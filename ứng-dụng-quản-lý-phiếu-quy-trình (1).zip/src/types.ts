/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type FormType = 'mau02' | 'mau03' | 'mau05';

export const PROCEDURE_FIELDS = [
  'Tư pháp',
  'Hộ tịch',
  'Kinh tế',
  'Hạ tầng - Đô thị',
  'Đất đai - Tài nguyên Môi trường',
  'Văn hóa - Xã hội',
  'Khác'
] as const;

export type ProcedureField = typeof PROCEDURE_FIELDS[number] | string;

export interface HistoryEntry {
  timestamp: string;
  action: string;
  user: string;
  details: string;
}

export interface Record {
  id: string;
  formType: FormType;
  ticketNo: string;        // Số phiếu (e.g., 05 / 123)
  createdDate: string;     // Ngày lập (YYYY-MM-DD)
  citizenName: string;     // Họ tên công dân / tổ chức
  citizenId: string;       // Số định danh cá nhân / CCCD / Mã số doanh nghiệp
  address: string;         // Địa chỉ
  phone: string;           // Số điện thoại
  email: string;           // Email
  recordId: string;        // Mã hồ sơ (nếu có)
  procedureContent: string;// Nội dung yêu cầu giải quyết / Nội dung thủ tục
  field?: string;          // Lĩnh vực thủ tục (Hộ tịch, Chứng thực, Đất đai, v.v.)
  
  // Specific for Mẫu 02 (Bổ sung hoàn thiện)
  papersList?: string[];   // Danh sách giấy tờ cần bổ sung
  officerPhone?: string;   // Điện thoại hướng dẫn
  
  // Specific for Mẫu 03 (Từ chối)
  rejectionReason?: string;// Lý do từ chối / bổ sung

  // Specific for Mẫu 05 (Dừng giải quyết)
  leaderName?: string;     // Tên lãnh đạo ký nhận
  stopReason?: string;     // Lý do đề nghị dừng
  stopDateRequest?: string;// Ngày đề nghị dừng của công dân
  
  officerName: string;     // Tên công chức tiếp nhận/hướng dẫn
  status: 'cho_xu_ly' | 'da_hoan_thien' | 'tu_choi' | 'bo_sung' | 'da_dung';
  notes?: string;          // Ghi chú
  history: HistoryEntry[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  username: string;
  action: string;          // Đăng nhập, Thêm, Sửa, Xóa, Import, Export, In...
  details: string;
  ip?: string;
}

export interface Procedure {
  id: string;
  code: string;
  name: string;
  field: string;           // Lĩnh vực
}

export interface Officer {
  id: string;
  name: string;
  dob?: string;            // Ngày sinh
  role: string;            // Chức vụ / Chức danh
  phone: string;           // Số điện thoại
  level?: string;          // Trình độ học vấn/chuyên môn
  major?: string;          // Chuyên ngành
  it?: string;             // Tin học
  language?: string;       // Ngoại ngữ
  political?: string;      // Lý luận chính trị
  isPartyMember?: boolean; // Đảng viên
  salaryCoeff?: string;    // Hệ số lương (vd: 4.40)
  citizenId?: string;      // Căn cước công dân / Số định danh cá nhân
  address?: string;        // Địa chỉ thường trú / Nơi ở hiện nay
  partyJoinDate?: string;  // Ngày vào Đảng
  email?: string;          // Email công vụ / cá nhân
  ethnicity?: string;      // Dân tộc
  hometown?: string;       // Quê quán
  notes?: string;          // Ghi chú bổ sung
}

export interface DailyReportSection {
  // Chứng thực bản sao
  ctBanSao_hoSo: number;
  ctBanSao_huongDan?: number;
  ctBanSao_ban: number;
  ctBanSao_tien: number;
  
  // Chứng thực chữ ký
  ctChuKy_hoSo: number;
  ctChuKy_huongDan?: number;
  ctChuKy_ban: number;
  ctChuKy_tien: number;

  // Hộ tịch
  hoTich_hoSo: number;
  hoTich_huongDan?: number;
  hoTich_ban: number;
  hoTich_tien: number;

  // Other fields (Kinh tế, Đất Đai - Tài nguyên môi trường, Hạ tầng - Đô thị, Văn hóa - Xã hội)
  kinhTe_hoSo: number;
  kinhTe_huongDan?: number;

  datDaiMoiTruong_hoSo: number;
  datDaiMoiTruong_huongDan?: number;

  haTangDoThi_hoSo: number;
  haTangDoThi_huongDan?: number;

  vanHoaXaHoi_hoSo: number;
  vanHoaXaHoi_huongDan?: number;

  // Bảo hiểm Y tế
  bhYTe_truongHop: number;
  bhYTe_huongDan?: number;
  bhYTe_tien: number;

  // Ngành dọc (nếu có)
  nganhDoc_thue: number;
  nganhDoc_thue_huongDan?: number;

  nganhDoc_bhxh: number;
  nganhDoc_bhxh_huongDan?: number;
}

export interface PaperDossiers {
  hoTich: number;
  datDai: number;
  taiNguyenMoiTruong: number;
  hoTich2: number;
  baoTroXaHoi: number;
  haTangDoThi: number;
}

export interface DailyReport {
  id: string;
  date: string; // YYYY-MM-DD
  officerId: string;
  officerName: string;
  reportedAt: string; // ISO string
  session: 'morning' | 'afternoon' | 'all_day';
  
  // Session details
  morning?: DailyReportSection;
  afternoon?: DailyReportSection;
  
  // Paper dossiers
  paperDossiers?: PaperDossiers;

  // Obstacles & suggestions
  difficulties?: string;
  suggestions?: string;
}

export interface ReportConfig {
  morningStart: string; // e.g. "10:30"
  morningEnd: string;   // e.g. "12:00"
  afternoonStart: string; // e.g. "15:30"
  afternoonEnd: string;   // e.g. "18:00"
}

export interface ReasonTemplate {
  id: string;
  formType: FormType;
  title: string;
  content: string;
}

export interface WordTemplate {
  id: string;
  name: string;
  formType: FormType;
  uploadedAt: string;
  placeholders: string[];
  isDefault: boolean;
  contentBase64?: string; // Stored template file
}

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: 'admin' | 'officer';
}
