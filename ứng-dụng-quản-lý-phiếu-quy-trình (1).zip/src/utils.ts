import * as XLSX from 'xlsx';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';
import { Record, FormType } from './types';

// Helper to format date to Vietnamese string (dd/mm/yyyy)
export function formatDateVN(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

// Get day, month, year components
export function getDateParts(dateStr: string) {
  if (!dateStr) {
    const today = new Date();
    return {
      day: String(today.getDate()).padStart(2, '0'),
      month: String(today.getMonth() + 1).padStart(2, '0'),
      year: String(today.getFullYear())
    };
  }
  const parts = dateStr.split('-');
  return {
    day: parts[2] || '……',
    month: parts[1] || '……',
    year: parts[0] || '……'
  };
}

// Translate status to Vietnamese
export function getStatusLabel(status: string): string {
  switch (status) {
    case 'cho_xu_ly': return 'Chờ xử lý';
    case 'da_hoan_thien': return 'Đã hoàn thiện';
    case 'tu_choi': return 'Từ chối';
    case 'bo_sung': return 'Yêu cầu bổ sung';
    case 'da_dung': return 'Đã dừng giải quyết';
    default: return status;
  }
}

// Translate form type to Vietnamese
export function getFormTypeLabel(type: FormType): string {
  switch (type) {
    case 'mau02': return 'Phiếu bổ sung hoàn thiện (Mẫu 02)';
    case 'mau03': return 'Phiếu từ chối giải quyết (Mẫu 03)';
    case 'mau05': return 'Thông báo dừng giải quyết (Mẫu 05)';
    default: return type;
  }
}

// Helper function to compare domain fields with alias matching (e.g., Đất đai - Môi trường vs Đất đai - Tài nguyên Môi trường)
export function isSameField(f1: string, f2: string): boolean {
  const s1 = (f1 || '').trim().toLowerCase();
  const s2 = (f2 || '').trim().toLowerCase();
  if (s1 === s2) return true;
  if (s1.includes('đất đai') && s2.includes('đất đai')) return true;
  if (s1.includes('hộ tịch') && s2.includes('hộ tịch')) return true;
  if (s1.includes('hạ tầng') && s2.includes('hạ tầng')) return true;
  if (s1.includes('kinh tế') && s2.includes('kinh tế')) return true;
  if (s1.includes('tư pháp') && s2.includes('tư pháp')) return true;
  if (s1.includes('văn hóa') && s2.includes('văn hóa')) return true;
  return false;
}

// Auto-generate consecutive ticket number by domain / field
export function getNextTicketNoForField(field: string, records: Record[], batchRows: Partial<Record>[] = []): string {
  if (!field) return '01';
  let maxNum = 0;

  records.forEach(r => {
    if (isSameField(r.field || '', field) && r.ticketNo) {
      const match = String(r.ticketNo).match(/\d+/);
      const num = match ? parseInt(match[0], 10) : parseInt(String(r.ticketNo), 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    }
  });

  batchRows.forEach(r => {
    if (isSameField(r.field || '', field) && r.ticketNo) {
      const match = String(r.ticketNo).match(/\d+/);
      const num = match ? parseInt(match[0], 10) : parseInt(String(r.ticketNo), 10);
      if (!isNaN(num) && num > maxNum) {
        maxNum = num;
      }
    }
  });

  const nextNum = maxNum + 1;
  return nextNum < 10 ? `0${nextNum}` : String(nextNum);
}

// Send Audit Log to Backend
export async function logAudit(username: string, action: string, details: string) {
  try {
    await fetch('/api/audit-logs/log-action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, action, details })
    });
  } catch (error) {
    console.error('Error logging audit action:', error);
  }
}

// Export Sổ theo dõi to Excel (Chức năng 5)
export function exportLogbookToExcel(records: Record[], customFilename?: string) {
  const data = records.map((r, i) => {
    return {
      'STT': i + 1,
      'Ngày lập': formatDateVN(r.createdDate),
      'Loại phiếu': r.formType === 'mau02' ? 'Bổ sung (Mẫu 02)' : r.formType === 'mau03' ? 'Từ chối (Mẫu 03)' : 'Dừng (Mẫu 05)',
      'Số phiếu': r.ticketNo,
      'Tên công dân, tổ chức': r.citizenName,
      'Số CCCD/Định danh': r.citizenId,
      'Địa chỉ thường trú/trụ sở': r.address || '',
      'Mã hồ sơ': r.recordId || 'N/A',
      'Thủ tục hành chính': r.procedureContent,
      'Nội dung bổ sung / yêu cầu': r.formType === 'mau02' ? (r.papersList?.join('; ') || '') : r.procedureContent,
      'Lý do từ chối / bổ sung / dừng': r.formType === 'mau02' ? (r.rejectionReason || 'Cần bổ sung hồ sơ') : r.formType === 'mau03' ? (r.rejectionReason || '') : (r.stopReason || ''),
      'Cán bộ hướng dẫn / tiếp nhận': r.officerName,
      'Số điện thoại hướng dẫn': r.officerPhone || 'N/A',
      'Trạng thái': getStatusLabel(r.status),
      'Ghi chú': r.notes || ''
    };
  });

  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sổ theo dõi');

  // Adjust columns width
  const wscols = [
    { wch: 6 },  // STT
    { wch: 12 }, // Ngày lập
    { wch: 18 }, // Loại phiếu
    { wch: 15 }, // Số phiếu
    { wch: 30 }, // Tên công dân, tổ chức
    { wch: 18 }, // Số CCCD
    { wch: 45 }, // Địa chỉ thường trú/trụ sở
    { wch: 18 }, // Mã hồ sơ
    { wch: 30 }, // Thủ tục
    { wch: 35 }, // Nội dung
    { wch: 35 }, // Lý do
    { wch: 22 }, // Cán bộ
    { wch: 15 }, // SĐT cán bộ
    { wch: 18 }, // Trạng thái
    { wch: 15 }  // Ghi chú
  ];
  ws['!cols'] = wscols;

  const finalName = customFilename || `So_Theo_Doi_Hanh_Chinh_Cong_${new Date().toISOString().split('T')[0]}`;
  XLSX.writeFile(wb, `${finalName}.xlsx`);
}

// Helper to escape XML special characters
export function xmlEscape(str: string | undefined | null): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Applies Times New Roman font to every text run in the XML
export function applyTimesNewRoman(xml: string): string {
  const fontTag = `<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman"/>`;
  
  // 1. If <w:rPr> exists, inject font tag inside it if not present
  let result = xml.replace(/<w:rPr>(?![\s\S]*?<w:rFonts)/gi, `<w:rPr>${fontTag}`);
  
  // 2. If <w:r> has no <w:rPr>, inject <w:rPr>${fontTag}</w:rPr>
  result = result.replace(/<w:r>(?!\s*<w:rPr>)/gi, `<w:r><w:rPr>${fontTag}</w:rPr>`);

  return result;
}

// Generate Docx using PizZip & Docxtemplater
export function generateWordDocument(record: Record, customTemplateBase64?: string) {
  const dateParts = getDateParts(record.createdDate);
  const papersText = record.papersList && record.papersList.length > 0
    ? record.papersList.map((p, i) => `${i + 1}. ${p}`).join('\n')
    : '';

  const data = {
    ticketNo: record.ticketNo,
    field: record.field || '',
    day: dateParts.day,
    month: dateParts.month,
    year: dateParts.year,
    citizenName: record.citizenName,
    citizenId: record.citizenId || '',
    address: record.address || '',
    phone: record.phone || '',
    email: record.email || '',
    recordId: record.recordId || '',
    procedureContent: record.procedureContent,
    papers: papersText,
    rejectionReason: record.rejectionReason || record.stopReason || '',
    officerName: record.officerName,
    officerPhone: record.officerPhone || '',
    leaderName: record.leaderName || '',
    stopReason: record.stopReason || '',
    stopDateRequest: record.stopDateRequest ? formatDateVN(record.stopDateRequest) : ''
  };

  try {
    let zip: PizZip;

    if (customTemplateBase64) {
      // Use the custom uploaded Word template
      const binaryString = window.atob(customTemplateBase64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      zip = new PizZip(bytes);
    } else {
      // Generate pristine raw Word document XML formatted to 100% accuracy
      let wordDocumentXml = getWordDocumentXml(record.formType, data);
      wordDocumentXml = applyTimesNewRoman(wordDocumentXml);

      zip = new PizZip();
      zip.file('word/document.xml', wordDocumentXml);
      zip.file('word/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman"/>
        <w:sz w:val="26"/>
        <w:szCs w:val="26"/>
        <w:lang w:val="vi-VN"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr>
      <w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman"/>
      <w:sz w:val="26"/>
    </w:rPr>
  </w:style>
</w:styles>`);
      zip.file('word/_rels/document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`);
      zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`);
      zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);
    }

    const doc = new Docxtemplater(zip, {
      paragraphLoop: true,
      linebreaks: true,
    });

    // Render the template with the substituted fields
    doc.setData(data);
    doc.render();

    const out = doc.getZip().generate({
      type: 'blob',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    });

    // Trigger download
    const url = window.URL.createObjectURL(out);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${record.formType === 'mau02' ? 'Phieu_bo_sung' : record.formType === 'mau03' ? 'Phieu_tu_choi' : 'Thong_bao_dung'}_${record.ticketNo.replace(/\//g, '_')}.docx`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);

    return true;
  } catch (error) {
    console.error('Error generating Word document:', error);
    return false;
  }
}

// Builds the raw WordProcessingML document.xml structure
function getWordDocumentXml(formType: FormType, d: any): string {
  const suffix = formType === 'mau02' ? 'PBS-TTPVHCC' : formType === 'mau03' ? 'PTC-TTPVHCC' : 'TBD-TTPVHCC';
  const formLabel = formType === 'mau02' ? 'Mẫu số 02' : formType === 'mau03' ? 'Mẫu số 03' : 'Mẫu số 05';

  const fontTN = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>';
  const fontBody = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="28"/><w:szCs w:val="28"/>';

  const headerTable = `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="5000" w:type="pct"/>
        <w:tblBorders>
          <w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/>
          <w:insideH w:val="none"/><w:insideV w:val="none"/>
        </w:tblBorders>
      </w:tblPr>
      <w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="2500" w:type="pct"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">UBND PHƯỜNG CẦU KIỆU</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
              <w:t xml:space="preserve">TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}</w:rPr><w:t xml:space="preserve">──────────</w:t></w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
              <w:t xml:space="preserve">Số: ${xmlEscape(d.ticketNo || '……')} / ${suffix}</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr>
              <w:t xml:space="preserve">(BPTNTKQ)</w:t>
            </w:r>
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="2500" w:type="pct"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="right"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">${formLabel}</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
              <w:t xml:space="preserve">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr>
              <w:t xml:space="preserve">Độc lập - Tự do - Hạnh phúc</w:t>
            </w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}</w:rPr><w:t xml:space="preserve">──────────────</w:t></w:r>
          </w:p>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr>
            <w:r><w:rPr>${fontTN}<w:i/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr>
              <w:t xml:space="preserve">Cầu Kiệu, ngày ${xmlEscape(d.day)} tháng ${xmlEscape(d.month)} năm ${xmlEscape(d.year)}</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
  `;

  if (formType === 'mau02') {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${headerTable}

    <w:p><w:pPr><w:spacing w:before="240" w:after="120"/><w:jc w:val="center"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>
        <w:t xml:space="preserve">PHIẾU YÊU CẦU BỔ SUNG, HOÀN THIỆN HỒ SƠ</w:t>
      </w:r>
    </w:p>

    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Hồ sơ của Ông (Bà)/Tổ chức: ${xmlEscape(d.citizenName) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Số định danh cá nhân/tổ chức: ${xmlEscape(d.citizenId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Mã hồ sơ (nếu có): ${xmlEscape(d.recordId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Địa chỉ: ${xmlEscape(d.address) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Số điện thoại: ${xmlEscape(d.phone) || '..................'}      Email: ${xmlEscape(d.email) || '..................'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Nội dung yêu cầu giải quyết: ${xmlEscape(d.procedureContent) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="120"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu yêu cầu Ông (Bà)/Tổ chức hoàn thiện hồ sơ gồm những nội dung sau:</w:t></w:r>
    </w:p>
    ${(() => {
      const content = [d.papers, d.rejectionReason].filter(Boolean).join('\n');
      if (!content.trim()) {
        return `<w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr><w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">……………………………………………………………………………………………………………………………………</w:t></w:r></w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr><w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">……………………………………………………………………………………………………………………………………</w:t></w:r></w:p>`;
      }
      return content.split('\n').map(line => {
        if (!line.trim()) return '';
        return `<w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="284"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr><w:r><w:rPr>${fontBody}<w:b/></w:rPr><w:t xml:space="preserve">${xmlEscape(line)}</w:t></w:r></w:p>`;
      }).filter(Boolean).join('\n    ');
    })()}
    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="120"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Trong quá trình hoàn thiện hồ sơ nếu có vướng mắc, Ông (Bà)/Tổ chức liên hệ với Ông/Bà ${xmlEscape(d.officerName) || '……………………'}${d.officerPhone ? ` số điện thoại ${xmlEscape(d.officerPhone)}` : ' số điện thoại ……………………'} để được hướng dẫn.</w:t></w:r>
    </w:p>

    <w:p><w:pPr><w:spacing w:before="240"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">NGƯỜI HƯỚNG DẪN  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:i/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr>
        <w:t xml:space="preserve">(Ký và ghi rõ họ tên hoặc chữ ký số nếu là biểu mẫu điện tử)  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:spacing w:before="1200"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">${xmlEscape(d.officerName) || '……………………'}  </w:t>
      </w:r>
    </w:p>
  </w:body>
</w:document>`;
  } else if (formType === 'mau03') {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${headerTable}

    <w:p><w:pPr><w:spacing w:before="240" w:after="120"/><w:jc w:val="center"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>
        <w:t xml:space="preserve">PHIẾU TỪ CHỐI TIẾP NHẬN GIẢI QUYẾT HỒ SƠ</w:t>
      </w:r>
    </w:p>

    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: ${xmlEscape(d.citizenName) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Số định danh cá nhân/tổ chức: ${xmlEscape(d.citizenId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Địa chỉ: ${xmlEscape(d.address) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Số điện thoại: ${xmlEscape(d.phone) || '..................'}      Email: ${xmlEscape(d.email) || '..................'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Mã hồ sơ (nếu có): ${xmlEscape(d.recordId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>

    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="120"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Qua xem xét, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo không tiếp nhận giải quyết hồ sơ này với lý do cụ thể như sau:</w:t></w:r>
    </w:p>
    ${(() => {
      const reasonStr = (d.rejectionReason || '……………………………………………………………………………………………………………………………………').trim();
      return reasonStr.split('\n').map(line => {
        if (!line.trim()) return '';
        return `<w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="284"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr><w:r><w:rPr>${fontBody}<w:b/></w:rPr><w:t xml:space="preserve">${xmlEscape(line)}</w:t></w:r></w:p>`;
      }).filter(Boolean).join('\n    ');
    })()}
    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:before="120" w:after="120"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Xin thông báo cho Ông (Bà)/Tổ chức được biết và phối hợp thực hiện.</w:t></w:r>
    </w:p>

    <w:p><w:pPr><w:spacing w:before="240"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">CÁN BỘ/CÔNG CHỨC TIẾP NHẬN HỒ SƠ  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:i/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr>
        <w:t xml:space="preserve">(Ký và ghi rõ họ tên hoặc chữ ký số nếu là biểu mẫu điện tử)  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:spacing w:before="1200"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">${xmlEscape(d.officerName) || '……………………'}  </w:t>
      </w:r>
    </w:p>
  </w:body>
</w:document>`;
  } else {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${headerTable}

    <w:p><w:pPr><w:spacing w:before="240" w:after="120"/><w:jc w:val="center"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>
        <w:t xml:space="preserve">THÔNG BÁO DỪNG GIẢI QUYẾT HỒ SƠ</w:t>
      </w:r>
    </w:p>

    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu đã tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: ${xmlEscape(d.citizenName) || '……………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Số định danh cá nhân/tổ chức: ${xmlEscape(d.citizenId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Mã hồ sơ: ${xmlEscape(d.recordId) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Nội dung yêu cầu giải quyết: ${xmlEscape(d.procedureContent) || '………………………………………………………………………………………………………………'}</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Qua kiểm tra, đến nay, mã hồ sơ ${xmlEscape(d.recordId) || '……………………'} chưa có quyết định giải quyết thủ tục hành chính hoặc có văn bản thông báo kết quả giải quyết thủ tục hành chính.</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/><w:ind w:firstLine="567"/><w:spacing w:line="276" w:lineRule="auto" w:after="80"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Theo đề nghị ngày ${xmlEscape(d.stopDateRequest) || '……/……/2026'} của Ông (Bà)/Tổ chức về việc dừng thực hiện hồ sơ giải quyết thủ tục hành chính, lý do: </w:t></w:r>
      <w:r><w:rPr>${fontBody}<w:b/></w:rPr><w:t xml:space="preserve">${xmlEscape(d.stopReason || '………………………………')}</w:t></w:r>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo dừng giải quyết hồ sơ nêu trên.</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Đề nghị Ông (Bà)/Tổ chức liên hệ Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả để nhận lại hồ sơ giấy và phí, lệ phí đã nộp (nếu có).</w:t></w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr>
      <w:r><w:rPr>${fontBody}</w:rPr><w:t xml:space="preserve">Xin thông báo cho Ông (Bà)/Tổ chức được biết.</w:t></w:r>
    </w:p>

    <w:p><w:pPr><w:spacing w:before="240"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">THỦ TRƯỜNG CƠ QUAN, ĐƠN VỊ  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:i/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr>
        <w:t xml:space="preserve">(Ký và ghi rõ họ tên hoặc chữ ký số nếu là biểu mẫu điện tử)  </w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:spacing w:before="1200"/><w:jc w:val="right"/></w:pPr>
      <w:r><w:rPr>${fontTN}<w:b/></w:rPr>
        <w:t xml:space="preserve">${xmlEscape(d.leaderName) || ''}  </w:t>
      </w:r>
    </w:p>
  </w:body>
</w:document>`;
  }
}
