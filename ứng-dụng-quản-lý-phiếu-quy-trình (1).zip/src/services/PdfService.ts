import { jsPDF } from 'jspdf';
import { Record } from '../types';
import { formatDateVN, getDateParts } from '../utils';

// Global cache for loaded fonts to prevent multiple fetch requests
let cachedRegularFont: string | null = null;
let cachedBoldFont: string | null = null;
let cachedItalicFont: string | null = null;

const FONT_URLS = {
  regular: [
    'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/tinos/Tinos-Regular.ttf',
    'https://raw.githubusercontent.com/google/fonts/main/ofl/tinos/Tinos-Regular.ttf',
    'https://raw.githubusercontent.com/vscat/vietnamese-fonts/master/times.ttf',
    'https://raw.githubusercontent.com/at-os/at-os.github.io/master/assets/fonts/times.ttf'
  ],
  bold: [
    'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/tinos/Tinos-Bold.ttf',
    'https://raw.githubusercontent.com/google/fonts/main/ofl/tinos/Tinos-Bold.ttf',
    'https://raw.githubusercontent.com/vscat/vietnamese-fonts/master/timesbd.ttf',
    'https://raw.githubusercontent.com/at-os/at-os.github.io/master/assets/fonts/timesbd.ttf'
  ],
  italic: [
    'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/tinos/Tinos-Italic.ttf',
    'https://raw.githubusercontent.com/google/fonts/main/ofl/tinos/Tinos-Italic.ttf',
    'https://raw.githubusercontent.com/vscat/vietnamese-fonts/master/timesi.ttf',
    'https://raw.githubusercontent.com/at-os/at-os.github.io/master/assets/fonts/timesi.ttf'
  ]
};

// Fetch helper with fallback urls
async function fetchFontWithFallback(urls: string[]): Promise<string> {
  let lastError: any = null;
  for (const url of urls) {
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP error ${response.status}`);
      const buffer = await response.arrayBuffer();
      
      // Convert buffer to Base64
      let binary = '';
      const bytes = new Uint8Array(buffer);
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      return window.btoa(binary);
    } catch (err) {
      console.warn(`Failed to fetch font from ${url}:`, err);
      lastError = err;
    }
  }
  throw lastError || new Error('All font URLs failed to load');
}

export async function prefetchFonts(): Promise<void> {
  if (cachedRegularFont && cachedBoldFont && cachedItalicFont) return;
  
  try {
    const [regular, bold, italic] = await Promise.all([
      cachedRegularFont ? Promise.resolve(cachedRegularFont) : fetchFontWithFallback(FONT_URLS.regular),
      cachedBoldFont ? Promise.resolve(cachedBoldFont) : fetchFontWithFallback(FONT_URLS.bold),
      cachedItalicFont ? Promise.resolve(cachedItalicFont) : fetchFontWithFallback(FONT_URLS.italic)
    ]);
    
    cachedRegularFont = regular;
    cachedBoldFont = bold;
    cachedItalicFont = italic;
  } catch (error) {
    console.error('Error prefetching PDF fonts:', error);
    throw error;
  }
}

export class PdfService {
  /**
   * Generates a high-quality vector-based PDF for administrative signing
   */
  public static async generateDocument(record: Record): Promise<jsPDF> {
    // Ensure fonts are loaded
    await prefetchFonts();

    // Create A4 PDF
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Load fonts into Virtual File System
    if (cachedRegularFont) {
      doc.addFileToVFS('times.ttf', cachedRegularFont);
      doc.addFont('times.ttf', 'Times New Roman', 'normal');
    }
    if (cachedBoldFont) {
      doc.addFileToVFS('timesbd.ttf', cachedBoldFont);
      doc.addFont('timesbd.ttf', 'Times New Roman', 'bold');
    }
    if (cachedItalicFont) {
      doc.addFileToVFS('timesi.ttf', cachedItalicFont);
      doc.addFont('timesi.ttf', 'Times New Roman', 'italic');
    }

    doc.setFont('Times New Roman', 'normal');

    const dateParts = getDateParts(record.createdDate);
    const suffix = record.formType === 'mau02' 
      ? 'PBS-TTPVHCC' 
      : record.formType === 'mau03' 
        ? 'PTC-TTPVHCC' 
        : 'TBD-TTPVHCC';

    const formLabel = record.formType === 'mau02' 
      ? 'Mẫu số 02' 
      : record.formType === 'mau03' 
        ? 'Mẫu số 03' 
        : 'Mẫu số 05';

    const titleText = record.formType === 'mau02'
      ? 'PHIẾU YÊU CẦU BỔ SUNG, HOÀN THIỆN HỒ SƠ'
      : record.formType === 'mau03'
        ? 'PHIẾU TỪ CHỐI TIẾP NHẬN GIẢI QUYẾT HỒ SƠ'
        : 'THÔNG BÁO DỪNG GIẢI QUYẾT HỒ SƠ';

    // 1. Draw Header Left (UBND PHƯỜNG CẦU KIỆU...)
    doc.setFont('Times New Roman', 'normal');
    doc.setFontSize(11);
    doc.text('UBND PHƯỜNG CẦU KIỆU', 65, 25, { align: 'center' });
    
    doc.setFont('Times New Roman', 'bold');
    doc.setFontSize(11);
    doc.text('TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG', 65, 30, { align: 'center' });

    // Underline Left
    doc.setLineWidth(0.2);
    doc.line(45, 32.5, 85, 32.5);

    doc.setFont('Times New Roman', 'normal');
    doc.setFontSize(11);
    doc.text(`Số: ${record.ticketNo || '……'} / ${suffix}`, 65, 38, { align: 'center' });
    
    doc.setFontSize(9);
    doc.text('(BPTNTKQ)', 65, 42, { align: 'center' });

    // 2. Draw Header Right (CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM...)
    doc.setFont('Times New Roman', 'normal');
    doc.setFontSize(11);
    doc.text(formLabel, 190, 20, { align: 'right' });

    doc.setFont('Times New Roman', 'bold');
    doc.setFontSize(11);
    doc.text('CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM', 150, 25, { align: 'center' });
    doc.text('Độc lập - Tự do - Hạnh phúc', 150, 30, { align: 'center' });

    // Underline Right
    doc.line(130, 32.5, 170, 32.5);

    doc.setFont('Times New Roman', 'italic');
    doc.setFontSize(12);
    doc.text(`Cầu Kiệu, ngày ${dateParts.day} tháng ${dateParts.month} năm ${dateParts.year}`, 150, 38, { align: 'center' });

    // 3. Draw Title
    doc.setFont('Times New Roman', 'bold');
    doc.setFontSize(14);
    doc.text(titleText, 105, 54, { align: 'center' });

    // Body text printing helpers with automatic page breaks
    let currentY = 66;

    const drawText = (
      text: string, 
      options: { 
        align?: 'left' | 'center' | 'right' | 'justify'; 
        fontSize?: number; 
        fontStyle?: 'normal' | 'bold' | 'italic';
        lineHeight?: number;
        indent?: number;
        spaceAfter?: number;
      } = {}
    ) => {
      const { 
        align = 'justify', 
        fontSize = 13, 
        fontStyle = 'normal', 
        lineHeight = 1.3,
        indent = 0,
        spaceAfter = 4
      } = options;

      doc.setFontSize(fontSize);
      doc.setFont('Times New Roman', fontStyle);

      const maxW = 160; // 190 - 30
      const indentMm = indent > 0 ? Math.min(indent * 2, 12) : 0;

      let lines: string[] = [];
      if (indentMm > 0) {
        const firstLineMaxW = maxW - indentMm;
        const words = text.trim().split(/\s+/);
        let currentLine = '';
        let isFirst = true;

        for (let w = 0; w < words.length; w++) {
          const word = words[w];
          const targetW = isFirst ? firstLineMaxW : maxW;
          const testLine = currentLine ? `${currentLine} ${word}` : word;
          if (doc.getTextWidth(testLine) <= targetW) {
            currentLine = testLine;
          } else {
            if (currentLine) {
              lines.push(currentLine);
              isFirst = false;
            }
            currentLine = word;
          }
        }
        if (currentLine) {
          lines.push(currentLine);
        }
      } else {
        lines = doc.splitTextToSize(text, maxW);
      }

      const fontHeight = fontSize * 0.3527777778; // pt to mm
      const step = fontHeight * lineHeight;

      for (let i = 0; i < lines.length; i++) {
        if (currentY > 270) {
          doc.addPage();
          currentY = 25;
        }

        const line = lines[i].trim();
        if (!line) continue;

        const lineX = (i === 0 && indentMm > 0) ? 30 + indentMm : 30;
        const lineMaxW = (i === 0 && indentMm > 0) ? maxW - indentMm : maxW;
        const isLastLine = (i === lines.length - 1);

        if (align === 'center') {
          doc.text(line, 105, currentY, { align: 'center' });
        } else if (align === 'right') {
          doc.text(line, 190, currentY, { align: 'right' });
        } else if (align === 'justify' && !isLastLine) {
          // Passing array [line, ''] forces jsPDF to justify line across lineMaxW
          doc.text([line, ''], lineX, currentY, { align: 'justify', maxWidth: lineMaxW });
        } else {
          doc.text(line, lineX, currentY);
        }
        currentY += step;
      }

      currentY += spaceAfter;
    };

    const drawDottedRow = (label: string, value: string | undefined, spaceAfter = 4) => {
      if (currentY > 270) {
        doc.addPage();
        currentY = 25;
      }

      doc.setFontSize(13);
      doc.setFont('Times New Roman', 'normal');
      
      const labelWidth = doc.getTextWidth(label);
      doc.text(label, 30, currentY);

      const val = value || '';
      if (val) {
        doc.setFont('Times New Roman', 'bold');
        // Wrap value if too long to prevent page overflow
        const maxValW = 190 - (30 + labelWidth);
        const wrappedVal = doc.splitTextToSize(val, maxValW);
        
        for (let i = 0; i < wrappedVal.length; i++) {
          if (i === 0) {
            doc.text(wrappedVal[i], 30 + labelWidth, currentY);
          } else {
            currentY += 13 * 0.3527777778 * 1.3;
            if (currentY > 270) {
              doc.addPage();
              currentY = 25;
            }
            doc.text(wrappedVal[i], 30 + labelWidth, currentY);
          }
        }

        // Draw dots if space left in the last line
        const lastLineWidth = doc.getTextWidth(wrappedVal[wrappedVal.length - 1]);
        const startDotsX = 30 + (wrappedVal.length === 1 ? labelWidth : 0) + lastLineWidth + 1;
        if (190 > startDotsX) {
          doc.setFont('Times New Roman', 'normal');
          const dotsW = 190 - startDotsX;
          const dotWidth = doc.getTextWidth('.');
          const dotCount = Math.floor(dotsW / dotWidth);
          if (dotCount > 0) {
            doc.text('.'.repeat(dotCount), startDotsX, currentY);
          }
        }
      } else {
        // Draw empty dotted line
        const startDotsX = 30 + labelWidth + 1;
        const dotsW = 190 - startDotsX;
        const dotWidth = doc.getTextWidth('.');
        const dotCount = Math.floor(dotsW / dotWidth);
        if (dotCount > 0) {
          doc.text('.'.repeat(dotCount), startDotsX, currentY);
        }
      }

      currentY += (13 * 0.3527777778 * 1.3) + spaceAfter;
    };

    // 4. Draw Document content depending on FormType
    if (record.formType === 'mau02') {
      drawDottedRow('Hồ sơ của Ông (Bà)/Tổ chức: ', record.citizenName);
      drawDottedRow('Số định danh cá nhân/tổ chức: ', record.citizenId);
      drawDottedRow('Mã hồ sơ (nếu có): ', record.recordId);
      drawDottedRow('Địa chỉ: ', record.address);
      
      // Phone and Email in columns
      if (currentY > 270) { doc.addPage(); currentY = 25; }
      doc.setFont('Times New Roman', 'normal');
      doc.setFontSize(13);
      let currentX = 30;
      
      doc.text('Số điện thoại: ', currentX, currentY);
      const telLabelW = doc.getTextWidth('Số điện thoại: ');
      if (record.phone) {
        doc.setFont('Times New Roman', 'bold');
        doc.text(record.phone, currentX + telLabelW, currentY);
        currentX += telLabelW + doc.getTextWidth(record.phone) + 15;
      } else {
        doc.setFont('Times New Roman', 'normal');
        doc.text('..................', currentX + telLabelW, currentY);
        currentX += telLabelW + doc.getTextWidth('..................') + 15;
      }

      doc.setFont('Times New Roman', 'normal');
      doc.text('Email: ', currentX, currentY);
      const emailLabelW = doc.getTextWidth('Email: ');
      if (record.email) {
        doc.setFont('Times New Roman', 'bold');
        doc.text(record.email, currentX + emailLabelW, currentY);
        currentX += emailLabelW + doc.getTextWidth(record.email);
      } else {
        doc.setFont('Times New Roman', 'normal');
        doc.text('..................', currentX + emailLabelW, currentY);
        currentX += emailLabelW + doc.getTextWidth('..................');
      }
      
      // Draw trailing dots
      if (190 > currentX) {
        doc.setFont('Times New Roman', 'normal');
        const dotsW = 190 - currentX;
        const dotCount = Math.floor(dotsW / doc.getTextWidth('.'));
        if (dotCount > 0) doc.text('.'.repeat(dotCount), currentX, currentY);
      }
      currentY += (13 * 0.3527777778 * 1.3) + 4;

      drawDottedRow('Nội dung yêu cầu giải quyết: ', record.procedureContent);

      drawText('Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu yêu cầu Ông (Bà)/Tổ chức hoàn thiện hồ sơ gồm những nội dung sau:', {
        indent: 4,
        spaceAfter: 4
      });

      // Papers list & Reason
      const hasPapers = record.papersList && record.papersList.length > 0;
      const hasReason = Boolean(record.rejectionReason);

      if (hasPapers || hasReason) {
        if (hasPapers) {
          record.papersList!.forEach((paper, idx) => {
            const lines = paper.split('\n');
            lines.forEach((l, i) => {
              if (l.trim()) {
                drawText(i === 0 ? `${idx + 1}. ${l.trim()}` : `   ${l.trim()}`, {
                  fontStyle: 'bold',
                  spaceAfter: 2,
                  indent: 2
                });
              }
            });
          });
        }
        if (hasReason) {
          const lines = record.rejectionReason!.split('\n');
          lines.forEach((l) => {
            if (l.trim()) {
              drawText(l.trim(), {
                fontStyle: 'normal',
                spaceAfter: 2,
                indent: 2
              });
            }
          });
        }
      } else {
        drawText('……………………………………………………………………………………………………………………………………', { spaceAfter: 2 });
        drawText('……………………………………………………………………………………………………………………………………', { spaceAfter: 2 });
        drawText('……………………………………………………………………………………………………………………………………', { spaceAfter: 2 });
      }

      currentY += 2;

      drawText(`Trong quá trình hoàn thiện hồ sơ nếu có vướng mắc, Ông (Bà)/Tổ chức liên hệ với Ông/Bà ${record.officerName || '……………………'}${record.officerPhone ? ` số điện thoại ${record.officerPhone}` : ' số điện thoại ……………………'} để được hướng dẫn.`, {
        indent: 4
      });

    } else if (record.formType === 'mau03') {
      drawText('Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu', { indent: 4 });
      drawDottedRow('Tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: ', record.citizenName);
      drawDottedRow('Số định danh cá nhân/tổ chức: ', record.citizenId);
      drawDottedRow('Địa chỉ: ', record.address);

      // Phone and email row
      if (currentY > 270) { doc.addPage(); currentY = 25; }
      doc.setFont('Times New Roman', 'normal');
      doc.setFontSize(13);
      let currentX = 30;

      doc.text('Số điện thoại: ', currentX, currentY);
      const telLabelW = doc.getTextWidth('Số điện thoại: ');
      if (record.phone) {
        doc.setFont('Times New Roman', 'bold');
        doc.text(record.phone, currentX + telLabelW, currentY);
        currentX += telLabelW + doc.getTextWidth(record.phone) + 15;
      } else {
        doc.setFont('Times New Roman', 'normal');
        doc.text('..................', currentX + telLabelW, currentY);
        currentX += telLabelW + doc.getTextWidth('..................') + 15;
      }

      doc.setFont('Times New Roman', 'normal');
      doc.text('Email: ', currentX, currentY);
      const emailLabelW = doc.getTextWidth('Email: ');
      if (record.email) {
        doc.setFont('Times New Roman', 'bold');
        doc.text(record.email, currentX + emailLabelW, currentY);
        currentX += emailLabelW + doc.getTextWidth(record.email);
      } else {
        doc.setFont('Times New Roman', 'normal');
        doc.text('..................', currentX + emailLabelW, currentY);
        currentX += emailLabelW + doc.getTextWidth('..................');
      }
      
      if (190 > currentX) {
        doc.setFont('Times New Roman', 'normal');
        const dotsW = 190 - currentX;
        const dotCount = Math.floor(dotsW / doc.getTextWidth('.'));
        if (dotCount > 0) doc.text('.'.repeat(dotCount), currentX, currentY);
      }
      currentY += (13 * 0.3527777778 * 1.3) + 4;

      drawDottedRow('Mã hồ sơ (nếu có): ', record.recordId);

      drawText('Qua xem xét, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo không tiếp nhận giải quyết hồ sơ này với lý do cụ thể như sau:', { indent: 4 });

      // Rejection reason highlighted
      drawText(record.rejectionReason || '………………………………………………………………………………………………………………', {
        fontStyle: 'bold',
        spaceAfter: 6
      });

      drawText('Xin thông báo cho Ông (Bà)/Tổ chức được biết và phối hợp thực hiện.', { indent: 4 });

    } else {
      // mau05
      drawText(`Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu đã tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: ${record.citizenName || '……………………'}`, { indent: 4 });
      drawDottedRow('Số định danh cá nhân/tổ chức: ', record.citizenId);
      drawDottedRow('Mã hồ sơ: ', record.recordId);
      drawDottedRow('Nội dung yêu cầu giải quyết: ', record.procedureContent);

      drawText(`Qua kiểm tra, đến nay, mã hồ sơ ${record.recordId || '……………………'} chưa có quyết định giải quyết thủ tục hành chính hoặc có văn bản thông báo kết quả giải quyết thủ tục hành chính.`, { indent: 4 });

      const requestDate = record.stopDateRequest ? formatDateVN(record.stopDateRequest) : '……/……/2026';
      drawText(`Theo đề nghị ngày ${requestDate} của Ông (Bà)/Tổ chức về việc dừng thực hiện hồ sơ giải quyết thủ tục hành chính, lý do: ${record.stopReason || '………………………………'}, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo dừng giải quyết hồ sơ nêu trên.`, { indent: 4 });

      drawText('Đề nghị Ông (Bà)/Tổ chức liên hệ Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả để nhận lại hồ sơ giấy và phí, lệ phí đã nộp (nếu có).', { indent: 4 });

      drawText('Xin thông báo cho Ông (Bà)/Tổ chức được biết.', { indent: 4 });
    }

    // 5. Signature Section
    currentY += 10;
    if (currentY > 230) {
      doc.addPage();
      currentY = 30;
    }

    const titleSig = record.formType === 'mau02' 
      ? 'NGƯỜI HƯỚNG DẪN' 
      : record.formType === 'mau03' 
        ? 'NGƯỜI TIẾP NHẬN HỒ SƠ' 
        : 'THỦ TRƯỞNG CƠ QUAN, ĐƠN VỊ';

    const personSig = record.formType === 'mau05'
      ? (record.leaderName || '')
      : (record.officerName || 'Nguyễn Văn Hùng');

    doc.setFont('Times New Roman', 'bold');
    doc.setFontSize(12);
    doc.text(titleSig, 150, currentY, { align: 'center' });

    doc.setFont('Times New Roman', 'italic');
    doc.setFontSize(9);
    doc.text('(Ký và ghi rõ họ tên hoặc chữ ký số nếu là biểu mẫu điện tử)', 150, currentY + 4, { align: 'center' });

    // Spacious area for digital/physical signature (USB token / SmartCA / ViettelCA...)
    // This provides ~25mm of safe, clear vector white space for placement of digital certificates
    currentY += 30; 

    doc.setFont('Times New Roman', 'bold');
    doc.setFontSize(13);
    doc.text(personSig, 150, currentY, { align: 'center' });

    return doc;
  }

  /**
   * Generates filename according to strict standards
   * Format: Phieu_[Loại phiếu]_[Mã hồ sơ]_[Ngày].pdf
   */
  public static getFilename(record: Record): string {
    const dateStr = record.createdDate || new Date().toISOString().split('T')[0];
    const cleanNo = (record.recordId || record.ticketNo || 'HS').replace(/[^a-zA-Z0-9]/g, '');
    
    let typeName = 'BoSung';
    if (record.formType === 'mau03') typeName = 'TuChoi';
    if (record.formType === 'mau05') typeName = 'Dung';

    return `Phieu_${typeName}_${cleanNo}_${dateStr}.pdf`;
  }
}
