export class PrintService {
  /**
   * Directly prints an HTML content string or element with custom print-specific CSS
   */
  public static printHtml(printContents: string, title = 'In Phiếu'): void {
    if (!printContents) return;

    // Create a hidden iframe for isolated print context
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);
    
    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${title}</title>
            <style>
              @page {
                size: A4;
                margin: 2cm 2cm 2cm 3cm; /* Top, Right, Bottom, Left margins */
              }
              body {
                font-family: "Times New Roman", Times, serif;
                color: #000;
                background: #fff;
                margin: 0;
                padding: 0;
                font-size: 13px;
                line-height: 1.3;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
              .document-paper {
                width: 100%;
                background: #fff;
              }
              /* Grid layout as tables for clean printing */
              .grid {
                display: table !important;
                width: 100% !important;
                table-layout: fixed !important;
              }
              .grid-cols-2 > div {
                display: table-cell !important;
                width: 50% !important;
                vertical-align: top !important;
              }
              /* Alignments */
              .text-center {
                text-align: center !important;
              }
              .text-right {
                text-align: right !important;
              }
              .text-justify {
                text-align: justify !important;
              }
              /* Font styles */
              .font-bold {
                font-weight: bold !important;
              }
              .font-semibold {
                font-weight: 600 !important;
              }
              .font-medium {
                font-weight: 500 !important;
              }
              .italic {
                font-style: italic !important;
              }
              .uppercase {
                text-transform: uppercase !important;
              }
              /* Spacing and margins */
              .my-6 {
                margin-top: 1.5rem !important;
                margin-bottom: 1.5rem !important;
              }
              .my-3 {
                margin-top: 1rem !important;
                margin-bottom: 1rem !important;
              }
              .my-4 {
                margin-top: 1.25rem !important;
                margin-bottom: 1.25rem !important;
              }
              .my-1.5 {
                margin-top: 0.375rem !important;
                margin-bottom: 0.375rem !important;
              }
              .mb-1 {
                margin-bottom: 0.25rem !important;
              }
              .mb-6 {
                margin-bottom: 1.5rem !important;
              }
              .pb-4 {
                padding-bottom: 1rem !important;
              }
              .pb-2 {
                padding-bottom: 0.5rem !important;
              }
              .mt-12 {
                margin-top: 3rem !important;
              }
              .mt-1 {
                margin-top: 0.25rem !important;
              }
              .pt-4 {
                padding-top: 1rem !important;
              }
              .space-y-4 > * + * {
                margin-top: 1rem !important;
              }
              .space-y-1.5 > * + * {
                margin-top: 0.375rem !important;
              }
              .pl-4 {
                padding-left: 1rem !important;
              }
              .h-20 {
                height: 5rem !important;
              }
              .w-16 {
                width: 4rem !important;
              }
              .w-24 {
                width: 6rem !important;
              }
              .h-[1px] {
                height: 1px !important;
              }
              .bg-black {
                background-color: #000 !important;
              }
              .mx-auto {
                margin-left: auto !important;
                margin-right: auto !important;
              }
              /* Flex elements with border-b dotted lines */
              .flex {
                display: table !important;
                width: 100% !important;
              }
              .flex > span {
                display: table-cell !important;
                vertical-align: bottom !important;
              }
              .shrink-0 {
                width: auto !important;
                white-space: nowrap !important;
                padding-right: 4px !important;
              }
              .shrink-1 {
                width: 100% !important;
              }
              .border-b {
                border-bottom: 1px solid #000 !important;
              }
              .border-dashed {
                border-bottom-style: dotted !important;
              }
              .border-gray-400 {
                border-bottom-color: #444 !important;
              }
              .px-1 {
                padding-left: 0.25rem !important;
                padding-right: 0.25rem !important;
              }
              .indent-8 {
                text-indent: 2rem !important;
              }
              /* Font sizes */
              .text-[14px] {
                font-size: 14px !important;
              }
              .text-[13px] {
                font-size: 13px !important;
              }
              .text-[12px] {
                font-size: 12px !important;
              }
              .text-[11px] {
                font-size: 11px !important;
              }
              .text-[10px] {
                font-size: 10px !important;
              }
              .text-blue-900 {
                color: #000 !important;
              }
              .text-slate-850 {
                color: #000 !important;
              }
              .text-red-950 {
                color: #000 !important;
              }
              .bg-red-50\/20 {
                background: none !important;
                border: 1px solid #000 !important;
                padding: 0.5rem !important;
                margin: 0.5rem 0 !important;
              }
              .border-l-2 {
                border-left-width: 2px !important;
              }
              .border-red-500 {
                border-color: #000 !important;
              }
              .rounded {
                border-radius: 4px !important;
              }
              .text-gray-400 {
                display: none !important; /* Hide guidance placeholders on print */
              }
              .no-print {
                display: none !important;
              }
            </style>
          </head>
          <body>
            <div class="document-paper">
              ${printContents}
            </div>
            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                  setTimeout(function() {
                    window.parent.document.body.removeChild(window.frameElement);
                  }, 200);
                }, 300);
              };
            </script>
          </body>
        </html>
      `);
      doc.close();
    }
  }
}
