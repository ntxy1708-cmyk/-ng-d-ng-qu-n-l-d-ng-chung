import React, { useState } from 'react';
import { AuditLog } from '../types';
import { formatDateVN } from '../utils';
import { ShieldCheck, Search, Calendar, User, SlidersHorizontal, Trash2 } from 'lucide-react';

interface AuditLogsProps {
  logs: AuditLog[];
  onClearLogs?: () => void;
  currentUserRole: string;
}

export default function AuditLogs({ logs, onClearLogs, currentUserRole }: AuditLogsProps) {
  const [search, setSearch] = useState('');
  const [userFilter, setUserFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('');

  // Extract unique users and actions for filters
  const uniqueUsers = Array.from(new Set(logs.map(l => l.username))).filter(Boolean);
  const uniqueActions = Array.from(new Set(logs.map(l => l.action))).filter(Boolean);

  // Filter logic
  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.details.toLowerCase().includes(search.toLowerCase()) || 
                          (log.ip && log.ip.includes(search));
    const matchesUser = userFilter ? log.username === userFilter : true;
    const matchesAction = actionFilter ? log.action === actionFilter : true;
    return matchesSearch && matchesUser && matchesAction;
  });

  const getActionBadgeColor = (action: string) => {
    switch (action) {
      case 'Đăng nhập': return 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300';
      case 'Đăng xuất': return 'bg-slate-50 text-slate-700 dark:bg-slate-800 dark:text-slate-300';
      case 'Thêm': return 'bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300';
      case 'Sửa': return 'bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300';
      case 'Xóa': return 'bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300';
      case 'Import': return 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-300';
      case 'Export': return 'bg-purple-50 text-purple-700 dark:bg-purple-950/30 dark:text-purple-300';
      case 'In': return 'bg-cyan-50 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-300';
      default: return 'bg-slate-50 text-slate-700 dark:bg-slate-800 dark:text-slate-300';
    }
  };

  const formatTimestamp = (isoString: string): string => {
    try {
      const d = new Date(isoString);
      const timeStr = d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const dateStr = d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
      return `${timeStr} - ${dateStr}`;
    } catch {
      return isoString;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Header Bar */}
      <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400 animate-pulse" />
            <h3 className="font-bold text-slate-850 dark:text-slate-200">Lịch sử hệ thống (Audit Trail)</h3>
          </div>
          {onClearLogs && currentUserRole === 'admin' && (
            <button
              onClick={() => {
                if(confirm('Bạn có chắc muốn làm trống toàn bộ lịch sử Audit Log hệ thống?')) onClearLogs();
              }}
              className="flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-700 bg-red-50 dark:bg-red-950/20 dark:text-red-300 border border-red-100 dark:border-red-900/50 px-3.5 py-1.5 rounded-lg cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Làm trống nhật ký
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Text Search */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder="Tìm kiếm chi tiết hoặc IP..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
            />
          </div>

          {/* User Filter */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
            <User className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
            >
              <option value="">Tất cả cán bộ</option>
              {uniqueUsers.map(user => (
                <option key={user} value={user}>{user}</option>
              ))}
            </select>
          </div>

          {/* Action Filter */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
            <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
            >
              <option value="">Tất cả hành động</option>
              {uniqueActions.map(act => (
                <option key={act} value={act}>{act}</option>
              ))}
            </select>
          </div>

          {/* Records Counter */}
          <div className="flex items-center justify-end text-xs font-semibold text-slate-500 dark:text-slate-400 pr-2">
            Hiển thị {filteredLogs.length} / {logs.length} sự kiện
          </div>
        </div>
      </div>

      {/* Logs Registry Table */}
      <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold sticky top-0 border-b border-slate-200 dark:border-slate-700 z-10">
              <tr>
                <th className="py-3 px-4 w-12 text-center">STT</th>
                <th className="py-3 px-4 w-44">Thời gian</th>
                <th className="py-3 px-4 w-32">Cán bộ</th>
                <th className="py-3 px-4 w-28">Hành động</th>
                <th className="py-3 px-4">Chi tiết nội dung xử lý</th>
                <th className="py-3 px-4 w-32 text-center">Địa chỉ IP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-normal">
              {filteredLogs.map((log, index) => (
                <tr key={log.id || index} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                  <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-400">
                    {index + 1}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-350">
                    {formatTimestamp(log.timestamp)}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                    {log.username}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${getActionBadgeColor(log.action)}`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-650 dark:text-slate-300 leading-relaxed max-w-sm break-words text-justify">
                    {log.details}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-500">
                    {log.ip || '127.0.0.1'}
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 italic">
                    Không có bản ghi nhật ký nào thỏa mãn điều kiện tìm kiếm.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
