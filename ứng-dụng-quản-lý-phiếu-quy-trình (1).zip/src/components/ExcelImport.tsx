import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Upload, AlertCircle, CheckCircle, FileSpreadsheet, RefreshCw, AlertTriangle } from 'lucide-react';
import { Record, PROCEDURE_FIELDS } from '../types';
import { formatDateVN, getNextTicketNoForField } from '../utils';

interface ExcelImportProps {
  existingRecords: Record[];
  onImportComplete: (importCount: number, syncCount: number) => void;
  currentUser: string;
}

interface ImportRow {
  rowNum: number;
  data: Partial<Record>;
  status: 'new' | 'update' | 'error';
  errors: string[];
}

export default function ExcelImport({ existingRecords, onImportComplete, currentUser }: ExcelImportProps) {
  const [dragActive, setDragActive] = useState(false);
  const [parsedRows, setParsedRows] = useState<ImportRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [replaceExisting, setReplaceExisting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Removes accents and special chars for intelligent column header matching
  const normalizeKey = (str: string) => {
    return str
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'd')
      .replace(/[^a-z0-9]/g, '');
  };

  // Maps excel columns to DB fields dynamically
  const mapRowToRecord = (row: any): Partial<Record> => {
    const keys = Object.keys(row);
    const result: Partial<Record> = {};

    // Helper to find column matching keywords with normalized accents
    const findValue = (keywords: string[]) => {
      const matchKey = keys.find(k => {
        const cleanK = normalizeKey(k);
        if (!cleanK) return false;
        return keywords.some(kw => cleanK.includes(kw) || kw.includes(cleanK));
      });
      if (!matchKey) return undefined;
      const val = row[matchKey];
      return val !== undefined && val !== null ? String(val).trim() : undefined;
    };

    // 1. Tên công dân, tổ chức (Họ và tên trong file import)
    result.citizenName = findValue([
      'hovatencongdantochuc',
      'hovatencongdan',
      'tencongdantochuc',
      'tencongdan',
      'hovaten',
      'hoten',
      'tentochuc',
      'citizenname',
      'congdan',
      'tochuc',
      'khachhang',
      'nguoinop',
      'name'
    ]);

    // 2. Địa chỉ thường trú/trụ sở (Địa chỉ trong file import)
    result.address = findValue([
      'diachithuongtrutruso',
      'diachithuongtru',
      'diachitruso',
      'diachi',
      'truso',
      'noio',
      'noicutru',
      'cutru',
      'address',
      'choo'
    ]) || '';

    result.citizenId = findValue([
      'sodinhdanhcanhan',
      'sodinhdanh',
      'socancuoccongdan',
      'socancuoc',
      'cancuoccongdan',
      'cancuoc',
      'cccd',
      'socmnd',
      'cmnd',
      'masothue',
      'mst',
      'citizenid'
    ]) || '';

    result.ticketNo = findValue(['tongsophieu', 'sophieu', 'ticketno', 'sohieu', 'stt', 'so']);
    result.recordId = findValue(['mahoso', 'masohoso', 'mahs', 'recordid', 'hoso']);
    result.phone = findValue(['dienthoai', 'phone', 'sodt', 'sodienthoai', 'lienhe']) || '';
    result.email = findValue(['email', 'thudientu']) || '';
    result.procedureContent = findValue(['thutuchanhchinh', 'thutuc', 'noidungyeucaugiaiquyet', 'noidungyeucau', 'noidungthutuc', 'noidung', 'procedure', 'yeucau']);
    result.rejectionReason = findValue(['lydo', 'lydotuchoi', 'lydobosung', 'noidungyeucau', 'rejectionreason', 'reason', 'chitiet']);
    result.officerName = findValue(['congchuchuongdan', 'canbohuongdan', 'officername', 'nguoitiepnhan', 'canbo', 'nguoilap', 'congchuc']);
    result.officerPhone = findValue(['sdtcanbo', 'officerphone', 'dienthoaicanbo', 'sdtcongchuc']);
    
    // Parse Field / Lĩnh vực thủ tục
    const rawField = findValue(['linhvuctuctuc', 'linhvuctuctu', 'linhvucls', 'linhvuc', 'field', 'nghanh', 'domain']);
    if (rawField) {
      let fieldStr = String(rawField).trim();
      // Remove roman numeral prefix like "I Lĩnh vực Hộ tịch" -> "Hộ tịch"
      fieldStr = fieldStr.replace(/^[I|V|X]+\s*/i, '').replace(/^Lĩnh\s+vực\s+/i, '').trim();
      
      const matchedStd = PROCEDURE_FIELDS.find(f => 
        f.toLowerCase().includes(fieldStr.toLowerCase()) || 
        fieldStr.toLowerCase().includes(f.toLowerCase().split(' ')[0])
      );
      result.field = matchedStd || fieldStr || 'Hộ tịch';
    } else {
      result.field = 'Hộ tịch';
    }

    // Parse Form Type & Status
    const formTypeVal = findValue(['loaiphieu', 'formtype', 'loai']);
    if (formTypeVal) {
      const ft = String(formTypeVal).toLowerCase().trim();
      if (ft.includes('tu choi') || ft.includes('từ chối') || ft.includes('mau03') || ft.includes('mau 03')) {
        result.formType = 'mau03';
        result.status = 'tu_choi';
      } else if (ft.includes('bo sung') || ft.includes('bổ sung') || ft.includes('mau02') || ft.includes('mau 02')) {
        result.formType = 'mau02';
        result.status = 'bo_sung';
      } else if (ft.includes('dung') || ft.includes('dừng') || ft.includes('mau05') || ft.includes('mau 05')) {
        result.formType = 'mau05';
        result.status = 'da_dung';
      }
    }
    
    // Parse status fallback if not set by formType
    if (!result.status) {
      const statusVal = findValue(['trangthai', 'status']);
      if (statusVal) {
        const s = String(statusVal).toLowerCase().trim();
        if (s.includes('cho') || s.includes('tiếp nhận')) result.status = 'cho_xu_ly';
        else if (s.includes('hoàn thiện') || s.includes('xong')) result.status = 'da_hoan_thien';
        else if (s.includes('từ chối') || s.includes('tuchoi')) result.status = 'tu_choi';
        else if (s.includes('bổ sung') || s.includes('bosung')) result.status = 'bo_sung';
        else if (s.includes('dừng') || s.includes('da_dung')) result.status = 'da_dung';
      }
    }

    // Papers list parsing for Mau02
    const papersVal = findValue(['giayto', 'papers', 'danhsach', 'bosung']);
    if (papersVal) {
      result.papersList = String(papersVal).split(/;|\n|,/).map(p => p.trim()).filter(Boolean);
      if (!result.formType) result.formType = 'mau02';
    }

    if (!result.formType) {
      result.formType = 'mau03';
    }

    // Created Date
    const dateVal = findValue(['ngaythangtuchoi', 'ngaytuchoi', 'ngaythang', 'ngaytao', 'ngaylap', 'ngay', 'date']);
    if (dateVal) {
      if (typeof dateVal === 'number') {
        // Excel date serialization conversion
        const utcDays = Math.floor(dateVal - 25569);
        const utcValue = utcDays * 86400;
        const dateInfo = new Date(utcValue * 1000);
        result.createdDate = dateInfo.toISOString().split('T')[0];
      } else {
        const parts = String(dateVal).split(/[-/]/);
        if (parts.length === 3) {
          // If in dd/mm/yyyy
          if (parts[0].length === 2 && parts[2].length === 4) {
            result.createdDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
          } else {
            result.createdDate = String(dateVal);
          }
        }
      }
    }

    return result;
  };

  const processFile = (file: File) => {
    setFileName(file.name);
    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json: any[] = XLSX.utils.sheet_to_json(worksheet);

        const accumulatedBatch: Partial<Record>[] = [];

        const rows: ImportRow[] = json.map((row, idx) => {
          const mapped = mapRowToRecord(row);
          const errors: string[] = [];
          
          if (!mapped.citizenName) errors.push('Thiếu Họ tên công dân/tổ chức');

          // Auto generate ticketNo for domain if missing
          if (!mapped.ticketNo) {
            mapped.ticketNo = getNextTicketNoForField(mapped.field || 'Hộ tịch', existingRecords, accumulatedBatch);
          }

          if (!mapped.citizenId) {
            mapped.citizenId = '';
          }

          accumulatedBatch.push(mapped);

          // Check if record already exists by ticketNo or recordId
          const isDuplicate = existingRecords.some(r => 
            (mapped.ticketNo && r.ticketNo === mapped.ticketNo && r.field === mapped.field) || 
            (mapped.recordId && r.recordId === mapped.recordId)
          );

          let rowStatus: 'new' | 'update' | 'error' = 'new';
          if (errors.length > 0) {
            rowStatus = 'error';
          } else if (isDuplicate) {
            rowStatus = 'update';
          }

          return {
            rowNum: idx + 2, // Excel spreadsheet is 1-indexed, and row 1 is header
            data: mapped,
            status: rowStatus,
            errors
          };
        });

        setParsedRows(rows);
      } catch (error) {
        console.error('Failed to parse excel file:', error);
        alert('Có lỗi xảy ra khi đọc file Excel. Vui lòng kiểm tra lại cấu trúc file.');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleConfirmImport = async () => {
    const validRows = parsedRows.filter(r => r.status !== 'error');
    if (validRows.length === 0) {
      alert('Không có dữ liệu hợp lệ để nhập khẩu.');
      return;
    }

    if (replaceExisting) {
      const confirmReplace = confirm('⚠️ CẢNH BÁO THAY THẾ DỮ LIỆU:\n\nBạn đã chọn "Thay thế dữ liệu hiện có". Tất cả danh sách hồ sơ cũ trên hệ thống sẽ bị XÓA và thay bằng dữ liệu trong file này.\n\nBạn có chắc chắn muốn thực hiện?');
      if (!confirmReplace) return;
    }

    setIsProcessing(true);
    try {
      const recordsToPost = validRows.map(r => r.data);
      const res = await fetch('/api/records/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: recordsToPost, username: currentUser, replaceExisting })
      });

      const result = await res.json();
      if (result.success) {
        onImportComplete(result.importCount, result.syncCount);
        setParsedRows([]);
        setFileName('');
        setReplaceExisting(false);
      } else {
        alert('Lỗi nhập khẩu: ' + result.message);
      }
    } catch (error) {
      console.error('Import action failed:', error);
      alert('Kết nối máy chủ thất bại khi thực hiện nhập khẩu.');
    } finally {
      setIsProcessing(false);
    }
  };

  const getStats = () => {
    const errorCount = parsedRows.filter(r => r.status === 'error').length;
    const updateCount = parsedRows.filter(r => r.status === 'update').length;
    const newCount = parsedRows.filter(r => r.status === 'new').length;
    return { errorCount, updateCount, newCount };
  };

  const { errorCount, updateCount, newCount } = getStats();

  return (
    <div className="space-y-6">
      {/* Upload Drag & Drop Area */}
      {parsedRows.length === 0 ? (
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={triggerFileSelect}
          className={`flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-10 cursor-pointer transition-colors ${
            dragActive
              ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-slate-300 dark:border-slate-700 hover:border-blue-400 hover:bg-slate-50 dark:hover:bg-slate-850'
          }`}
          id="import-drag-drop"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx, .xls, .csv"
            onChange={handleFileChange}
            className="hidden"
          />
          <Upload className="w-12 h-12 text-slate-400 dark:text-slate-500 mb-4" />
          <p className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">
            Kéo thả tệp dữ liệu vào đây hoặc nhấn để chọn
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-4">
            Chấp nhận định dạng file .xlsx, .xls, .csv. Hệ thống tự nhận diện cột thông minh.
          </p>
          <button className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/30 dark:text-blue-300 rounded-lg transition-colors border border-blue-200 dark:border-blue-900 cursor-pointer">
            Chọn tệp Excel / CSV
          </button>
        </div>
      ) : (
        /* Preview Table & Diagnostic Reports */
        <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          {/* File Name & Import Options Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800 gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg text-emerald-600 dark:text-emerald-400">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-850 dark:text-slate-200 truncate max-w-[300px]">
                  {fileName}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Phát hiện tổng số: <span className="font-bold text-slate-700 dark:text-slate-300">{parsedRows.length}</span> dòng dữ liệu.
                </p>
              </div>
            </div>

            {/* Import Mode Selection */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Chế độ nhập:</span>
              <label className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="importMode"
                  checked={!replaceExisting}
                  onChange={() => setReplaceExisting(false)}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span>Thêm mới / Đồng bộ</span>
              </label>
              <label className="flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-400 font-semibold cursor-pointer">
                <input
                  type="radio"
                  name="importMode"
                  checked={replaceExisting}
                  onChange={() => setReplaceExisting(true)}
                  className="text-amber-600 focus:ring-amber-500"
                />
                <span>Thay thế toàn bộ dữ liệu hiện có</span>
              </label>
            </div>

            {/* Dry Run Statistics Widget */}
            <div className="flex flex-wrap items-center gap-3 text-xs font-semibold">
              <span className="flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300 rounded-full">
                <CheckCircle className="w-3.5 h-3.5 text-blue-500" />
                {newCount} thêm mới
              </span>
              <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300 rounded-full">
                <RefreshCw className="w-3.5 h-3.5 text-amber-500" />
                {updateCount} cập nhật & đồng bộ
              </span>
              <span className="flex items-center gap-1 px-2.5 py-1 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 rounded-full">
                <AlertCircle className="w-3.5 h-3.5 text-red-500" />
                {errorCount} dòng lỗi
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => { setParsedRows([]); setFileName(''); setReplaceExisting(false); }}
                className="px-4 py-2 text-sm font-medium text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 rounded-lg cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmImport}
                disabled={isProcessing || newCount + updateCount === 0}
                className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white ${
                  replaceExisting 
                    ? 'bg-amber-600 hover:bg-amber-700' 
                    : 'bg-emerald-600 hover:bg-emerald-700'
                } disabled:opacity-50 rounded-lg cursor-pointer transition-colors`}
                id="btn-confirm-import"
              >
                {replaceExisting ? 'Thay thế dữ liệu cũ' : 'Xác nhận nhập khẩu'} ({newCount + updateCount})
              </button>
            </div>
          </div>

          {/* Detailed Row List Preview */}
          <div className="overflow-x-auto max-h-[450px]">
            <table className="w-full text-left border-collapse text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold sticky top-0 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="py-3 px-4 w-12 text-center">Dòng</th>
                  <th className="py-3 px-4">Tác vụ</th>
                  <th className="py-3 px-4">Tên công dân, tổ chức</th>
                  <th className="py-3 px-4">Địa chỉ thường trú / trụ sở</th>
                  <th className="py-3 px-4">Số phiếu</th>
                  <th className="py-3 px-4">Mã hồ sơ</th>
                  <th className="py-3 px-4">Chuẩn đoán tệp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {parsedRows.map((row, index) => (
                  <tr 
                    key={index}
                    className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/30 ${
                      row.status === 'error' ? 'bg-red-50/10 dark:bg-red-950/5' : 
                      row.status === 'update' ? 'bg-amber-50/5 dark:bg-amber-950/2' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-center font-mono text-xs text-slate-500">
                      {row.rowNum}
                    </td>
                    <td className="py-3 px-4">
                      {row.status === 'error' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">
                          <AlertCircle className="w-3 h-3" /> Lỗi
                        </span>
                      )}
                      {row.status === 'update' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">
                          <RefreshCw className="w-3.5 h-3.5" /> Đồng bộ
                        </span>
                      )}
                      {row.status === 'new' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300">
                          <CheckCircle className="w-3 h-3" /> Thêm mới
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-850 dark:text-slate-200">
                      {row.data.citizenName || <span className="text-red-500 italic">Thiếu tên</span>}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-700 dark:text-slate-300 max-w-[220px] truncate" title={row.data.address}>
                      {row.data.address || <span className="text-slate-400 italic">Chưa có địa chỉ</span>}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs font-semibold text-blue-700 dark:text-blue-400">
                      {row.data.ticketNo || <span className="text-red-500 italic">Thiếu số phiếu</span>}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-600 dark:text-slate-400">
                      {row.data.recordId || <span className="text-slate-400 italic">Chưa có</span>}
                    </td>
                    <td className="py-3 px-4">
                      {row.status === 'error' ? (
                        <div className="flex flex-col gap-1">
                          {row.errors.map((err, i) => (
                            <span key={i} className="text-xs text-red-600 dark:text-red-400 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" /> {err}
                            </span>
                          ))}
                        </div>
                      ) : row.status === 'update' ? (
                        <span className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1 font-medium">
                          <RefreshCw className="w-3 h-3 animate-spin-slow" /> Trùng khớp phiếu, sẽ cập nhật dữ liệu gốc
                        </span>
                      ) : (
                        <span className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium">
                          <CheckCircle className="w-3 h-3" /> Hồ sơ hợp lệ để tạo mới
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
