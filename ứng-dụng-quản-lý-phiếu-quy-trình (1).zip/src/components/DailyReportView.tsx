import React, { useState, useEffect } from 'react';
import { Officer, DailyReport, DailyReportSection, PaperDossiers, ReportConfig, Record as DossierRecord } from '../types';
import { 
  FileText, Calendar, Clock, CheckCircle2, AlertTriangle, Send, Sliders, Settings, 
  ChevronRight, ArrowRight, Table, PlusCircle, AlertCircle, FileSpreadsheet, Printer, ArrowDown, BarChart3,
  Link, RefreshCw, Zap
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface DailyReportViewProps {
  officers: Officer[];
  currentUser: { id: string; username: string; fullName: string; role: string } | null;
  dailyReports: DailyReport[];
  records?: DossierRecord[];
  reportConfig: ReportConfig;
  onSaveReport: (report: Omit<DailyReport, 'id' | 'reportedAt'>) => Promise<void>;
  onSaveConfig: (config: ReportConfig) => Promise<void>;
  onDeleteReport: (id: string) => Promise<void>;
}

// Helper to check if a time string is within a range
function isTimeBetween(nowStr: string, start: string, end: string): boolean {
  const [nowH, nowM] = nowStr.split(':').map(Number);
  const [startH, startM] = start.split(':').map(Number);
  const [endH, endM] = end.split(':').map(Number);
  
  const nowVal = nowH * 60 + nowM;
  const startVal = startH * 60 + startM;
  const endVal = endH * 60 + endM;
  
  return nowVal >= startVal && nowVal <= endVal;
}

// Blank section creator
const createBlankSection = (): DailyReportSection => ({
  ctBanSao_hoSo: 0,
  ctBanSao_huongDan: 0,
  ctBanSao_ban: 0,
  ctBanSao_tien: 0,
  ctChuKy_hoSo: 0,
  ctChuKy_huongDan: 0,
  ctChuKy_ban: 0,
  ctChuKy_tien: 0,
  hoTich_hoSo: 0,
  hoTich_huongDan: 0,
  hoTich_ban: 0,
  hoTich_tien: 0,
  kinhTe_hoSo: 0,
  kinhTe_huongDan: 0,
  datDaiMoiTruong_hoSo: 0,
  datDaiMoiTruong_huongDan: 0,
  haTangDoThi_hoSo: 0,
  haTangDoThi_huongDan: 0,
  vanHoaXaHoi_hoSo: 0,
  vanHoaXaHoi_huongDan: 0,
  bhYTe_truongHop: 0,
  bhYTe_huongDan: 0,
  bhYTe_tien: 0,
  nganhDoc_thue: 0,
  nganhDoc_thue_huongDan: 0,
  nganhDoc_bhxh: 0,
  nganhDoc_bhxh_huongDan: 0
});

const createBlankPaperDossiers = (): PaperDossiers => ({
  hoTich: 0,
  datDai: 0,
  taiNguyenMoiTruong: 0,
  hoTich2: 0,
  baoTroXaHoi: 0,
  haTangDoThi: 0
});

export default function DailyReportView({
  officers,
  currentUser,
  dailyReports,
  records = [],
  reportConfig,
  onSaveReport,
  onSaveConfig,
  onDeleteReport
}: DailyReportViewProps) {
  // Navigation inside reporting
  const [activeTab, setActiveTab] = useState<'submit' | 'dashboard' | 'period_summary' | 'config'>('dashboard');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Periodic Summary States
  const [periodType, setPeriodType] = useState<'month' | 'quarter' | 'year'>('month');
  const [periodYear, setPeriodYear] = useState<number>(new Date().getFullYear());
  const [periodMonth, setPeriodMonth] = useState<number>(new Date().getMonth() + 1);
  const [periodQuarter, setPeriodQuarter] = useState<number>(Math.floor(new Date().getMonth() / 3) + 1);
  const [auditOfficerFilter, setAuditOfficerFilter] = useState<string>('');
  const [auditStatusFilter, setAuditStatusFilter] = useState<'all' | 'missed'>('all');

  // Filter out leaders (Giám đốc, Phó Giám đốc), keep only Chuyên viên who process dossiers & reports
  const isSpecialist = (o: Officer) => {
    if (!o) return false;
    const roleLower = (o.role || '').toLowerCase();
    if (roleLower.includes('giám đốc') || roleLower.includes('phó giám đốc') || roleLower.includes('lãnh đạo')) {
      return false;
    }
    return true;
  };
  const specialistOfficers = officers.filter(isSpecialist);

  // Submit report states
  const [reportSession, setReportSession] = useState<'morning' | 'afternoon'>('morning');
  const [reportingOfficerId, setReportingOfficerId] = useState<string>('');
  
  // Section states
  const [sectionData, setSectionData] = useState<DailyReportSection>(createBlankSection());
  const [paperDossiers, setPaperDossiers] = useState<PaperDossiers>(createBlankPaperDossiers());
  const [difficulties, setDifficulties] = useState('');
  const [suggestions, setSuggestions] = useState('');

  // Time state to verify constraint
  const [currentTime, setCurrentTime] = useState('');
  const [forceSubmit, setForceSubmit] = useState(false);

  // Config form states
  const [cfgMorningStart, setCfgMorningStart] = useState(reportConfig.morningStart);
  const [cfgMorningEnd, setCfgMorningEnd] = useState(reportConfig.morningEnd);
  const [cfgAfternoonStart, setCfgAfternoonStart] = useState(reportConfig.afternoonStart);
  const [cfgAfternoonEnd, setCfgAfternoonEnd] = useState(reportConfig.afternoonEnd);

  // Sync config form with props
  useEffect(() => {
    setCfgMorningStart(reportConfig.morningStart);
    setCfgMorningEnd(reportConfig.morningEnd);
    setCfgAfternoonStart(reportConfig.afternoonStart);
    setCfgAfternoonEnd(reportConfig.afternoonEnd);
  }, [reportConfig]);

  // Auto detect which officer is logged in and prefill
  useEffect(() => {
    if (currentUser && currentUser.role === 'officer') {
      const off = specialistOfficers.find(o => o.name === currentUser.fullName);
      if (off) {
        setReportingOfficerId(off.id);
      }
    } else if (specialistOfficers.length > 0) {
      setReportingOfficerId(specialistOfficers[0].id);
    }
  }, [currentUser, officers]);

  // Update current clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const H = String(now.getHours()).padStart(2, '0');
      const M = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${H}:${M}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 1000 * 30);
    return () => clearInterval(timer);
  }, []);

  // Time check details
  const isMorningWindow = isTimeBetween(currentTime, reportConfig.morningStart, reportConfig.morningEnd);
  const isAfternoonWindow = isTimeBetween(currentTime, reportConfig.afternoonStart, reportConfig.afternoonEnd);
  const canReportNow = isMorningWindow || isAfternoonWindow;
  
  // Check if current selected session is within its allowed time window
  const isCurrentSessionAllowed = (reportSession === 'morning' ? isMorningWindow : isAfternoonWindow) || (currentUser?.role === 'admin' || forceSubmit);

  const currentWindowLabel = isMorningWindow 
    ? `Buổi Sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd})` 
    : isAfternoonWindow 
      ? `Buổi Chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd})` 
      : `Ngoài khung giờ báo cáo (Quy định: Sáng ${reportConfig.morningStart}-${reportConfig.morningEnd}, Chiều ${reportConfig.afternoonStart}-${reportConfig.afternoonEnd})`;

  // Automatically select session based on current time window when window changes
  useEffect(() => {
    if (isMorningWindow) {
      setReportSession('morning');
    } else if (isAfternoonWindow) {
      setReportSession('afternoon');
    }
  }, [isMorningWindow, isAfternoonWindow]);

  // Handler for officer selecting/editing report from Dashboard
  const handleEditReport = (officerId: string, session: 'morning' | 'afternoon' | 'all_day') => {
    const targetSession = session === 'afternoon' ? 'afternoon' : 'morning';
    const isSessionAllowed = (targetSession === 'morning' && isMorningWindow) || (targetSession === 'afternoon' && isAfternoonWindow);
    
    if (!isSessionAllowed && currentUser?.role !== 'admin' && !forceSubmit) {
      if (targetSession === 'morning' && isAfternoonWindow) {
        alert(`⛔ KHÔNG THỂ CHỈNH SỬA BÁO CÁO BUỔI SÁNG:\nHiện tại đang là Khung giờ Buổi Chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd}).\nTheo quy định, Báo cáo Buổi Sáng chỉ được nhập/chỉnh sửa trong khung giờ buổi sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd}). Buổi chiều không thể nhập hay sửa lại báo cáo buổi sáng!`);
      } else if (targetSession === 'afternoon' && isMorningWindow) {
        alert(`⛔ KHÔNG THỂ CHỈNH SỬA BÁO CÁO BUỔI CHIỀU:\nHiện tại đang là Khung giờ Buổi Sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd}).\nTheo quy định, Báo cáo Buổi Chiều chỉ được nhập/chỉnh sửa trong khung giờ buổi chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd})!`);
      } else {
        alert(`⛔ NGOÀI KHUNG GIỜ QUY ĐỊNH:\nHiện tại đang ngoài khung giờ nhập báo cáo quy định (Sáng: ${reportConfig.morningStart}-${reportConfig.morningEnd}, Chiều: ${reportConfig.afternoonStart}-${reportConfig.afternoonEnd}).\nChuyên viên không thể nhập hoặc chỉnh sửa báo cáo ngoài giờ.`);
      }
      return;
    }

    setReportingOfficerId(officerId);
    setReportSession(targetSession);
    setActiveTab('submit');
  };

  // Handler for session select dropdown change with window check
  const handleSessionChange = (newSession: 'morning' | 'afternoon') => {
    const isAllowed = (newSession === 'morning' && isMorningWindow) || (newSession === 'afternoon' && isAfternoonWindow);
    if (!isAllowed && currentUser?.role !== 'admin' && !forceSubmit) {
      if (newSession === 'morning' && isAfternoonWindow) {
        alert(`⛔ QUY ĐỊNH KHUNG GIỜ BÁO CÁO:\nHiện tại đang trong Khung giờ Buổi Chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd}).\nChuyên viên chỉ được nhập/chỉnh sửa báo cáo Buổi Chiều. Báo cáo Buổi Sáng chỉ được làm vào buổi sáng!`);
      } else if (newSession === 'afternoon' && isMorningWindow) {
        alert(`⛔ QUY ĐỊNH KHUNG GIỜ BÁO CÁO:\nHiện tại đang trong Khung giờ Buổi Sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd}).\nChuyên viên chỉ được nhập/chỉnh sửa báo cáo Buổi Sáng. Báo cáo Buổi Chiều chỉ được làm vào buổi chiều!`);
      } else {
        alert(`⛔ NGOÀI KHUNG GIỜ QUY ĐỊNH:\nSáng (${reportConfig.morningStart}-${reportConfig.morningEnd}), Chiều (${reportConfig.afternoonStart}-${reportConfig.afternoonEnd}).`);
      }
      return;
    }
    setReportSession(newSession);
  };

  // Load existing data if officer has already reported for this date
  useEffect(() => {
    if (!reportingOfficerId) return;
    const existing = dailyReports.find(r => 
      r.date === selectedDate && 
      r.officerId === reportingOfficerId
    );

    if (existing) {
      const data = reportSession === 'morning' ? existing.morning : existing.afternoon;
      setSectionData(data || createBlankSection());
      if (existing.paperDossiers) setPaperDossiers(existing.paperDossiers);
      setDifficulties(existing.difficulties || '');
      setSuggestions(existing.suggestions || '');
    } else {
      setSectionData(createBlankSection());
      setPaperDossiers(createBlankPaperDossiers());
      setDifficulties('');
      setSuggestions('');
    }
  }, [selectedDate, reportingOfficerId, reportSession, dailyReports]);

  // Submit report action
  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportingOfficerId) {
      alert('Vui lòng chọn hoặc xác định cán bộ báo cáo!');
      return;
    }

    // Time window enforcement for current session
    if (!isCurrentSessionAllowed) {
      if (reportSession === 'morning' && isAfternoonWindow) {
        alert(`⛔ KHÔNG THỂ NỘP BÁO CÁO BUỔI SÁNG LÚC NÀY:\nHiện tại đang là Khung giờ Buổi Chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd}).\nBáo cáo Buổi Sáng chỉ được nộp/chỉnh sửa trong khung giờ buổi sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd}). Buổi chiều không được nhập lại báo cáo buổi sáng!`);
      } else if (reportSession === 'afternoon' && isMorningWindow) {
        alert(`⛔ KHÔNG THỂ NỘP BÁO CÁO BUỔI CHIỀU LÚC NÀY:\nHiện tại đang là Khung giờ Buổi Sáng (${reportConfig.morningStart} - ${reportConfig.morningEnd}).\nBáo cáo Buổi Chiều chỉ được nộp/chỉnh sửa trong khung giờ buổi chiều (${reportConfig.afternoonStart} - ${reportConfig.afternoonEnd})!`);
      } else {
        alert(`⛔ NGOÀI KHUNG GIỜ QUY ĐỊNH:\nHiện tại đang ngoài khung giờ báo cáo quy định (Sáng: ${reportConfig.morningStart}-${reportConfig.morningEnd}, Chiều: ${reportConfig.afternoonStart}-${reportConfig.afternoonEnd}).\nBạn không thể nộp hoặc chỉnh sửa báo cáo ngoài giờ.`);
      }
      return;
    }

    const off = officers.find(o => o.id === reportingOfficerId);
    if (!off) return;

    if (!isSpecialist(off)) {
      alert('Chỉ chuyên viên Trung tâm mới được yêu cầu báo cáo!');
      return;
    }

    // Create a complete daily report payload
    // Search if there is already a general DailyReport object for this date and officer
    const existingReport = dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId);
    
    // Explicitly construct morning and afternoon sections
    const morningData = reportSession === 'morning' ? sectionData : existingReport?.morning;
    const afternoonData = reportSession === 'afternoon' ? sectionData : existingReport?.afternoon;

    const payload: Omit<DailyReport, 'id' | 'reportedAt'> = {
      date: selectedDate,
      officerId: reportingOfficerId,
      officerName: off.name,
      session: reportSession,
      morning: morningData,
      afternoon: afternoonData,
      paperDossiers: paperDossiers,
      difficulties: difficulties.trim() || existingReport?.difficulties || '',
      suggestions: suggestions.trim() || existingReport?.suggestions || ''
    };

    try {
      await onSaveReport(payload);
      alert(`Nộp báo cáo ${reportSession === 'morning' ? 'Buổi sáng' : 'Buổi chiều'} ngày ${selectedDate} thành công!`);
      setActiveTab('dashboard');
    } catch (err) {
      console.error(err);
      alert('Không thể lưu báo cáo, vui lòng liên hệ hệ thống.');
    }
  };

  // Submit config action
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onSaveConfig({
        morningStart: cfgMorningStart,
        morningEnd: cfgMorningEnd,
        afternoonStart: cfgAfternoonStart,
        afternoonEnd: cfgAfternoonEnd
      });
      alert('Cập nhật khung giờ báo cáo hành chính thành công!');
      setActiveTab('dashboard');
    } catch (err) {
      console.error(err);
      alert('Không thể cập nhật cấu hình.');
    }
  };

  // Statistics Calculation for selected date (only include specialists)
  const reportsForDate = dailyReports.filter(r => {
    if (r.date !== selectedDate) return false;
    const off = officers.find(o => o.id === r.officerId);
    return !!(off && isSpecialist(off));
  });
  
  // Status lists of specialist officers reporting status today
  const reportingStatusList = specialistOfficers.map(o => {
    const mReport = reportsForDate.find(r => r.officerId === o.id && r.morning);
    const aReport = reportsForDate.find(r => r.officerId === o.id && r.afternoon);
    return {
      officer: o,
      morningSubmitted: !!mReport,
      morningTime: mReport ? new Date(mReport.reportedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '',
      afternoonSubmitted: !!aReport,
      afternoonTime: aReport ? new Date(aReport.reportedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : ''
    };
  });

  const reportedOfficersCount = reportingStatusList.filter(s => s.morningSubmitted || s.afternoonSubmitted).length;
  const unsubmittedCount = specialistOfficers.length - reportedOfficersCount;

  // Combine and aggregate all reports of the selected date to create the master table
  const combinedMorning = createBlankSection();
  const combinedAfternoon = createBlankSection();
  const combinedPaperDossiers = createBlankPaperDossiers();

  reportsForDate.forEach(r => {
    if (r.morning) {
      Object.keys(r.morning).forEach(key => {
        const k = key as keyof DailyReportSection;
        combinedMorning[k] = (combinedMorning[k] || 0) + (r.morning[k] || 0);
      });
    }
    if (r.afternoon) {
      Object.keys(r.afternoon).forEach(key => {
        const k = key as keyof DailyReportSection;
        combinedAfternoon[k] = (combinedAfternoon[k] || 0) + (r.afternoon[k] || 0);
      });
    }
    if (r.paperDossiers) {
      Object.keys(r.paperDossiers).forEach(key => {
        const k = key as keyof PaperDossiers;
        combinedPaperDossiers[k] = (combinedPaperDossiers[k] || 0) + (r.paperDossiers[k] || 0);
      });
    }
  });

  // Calculate sum total of dossiers
  const morningTotalDossiers = 
    combinedMorning.ctBanSao_hoSo + 
    combinedMorning.ctChuKy_hoSo + 
    combinedMorning.hoTich_hoSo + 
    combinedMorning.kinhTe_hoSo + 
    combinedMorning.datDaiMoiTruong_hoSo + 
    combinedMorning.haTangDoThi_hoSo + 
    combinedMorning.vanHoaXaHoi_hoSo + 
    combinedMorning.bhYTe_truongHop;

  const morningTotalGuided = 
    (combinedMorning.ctBanSao_huongDan || 0) + 
    (combinedMorning.ctChuKy_huongDan || 0) + 
    (combinedMorning.hoTich_huongDan || 0) + 
    (combinedMorning.kinhTe_huongDan || 0) + 
    (combinedMorning.datDaiMoiTruong_huongDan || 0) + 
    (combinedMorning.haTangDoThi_huongDan || 0) + 
    (combinedMorning.vanHoaXaHoi_huongDan || 0) + 
    (combinedMorning.bhYTe_huongDan || 0) +
    (combinedMorning.nganhDoc_thue_huongDan || 0) +
    (combinedMorning.nganhDoc_bhxh_huongDan || 0);

  const afternoonTotalDossiers = 
    combinedAfternoon.ctBanSao_hoSo + 
    combinedAfternoon.ctChuKy_hoSo + 
    combinedAfternoon.hoTich_hoSo + 
    combinedAfternoon.kinhTe_hoSo + 
    combinedAfternoon.datDaiMoiTruong_hoSo + 
    combinedAfternoon.haTangDoThi_hoSo + 
    combinedAfternoon.vanHoaXaHoi_hoSo + 
    combinedAfternoon.bhYTe_truongHop;

  const afternoonTotalGuided = 
    (combinedAfternoon.ctBanSao_huongDan || 0) + 
    (combinedAfternoon.ctChuKy_huongDan || 0) + 
    (combinedAfternoon.hoTich_huongDan || 0) + 
    (combinedAfternoon.kinhTe_huongDan || 0) + 
    (combinedAfternoon.datDaiMoiTruong_huongDan || 0) + 
    (combinedAfternoon.haTangDoThi_huongDan || 0) + 
    (combinedAfternoon.vanHoaXaHoi_huongDan || 0) + 
    (combinedAfternoon.bhYTe_huongDan || 0) +
    (combinedAfternoon.nganhDoc_thue_huongDan || 0) +
    (combinedAfternoon.nganhDoc_bhxh_huongDan || 0);

  // Combined difficult comments
  const feedbackList = reportsForDate.map(r => ({
    officerName: r.officerName,
    difficulties: r.difficulties,
    suggestions: r.suggestions
  })).filter(f => f.difficulties || f.suggestions);

  // Export Combined Report to Excel
  const exportMasterReportToExcel = () => {
    // 1. Detailed records
    const detailedRecords = [
      { 'Chỉ tiêu': '1. Chứng thực bản sao (Số HS nhận)', 'Buổi sáng': combinedMorning.ctBanSao_hoSo, 'Buổi chiều': combinedAfternoon.ctBanSao_hoSo, 'Cả ngày': combinedMorning.ctBanSao_hoSo + combinedAfternoon.ctBanSao_hoSo },
      { 'Chỉ tiêu': '1. Chứng thực bản sao (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.ctBanSao_huongDan || 0, 'Buổi chiều': combinedAfternoon.ctBanSao_huongDan || 0, 'Cả ngày': (combinedMorning.ctBanSao_huongDan || 0) + (combinedAfternoon.ctBanSao_huongDan || 0) },
      { 'Chỉ tiêu': '1. Chứng thực bản sao (Số bản)', 'Buổi sáng': combinedMorning.ctBanSao_ban, 'Buổi chiều': combinedAfternoon.ctBanSao_ban, 'Cả ngày': combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban },
      { 'Chỉ tiêu': '1. Chứng thực bản sao (Lệ phí tiền)', 'Buổi sáng': combinedMorning.ctBanSao_tien, 'Buổi chiều': combinedAfternoon.ctBanSao_tien, 'Cả ngày': combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien },
      
      { 'Chỉ tiêu': '2. Chứng thực chữ ký (Số HS nhận)', 'Buổi sáng': combinedMorning.ctChuKy_hoSo, 'Buổi chiều': combinedAfternoon.ctChuKy_hoSo, 'Cả ngày': combinedMorning.ctChuKy_hoSo + combinedAfternoon.ctChuKy_hoSo },
      { 'Chỉ tiêu': '2. Chứng thực chữ ký (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.ctChuKy_huongDan || 0, 'Buổi chiều': combinedAfternoon.ctChuKy_huongDan || 0, 'Cả ngày': (combinedMorning.ctChuKy_huongDan || 0) + (combinedAfternoon.ctChuKy_huongDan || 0) },
      { 'Chỉ tiêu': '2. Chứng thực chữ ký (Số bản)', 'Buổi sáng': combinedMorning.ctChuKy_ban, 'Buổi chiều': combinedAfternoon.ctChuKy_ban, 'Cả ngày': combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban },
      { 'Chỉ tiêu': '2. Chứng thực chữ ký (Lệ phí tiền)', 'Buổi sáng': combinedMorning.ctChuKy_tien, 'Buổi chiều': combinedAfternoon.ctChuKy_tien, 'Cả ngày': combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien },

      { 'Chỉ tiêu': '3. Hộ tịch (Số HS nhận)', 'Buổi sáng': combinedMorning.hoTich_hoSo, 'Buổi chiều': combinedAfternoon.hoTich_hoSo, 'Cả ngày': combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo },
      { 'Chỉ tiêu': '3. Hộ tịch (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.hoTich_huongDan || 0, 'Buổi chiều': combinedAfternoon.hoTich_huongDan || 0, 'Cả ngày': (combinedMorning.hoTich_huongDan || 0) + (combinedAfternoon.hoTich_huongDan || 0) },
      { 'Chỉ tiêu': '3. Hộ tịch (Lệ phí tiền)', 'Buổi sáng': combinedMorning.hoTich_tien, 'Buổi chiều': combinedAfternoon.hoTich_tien, 'Cả ngày': combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien },

      { 'Chỉ tiêu': '4. Kinh tế (Số HS nhận)', 'Buổi sáng': combinedMorning.kinhTe_hoSo, 'Buổi chiều': combinedAfternoon.kinhTe_hoSo, 'Cả ngày': combinedMorning.kinhTe_hoSo + combinedAfternoon.kinhTe_hoSo },
      { 'Chỉ tiêu': '4. Kinh tế (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.kinhTe_huongDan || 0, 'Buổi chiều': combinedAfternoon.kinhTe_huongDan || 0, 'Cả ngày': (combinedMorning.kinhTe_huongDan || 0) + (combinedAfternoon.kinhTe_huongDan || 0) },

      { 'Chỉ tiêu': '5. Đất đai - Môi trường (Số HS nhận)', 'Buổi sáng': combinedMorning.datDaiMoiTruong_hoSo, 'Buổi chiều': combinedAfternoon.datDaiMoiTruong_hoSo, 'Cả ngày': combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo },
      { 'Chỉ tiêu': '5. Đất đai - Môi trường (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.datDaiMoiTruong_huongDan || 0, 'Buổi chiều': combinedAfternoon.datDaiMoiTruong_huongDan || 0, 'Cả ngày': (combinedMorning.datDaiMoiTruong_huongDan || 0) + (combinedAfternoon.datDaiMoiTruong_huongDan || 0) },

      { 'Chỉ tiêu': '6. Hạ tầng - Đô thị (Số HS nhận)', 'Buổi sáng': combinedMorning.haTangDoThi_hoSo, 'Buổi chiều': combinedAfternoon.haTangDoThi_hoSo, 'Cả ngày': combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo },
      { 'Chỉ tiêu': '6. Hạ tầng - Đô thị (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.haTangDoThi_huongDan || 0, 'Buổi chiều': combinedAfternoon.haTangDoThi_huongDan || 0, 'Cả ngày': (combinedMorning.haTangDoThi_huongDan || 0) + (combinedAfternoon.haTangDoThi_huongDan || 0) },

      { 'Chỉ tiêu': '7. Văn hóa - Xã hội (Số HS nhận)', 'Buổi sáng': combinedMorning.vanHoaXaHoi_hoSo, 'Buổi chiều': combinedAfternoon.vanHoaXaHoi_hoSo, 'Cả ngày': combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo },
      { 'Chỉ tiêu': '7. Văn hóa - Xã hội (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.vanHoaXaHoi_huongDan || 0, 'Buổi chiều': combinedAfternoon.vanHoaXaHoi_huongDan || 0, 'Cả ngày': (combinedMorning.vanHoaXaHoi_huongDan || 0) + (combinedAfternoon.vanHoaXaHoi_huongDan || 0) },
      
      { 'Chỉ tiêu': '8. Bảo hiểm y tế (Số trường hợp)', 'Buổi sáng': combinedMorning.bhYTe_truongHop, 'Buổi chiều': combinedAfternoon.bhYTe_truongHop, 'Cả ngày': combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop },
      { 'Chỉ tiêu': '8. Bảo hiểm y tế (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.bhYTe_huongDan || 0, 'Buổi chiều': combinedAfternoon.bhYTe_huongDan || 0, 'Cả ngày': (combinedMorning.bhYTe_huongDan || 0) + (combinedAfternoon.bhYTe_huongDan || 0) },
      { 'Chỉ tiêu': '8. Bảo hiểm y tế (Số tiền đóng)', 'Buổi sáng': combinedMorning.bhYTe_tien, 'Buổi chiều': combinedAfternoon.bhYTe_tien, 'Cả ngày': combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien },

      { 'Chỉ tiêu': '9. Thuế ngành dọc (Số HS nhận)', 'Buổi sáng': combinedMorning.nganhDoc_thue, 'Buổi chiều': combinedAfternoon.nganhDoc_thue, 'Cả ngày': combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue },
      { 'Chỉ tiêu': '9. Thuế ngành dọc (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.nganhDoc_thue_huongDan || 0, 'Buổi chiều': combinedAfternoon.nganhDoc_thue_huongDan || 0, 'Cả ngày': (combinedMorning.nganhDoc_thue_huongDan || 0) + (combinedAfternoon.nganhDoc_thue_huongDan || 0) },

      { 'Chỉ tiêu': '10. BHXH ngành dọc (Số HS nhận)', 'Buổi sáng': combinedMorning.nganhDoc_bhxh, 'Buổi chiều': combinedAfternoon.nganhDoc_bhxh, 'Cả ngày': combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh },
      { 'Chỉ tiêu': '10. BHXH ngành dọc (Số HS hướng dẫn)', 'Buổi sáng': combinedMorning.nganhDoc_bhxh_huongDan || 0, 'Buổi chiều': combinedAfternoon.nganhDoc_bhxh_huongDan || 0, 'Cả ngày': (combinedMorning.nganhDoc_bhxh_huongDan || 0) + (combinedAfternoon.nganhDoc_bhxh_huongDan || 0) }
    ];

    const wsDetailed = XLSX.utils.json_to_sheet([]);
    XLSX.utils.sheet_add_aoa(wsDetailed, [
      ['BÁO CÁO THỐNG KÊ KẾT QUẢ TIẾP NHẬN HỒ SƠ HÀNG NGÀY'],
      [`Ngày báo cáo: ${selectedDate}`],
      ['Trung tâm Phục vụ Hành chính công Phường Cầu Kiệu - TP. Hồ Chí Minh'],
      [''],
    ], { origin: 'A1' });
    XLSX.utils.sheet_add_json(wsDetailed, detailedRecords, { origin: 'A5', skipHeader: false });

    // 2. Summary by specific sector / field
    const totalFeesCollected = (combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien) +
                               (combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien) +
                               (combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien) +
                               (combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien);

    const sectorSummaryRecords = [
      {
        'STT': 1,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Chứng thực (Bản sao & Chữ ký)',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.ctBanSao_hoSo + combinedAfternoon.ctBanSao_hoSo) + (combinedMorning.ctChuKy_hoSo + combinedAfternoon.ctChuKy_hoSo),
        'Số hồ sơ hướng dẫn': (combinedMorning.ctBanSao_huongDan || 0) + (combinedAfternoon.ctBanSao_huongDan || 0) + (combinedMorning.ctChuKy_huongDan || 0) + (combinedAfternoon.ctChuKy_huongDan || 0),
        'Số bản / Số trường hợp': (combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban) + (combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban),
        'Tổng Lệ phí / Thu hộ (VNĐ)': (combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien) + (combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien),
        'Ghi chú': 'Bao gồm Chứng thực bản sao từ bản chính & Chứng thực chữ ký'
      },
      {
        'STT': 2,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Hộ tịch',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo) + combinedPaperDossiers.hoTich + combinedPaperDossiers.hoTich2,
        'Số hồ sơ hướng dẫn': (combinedMorning.hoTich_huongDan || 0) + (combinedAfternoon.hoTich_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien,
        'Ghi chú': `Gồm ${combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo} HS điện tử + ${combinedPaperDossiers.hoTich + combinedPaperDossiers.hoTich2} HS giấy`
      },
      {
        'STT': 3,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Kinh tế',
        'Tổng số hồ sơ tiếp nhận': combinedMorning.kinhTe_hoSo + combinedAfternoon.kinhTe_hoSo,
        'Số hồ sơ hướng dẫn': (combinedMorning.kinhTe_huongDan || 0) + (combinedAfternoon.kinhTe_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': 0,
        'Ghi chú': 'Hồ sơ đăng ký kinh doanh & hộ kinh doanh'
      },
      {
        'STT': 4,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Đất đai - Môi trường',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo) + combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong,
        'Số hồ sơ hướng dẫn': (combinedMorning.datDaiMoiTruong_huongDan || 0) + (combinedAfternoon.datDaiMoiTruong_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': 0,
        'Ghi chú': `Gồm ${combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo} HS điện tử + ${combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong} HS giấy`
      },
      {
        'STT': 5,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Hạ tầng - Đô thị',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo) + combinedPaperDossiers.haTangDoThi,
        'Số hồ sơ hướng dẫn': (combinedMorning.haTangDoThi_huongDan || 0) + (combinedAfternoon.haTangDoThi_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': 0,
        'Ghi chú': `Gồm ${combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo} HS điện tử + ${combinedPaperDossiers.haTangDoThi} HS giấy`
      },
      {
        'STT': 6,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Văn hóa - Xã hội & BTXH',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo) + combinedPaperDossiers.baoTroXaHoi,
        'Số hồ sơ hướng dẫn': (combinedMorning.vanHoaXaHoi_huongDan || 0) + (combinedAfternoon.vanHoaXaHoi_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': 0,
        'Ghi chú': `Gồm ${combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo} HS VH-XH + ${combinedPaperDossiers.baoTroXaHoi} HS Bảo trợ XH`
      },
      {
        'STT': 7,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Bảo hiểm Y tế (BHYT)',
        'Tổng số hồ sơ tiếp nhận': combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop,
        'Số hồ sơ hướng dẫn': (combinedMorning.bhYTe_huongDan || 0) + (combinedAfternoon.bhYTe_huongDan || 0),
        'Số bản / Số trường hợp': combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop,
        'Tổng Lệ phí / Thu hộ (VNĐ)': combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien,
        'Ghi chú': 'Thu hộ tiền đóng BHYT tự nguyện / Hộ gia đình'
      },
      {
        'STT': 8,
        'Lĩnh vực Cụ thể': 'Lĩnh vực Ngành dọc Liên thông (Thuế & BHXH)',
        'Tổng số hồ sơ tiếp nhận': (combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue) + (combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh),
        'Số hồ sơ hướng dẫn': (combinedMorning.nganhDoc_thue_huongDan || 0) + (combinedAfternoon.nganhDoc_thue_huongDan || 0) + (combinedMorning.nganhDoc_bhxh_huongDan || 0) + (combinedAfternoon.nganhDoc_bhxh_huongDan || 0),
        'Số bản / Số trường hợp': '—',
        'Tổng Lệ phí / Thu hộ (VNĐ)': 0,
        'Ghi chú': `Thuế: ${combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue} HS | BHXH: ${combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh} HS`
      },
      {
        'STT': 'CỘNG',
        'Lĩnh vực Cụ thể': 'TỔNG CỘNG TOÀN BỘ CÁC LĨNH VỰC',
        'Tổng số hồ sơ tiếp nhận': morningTotalDossiers + afternoonTotalDossiers + combinedPaperDossiers.hoTich + combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong + combinedPaperDossiers.hoTich2 + combinedPaperDossiers.baoTroXaHoi + combinedPaperDossiers.haTangDoThi,
        'Số hồ sơ hướng dẫn': morningTotalGuided + afternoonTotalGuided,
        'Số bản / Số trường hợp': (combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban) + (combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban) + (combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop),
        'Tổng Lệ phí / Thu hộ (VNĐ)': totalFeesCollected,
        'Ghi chú': 'Tổng hợp điện tử & giấy trực tiếp toàn bộ quầy'
      }
    ];

    const wsSectorSummary = XLSX.utils.json_to_sheet([]);
    XLSX.utils.sheet_add_aoa(wsSectorSummary, [
      ['BẢNG TỔNG HỢP KẾT QUẢ TIẾP NHẬN THEO TỪNG LĨNH VỰC CỤ THỂ'],
      [`Ngày báo cáo: ${selectedDate}`],
      ['Trung tâm Phục vụ Hành chính công Phường Cầu Kiệu - TP. Hồ Chí Minh'],
      [''],
    ], { origin: 'A1' });
    XLSX.utils.sheet_add_json(wsSectorSummary, sectorSummaryRecords, { origin: 'A5', skipHeader: false });

    // 3. Paper dossier records
    const paperRecords = [
      { 'Lĩnh vực': 'Hộ tịch', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.hoTich },
      { 'Lĩnh vực': 'Đất đai', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.datDai },
      { 'Lĩnh vực': 'Tài nguyên - Môi trường', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.taiNguyenMoiTruong },
      { 'Lĩnh vực': 'Tư pháp', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.hoTich2 },
      { 'Lĩnh vực': 'Bảo trợ xã hội', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.baoTroXaHoi },
      { 'Lĩnh vực': 'Hạ tầng - Đô thị', 'Số hồ sơ tiếp nhận trực tiếp (Giấy)': combinedPaperDossiers.haTangDoThi },
    ];

    const wsPaper = XLSX.utils.json_to_sheet(paperRecords);

    // 4. Difficulties, Proposals & Solutions
    const feedbackRecords = reportsForDate.map((r, i) => ({
      'STT': i + 1,
      'Cán bộ / Chuyên viên báo cáo': r.officerName,
      'Phiên làm việc': r.session === 'morning' ? 'Buổi Sáng' : 'Buổi Chiều',
      'Khó khăn, vướng mắc phát sinh trong ngày': r.difficulties || 'Không có phát sinh khó khăn, vướng mắc',
      'Đề xuất, kiến nghị & Giải pháp cụ thể': r.suggestions || 'Không có đề xuất, giải pháp bổ sung',
      'Thời điểm gửi báo cáo': r.reportedAt ? new Date(r.reportedAt).toLocaleString('vi-VN') : selectedDate
    }));

    if (feedbackRecords.length === 0) {
      feedbackRecords.push({
        'STT': 1,
        'Cán bộ / Chuyên viên báo cáo': 'Tất cả chuyên viên',
        'Phiên làm việc': 'Cả ngày',
        'Khó khăn, vướng mắc phát sinh trong ngày': 'Không có phát sinh khó khăn, vướng mắc trong ngày.',
        'Đề xuất, kiến nghị & Giải pháp cụ thể': 'Tình hình tiếp nhận hồ sơ diễn ra thuận lợi, ổn định.',
        'Thời điểm gửi báo cáo': selectedDate
      });
    }

    const wsFeedback = XLSX.utils.json_to_sheet([]);
    XLSX.utils.sheet_add_aoa(wsFeedback, [
      ['BẢNG TỔNG HỢP KHÓ KHĂN, VƯỚNG MẮC, ĐỀ XUẤT, KIẾN NGHỊ VÀ GIẢI PHÁP CỤ THỂ TRONG NGÀY'],
      [`Ngày báo cáo: ${selectedDate}`],
      ['Trung tâm Phục vụ Hành chính công Phường Cầu Kiệu - TP. Hồ Chí Minh'],
      [''],
    ], { origin: 'A1' });
    XLSX.utils.sheet_add_json(wsFeedback, feedbackRecords, { origin: 'A5', skipHeader: false });

    // Workbook construction
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsSectorSummary, 'Tổng hợp Từng Lĩnh Vực');
    XLSX.utils.book_append_sheet(wb, wsDetailed, 'Thống kê Chi tiết');
    XLSX.utils.book_append_sheet(wb, wsPaper, 'Hồ sơ Giấy Trực tiếp');
    XLSX.utils.book_append_sheet(wb, wsFeedback, 'Khó khăn & Giải pháp');

    wsDetailed['!cols'] = [{ wch: 38 }, { wch: 15 }, { wch: 15 }, { wch: 15 }];
    wsSectorSummary['!cols'] = [{ wch: 6 }, { wch: 38 }, { wch: 22 }, { wch: 22 }, { wch: 25 }, { wch: 45 }];
    wsPaper['!cols'] = [{ wch: 30 }, { wch: 35 }];
    wsFeedback['!cols'] = [{ wch: 6 }, { wch: 25 }, { wch: 15 }, { wch: 45 }, { wch: 45 }, { wch: 20 }];

    XLSX.writeFile(wb, `Bao_cao_tong_hop_${selectedDate}_Cau_Kieu.xlsx`);
  };

  const handlePrint = () => {
    window.print();
  };

  // --- PERIODIC SUMMARY CALCULATIONS (Tháng / Quý / Năm) ---
  const getPeriodDateRange = () => {
    let start = '';
    let end = '';
    let label = '';

    if (periodType === 'month') {
      const monthStr = String(periodMonth).padStart(2, '0');
      start = `${periodYear}-${monthStr}-01`;
      const lastDay = new Date(periodYear, periodMonth, 0).getDate();
      end = `${periodYear}-${monthStr}-${String(lastDay).padStart(2, '0')}`;
      label = `Tháng ${periodMonth}/${periodYear}`;
    } else if (periodType === 'quarter') {
      const qStartMonth = (periodQuarter - 1) * 3 + 1;
      const qEndMonth = periodQuarter * 3;
      const startStr = String(qStartMonth).padStart(2, '0');
      const endStr = String(qEndMonth).padStart(2, '0');
      start = `${periodYear}-${startStr}-01`;
      const lastDay = new Date(periodYear, qEndMonth, 0).getDate();
      end = `${periodYear}-${endStr}-${String(lastDay).padStart(2, '0')}`;
      label = `Quý ${periodQuarter}/${periodYear}`;
    } else {
      start = `${periodYear}-01-01`;
      end = `${periodYear}-12-31`;
      label = `Năm ${periodYear}`;
    }

    return { start, end, label };
  };

  const { start: pStart, end: pEnd, label: pLabel } = getPeriodDateRange();

  // Filter specialist reports in period date range
  const periodReports = dailyReports.filter(r => {
    if (r.date < pStart || r.date > pEnd) return false;
    const off = officers.find(o => o.id === r.officerId);
    return !!(off && isSpecialist(off));
  });

  // Aggregate sector metrics for period
  const periodTotals = periodReports.reduce((acc, r) => {
    const m = r.morning;
    const a = r.afternoon;
    const p = r.paperDossiers;

    if (m) {
      acc.ctBanSao_hoSo += m.ctBanSao_hoSo || 0;
      acc.ctBanSao_huongDan += m.ctBanSao_huongDan || 0;
      acc.ctBanSao_ban += m.ctBanSao_ban || 0;
      acc.ctBanSao_tien += m.ctBanSao_tien || 0;

      acc.ctChuKy_hoSo += m.ctChuKy_hoSo || 0;
      acc.ctChuKy_huongDan += m.ctChuKy_huongDan || 0;
      acc.ctChuKy_ban += m.ctChuKy_ban || 0;
      acc.ctChuKy_tien += m.ctChuKy_tien || 0;

      acc.hoTich_hoSo += m.hoTich_hoSo || 0;
      acc.hoTich_huongDan += m.hoTich_huongDan || 0;
      acc.hoTich_tien += m.hoTich_tien || 0;

      acc.kinhTe_hoSo += m.kinhTe_hoSo || 0;
      acc.kinhTe_huongDan += m.kinhTe_huongDan || 0;

      acc.datDaiMoiTruong_hoSo += m.datDaiMoiTruong_hoSo || 0;
      acc.datDaiMoiTruong_huongDan += m.datDaiMoiTruong_huongDan || 0;

      acc.haTangDoThi_hoSo += m.haTangDoThi_hoSo || 0;
      acc.haTangDoThi_huongDan += m.haTangDoThi_huongDan || 0;

      acc.vanHoaXaHoi_hoSo += m.vanHoaXaHoi_hoSo || 0;
      acc.vanHoaXaHoi_huongDan += m.vanHoaXaHoi_huongDan || 0;

      acc.bhYTe_truongHop += m.bhYTe_truongHop || 0;
      acc.bhYTe_huongDan += m.bhYTe_huongDan || 0;
      acc.bhYTe_tien += m.bhYTe_tien || 0;

      acc.nganhDoc_thue += m.nganhDoc_thue || 0;
      acc.nganhDoc_thue_huongDan += m.nganhDoc_thue_huongDan || 0;
      acc.nganhDoc_bhxh += m.nganhDoc_bhxh || 0;
      acc.nganhDoc_bhxh_huongDan += m.nganhDoc_bhxh_huongDan || 0;
    }

    if (a) {
      acc.ctBanSao_hoSo += a.ctBanSao_hoSo || 0;
      acc.ctBanSao_huongDan += a.ctBanSao_huongDan || 0;
      acc.ctBanSao_ban += a.ctBanSao_ban || 0;
      acc.ctBanSao_tien += a.ctBanSao_tien || 0;

      acc.ctChuKy_hoSo += a.ctChuKy_hoSo || 0;
      acc.ctChuKy_huongDan += a.ctChuKy_huongDan || 0;
      acc.ctChuKy_ban += a.ctChuKy_ban || 0;
      acc.ctChuKy_tien += a.ctChuKy_tien || 0;

      acc.hoTich_hoSo += a.hoTich_hoSo || 0;
      acc.hoTich_huongDan += a.hoTich_huongDan || 0;
      acc.hoTich_tien += a.hoTich_tien || 0;

      acc.kinhTe_hoSo += a.kinhTe_hoSo || 0;
      acc.kinhTe_huongDan += a.kinhTe_huongDan || 0;

      acc.datDaiMoiTruong_hoSo += a.datDaiMoiTruong_hoSo || 0;
      acc.datDaiMoiTruong_huongDan += a.datDaiMoiTruong_huongDan || 0;

      acc.haTangDoThi_hoSo += a.haTangDoThi_hoSo || 0;
      acc.haTangDoThi_huongDan += a.haTangDoThi_huongDan || 0;

      acc.vanHoaXaHoi_hoSo += a.vanHoaXaHoi_hoSo || 0;
      acc.vanHoaXaHoi_huongDan += a.vanHoaXaHoi_huongDan || 0;

      acc.bhYTe_truongHop += a.bhYTe_truongHop || 0;
      acc.bhYTe_huongDan += a.bhYTe_huongDan || 0;
      acc.bhYTe_tien += a.bhYTe_tien || 0;

      acc.nganhDoc_thue += a.nganhDoc_thue || 0;
      acc.nganhDoc_thue_huongDan += a.nganhDoc_thue_huongDan || 0;
      acc.nganhDoc_bhxh += a.nganhDoc_bhxh || 0;
      acc.nganhDoc_bhxh_huongDan += a.nganhDoc_bhxh_huongDan || 0;
    }

    if (p) {
      acc.paper_hoTich += p.hoTich || 0;
      acc.paper_datDai += p.datDai || 0;
      acc.paper_taiNguyenMoiTruong += p.taiNguyenMoiTruong || 0;
      acc.paper_hoTich2 += p.hoTich2 || 0;
      acc.paper_baoTroXaHoi += p.baoTroXaHoi || 0;
      acc.paper_haTangDoThi += p.haTangDoThi || 0;
    }

    return acc;
  }, {
    ctBanSao_hoSo: 0, ctBanSao_huongDan: 0, ctBanSao_ban: 0, ctBanSao_tien: 0,
    ctChuKy_hoSo: 0, ctChuKy_huongDan: 0, ctChuKy_ban: 0, ctChuKy_tien: 0,
    hoTich_hoSo: 0, hoTich_huongDan: 0, hoTich_tien: 0,
    kinhTe_hoSo: 0, kinhTe_huongDan: 0,
    datDaiMoiTruong_hoSo: 0, datDaiMoiTruong_huongDan: 0,
    haTangDoThi_hoSo: 0, haTangDoThi_huongDan: 0,
    vanHoaXaHoi_hoSo: 0, vanHoaXaHoi_huongDan: 0,
    bhYTe_truongHop: 0, bhYTe_huongDan: 0, bhYTe_tien: 0,
    nganhDoc_thue: 0, nganhDoc_thue_huongDan: 0,
    nganhDoc_bhxh: 0, nganhDoc_bhxh_huongDan: 0,
    paper_hoTich: 0, paper_datDai: 0, paper_taiNguyenMoiTruong: 0, paper_hoTich2: 0, paper_baoTroXaHoi: 0, paper_haTangDoThi: 0
  });

  // Get list of workdays (Mon-Fri) in period up to today
  const periodWorkdays = (() => {
    const dates: string[] = [];
    const todayStr = new Date().toISOString().split('T')[0];
    const cutoffEnd = pEnd > todayStr ? todayStr : pEnd;

    let current = new Date(pStart);
    const endDateObj = new Date(cutoffEnd);

    while (current <= endDateObj) {
      const dayOfWeek = current.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 5) {
        const year = current.getFullYear();
        const month = String(current.getMonth() + 1).padStart(2, '0');
        const day = String(current.getDate()).padStart(2, '0');
        dates.push(`${year}-${month}-${day}`);
      }
      current.setDate(current.getDate() + 1);
    }
    return dates;
  })();

  // Calculate missed reports per specialist officer
  const officerAudits = specialistOfficers.map(off => {
    let submittedSessions = 0;
    let missedMorningCount = 0;
    let missedAfternoonCount = 0;
    let missedFullDaysCount = 0;
    const missedDetails: Array<{ date: string; missedSession: 'Sáng' | 'Chiều' | 'Cả ngày (Sáng & Chiều)' }> = [];

    periodWorkdays.forEach(d => {
      const r = periodReports.find(rep => rep.date === d && rep.officerId === off.id);
      const hasMorning = !!(r && r.morning);
      const hasAfternoon = !!(r && r.afternoon);

      if (hasMorning) submittedSessions += 1;
      else missedMorningCount += 1;

      if (hasAfternoon) submittedSessions += 1;
      else missedAfternoonCount += 1;

      if (!hasMorning && !hasAfternoon) {
        missedFullDaysCount += 1;
        missedDetails.push({ date: d, missedSession: 'Cả ngày (Sáng & Chiều)' });
      } else if (!hasMorning) {
        missedDetails.push({ date: d, missedSession: 'Sáng' });
      } else if (!hasAfternoon) {
        missedDetails.push({ date: d, missedSession: 'Chiều' });
      }
    });

    const totalRequiredSessions = periodWorkdays.length * 2;
    const missedSessionsTotal = missedMorningCount + missedAfternoonCount;
    const completionRate = totalRequiredSessions > 0 ? Math.round((submittedSessions / totalRequiredSessions) * 100) : 100;

    return {
      officer: off,
      totalRequiredSessions,
      submittedSessions,
      missedMorningCount,
      missedAfternoonCount,
      missedSessionsTotal,
      missedFullDaysCount,
      completionRate,
      missedDetails
    };
  });

  const totalRequiredAllOfficers = officerAudits.reduce((acc, a) => acc + a.totalRequiredSessions, 0);
  const totalSubmittedAllOfficers = officerAudits.reduce((acc, a) => acc + a.submittedSessions, 0);
  const totalMissedAllOfficers = officerAudits.reduce((acc, a) => acc + a.missedSessionsTotal, 0);
  const overallComplianceRate = totalRequiredAllOfficers > 0 ? Math.round((totalSubmittedAllOfficers / totalRequiredAllOfficers) * 100) : 100;

  // Export excel function for period summary
  const handleExportPeriodExcel = () => {
    const wb = XLSX.utils.book_new();

    const sectorData = [
      [`BÁO CÁO TỔNG HỢP SỐ LIỆU THEO LĨNH VỰC - ${pLabel.toUpperCase()}`],
      [`Giai đoạn: Từ ${pStart} đến ${pEnd}`],
      [],
      ['STT', 'Lĩnh vực Cụ thể', 'Tổng HS tiếp nhận', 'HS Hướng dẫn', 'Số bản / Trường hợp', 'Lệ phí / Thu hộ (VNĐ)', 'Ghi chú'],
      [1, 'Chứng thực (Bản sao & Chữ ký)', periodTotals.ctBanSao_hoSo + periodTotals.ctChuKy_hoSo, periodTotals.ctBanSao_huongDan + periodTotals.ctChuKy_huongDan, `${periodTotals.ctBanSao_ban + periodTotals.ctChuKy_ban} bản`, periodTotals.ctBanSao_tien + periodTotals.ctChuKy_tien, `Bản sao: ${periodTotals.ctBanSao_hoSo} HS | Chữ ký: ${periodTotals.ctChuKy_hoSo} HS`],
      [2, 'Hộ tịch', periodTotals.hoTich_hoSo + periodTotals.paper_hoTich + periodTotals.paper_hoTich2, periodTotals.hoTich_huongDan, '—', periodTotals.hoTich_tien, `${periodTotals.hoTich_hoSo} HS điện tử + ${periodTotals.paper_hoTich + periodTotals.paper_hoTich2} HS giấy`],
      [3, 'Kinh tế', periodTotals.kinhTe_hoSo, periodTotals.kinhTe_huongDan, '—', 0, 'Đăng ký hộ kinh doanh & giấy phép'],
      [4, 'Đất đai - Tài nguyên Môi trường', periodTotals.datDaiMoiTruong_hoSo + periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong, periodTotals.datDaiMoiTruong_huongDan, '—', 0, `${periodTotals.datDaiMoiTruong_hoSo} HS điện tử + ${periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong} HS giấy`],
      [5, 'Hạ tầng - Đô thị', periodTotals.haTangDoThi_hoSo + periodTotals.paper_haTangDoThi, periodTotals.haTangDoThi_huongDan, '—', 0, `${periodTotals.haTangDoThi_hoSo} HS điện tử + ${periodTotals.paper_haTangDoThi} HS giấy`],
      [6, 'Văn hóa - Xã hội & BTXH', periodTotals.vanHoaXaHoi_hoSo + periodTotals.paper_baoTroXaHoi, periodTotals.vanHoaXaHoi_huongDan, '—', 0, `${periodTotals.vanHoaXaHoi_hoSo} HS VH-XH + ${periodTotals.paper_baoTroXaHoi} HS Bảo trợ XH`],
      [7, 'Bảo hiểm Y tế (BHYT)', periodTotals.bhYTe_truongHop, periodTotals.bhYTe_huongDan, `${periodTotals.bhYTe_truongHop} trường hợp`, periodTotals.bhYTe_tien, 'Gia hạn & đăng ký BHYT'],
      [8, 'Ngành dọc (Thuế & BHXH)', periodTotals.nganhDoc_thue + periodTotals.nganhDoc_bhxh, periodTotals.nganhDoc_thue_huongDan + periodTotals.nganhDoc_bhxh_huongDan, '—', 0, `Thuế: ${periodTotals.nganhDoc_thue} HS | BHXH: ${periodTotals.nganhDoc_bhxh} HS`]
    ];

    const wsSector = XLSX.utils.aoa_to_sheet(sectorData);
    XLSX.utils.book_append_sheet(wb, wsSector, 'Tổng hợp Lĩnh vực');

    const auditData = [
      [`BÁO CÁO CHỐT SỐ LIỆU THEO DÕI NỘP BÁO CÁO HÀNG NGÀY - ${pLabel.toUpperCase()}`],
      [`Tổng số ngày làm việc trong giai đoạn: ${periodWorkdays.length} ngày (${periodWorkdays.length * 2} buổi quy định)`],
      [],
      ['STT', 'Họ và tên Công chức', 'Lĩnh vực phụ trách', 'Tổng số buổi quy định', 'Số buổi đã nộp', 'Số buổi THIẾU', 'Thiếu cả ngày', 'Tỷ lệ hoàn thành (%)'],
      ...officerAudits.map((a, idx) => [
        idx + 1,
        a.officer.name,
        a.officer.role,
        a.totalRequiredSessions,
        a.submittedSessions,
        a.missedSessionsTotal,
        a.missedFullDaysCount,
        `${a.completionRate}%`
      ]),
      [],
      ['DANH SÁCH CHI TIẾT CÁC BUỔI / NGÀY CHƯA NỘP BÁO CÁO'],
      ['Công chức', 'Lĩnh vực', 'Ngày chưa nộp', 'Buổi thiếu']
    ];

    officerAudits.forEach(a => {
      a.missedDetails.forEach(m => {
        auditData.push([a.officer.name, a.officer.role, m.date, m.missedSession]);
      });
    });

    const wsAudit = XLSX.utils.aoa_to_sheet(auditData);
    XLSX.utils.book_append_sheet(wb, wsAudit, 'Theo dõi Chấn chỉnh Nộp BC');

    XLSX.writeFile(wb, `Bao_cao_tong_hop_${periodType}_${pLabel.replace(/[\/\s]/g, '_')}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Tab Nav Links */}
      <div className="flex justify-between items-center bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm no-print">
        <div className="flex flex-wrap gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-extrabold'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <Table className="w-3.5 h-3.5 inline mr-1" /> Thống kê & Giám sát
          </button>
          <button
            onClick={() => setActiveTab('period_summary')}
            className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
              activeTab === 'period_summary'
                ? 'bg-blue-600 text-white shadow-sm font-extrabold'
                : 'text-slate-500 dark:text-slate-400 hover:text-blue-600'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 inline mr-1" /> Tổng hợp Tháng / Quý / Năm
          </button>
          <button
            onClick={() => setActiveTab('submit')}
            className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
              activeTab === 'submit'
                ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-extrabold'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5 inline mr-1" /> Soạn báo cáo mới
          </button>
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setActiveTab('config')}
              className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                activeTab === 'config'
                  ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Settings className="w-3.5 h-3.5 inline mr-1" /> Cấu hình giờ
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 font-mono">Chọn Ngày:</span>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 text-xs font-bold border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none font-mono"
          />
        </div>
      </div>

      {/* --- TAB 1: DASHBOARD --- */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Status of reporting officers today */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 no-print">
            {/* Status card */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm col-span-1 flex flex-col justify-between space-y-4">
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tiến độ báo cáo trong ngày</h4>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="text-4xl font-black text-blue-600">{reportedOfficersCount}</span>
                  <span className="text-slate-400">/ {specialistOfficers.length} chuyên viên đã báo cáo</span>
                </div>
                {unsubmittedCount > 0 ? (
                  <p className="text-xs text-amber-600 dark:text-amber-400 font-medium mt-2 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Có {unsubmittedCount} chuyên viên chưa báo cáo!
                  </p>
                ) : (
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium mt-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> 100% Chuyên viên đã báo cáo hôm nay.
                  </p>
                )}
              </div>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-3 flex gap-2">
                <button
                  onClick={exportMasterReportToExcel}
                  className="flex-1 flex items-center justify-center gap-1 py-2 text-xs font-bold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900 rounded-lg cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4" /> Xuất Excel tổng hợp
                </button>
                <button
                  onClick={handlePrint}
                  className="flex-1 flex items-center justify-center gap-1 py-2 text-xs font-bold text-slate-700 bg-slate-100 dark:bg-slate-800 dark:text-slate-200 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  <Printer className="w-4 h-4" /> In báo cáo
                </button>
              </div>
            </div>

            {/* Officer reporting list */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm col-span-2">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Tình trạng báo cáo chi tiết</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[160px] overflow-y-auto pr-1">
                {reportingStatusList.map(s => (
                  <div key={s.officer.id} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-750 text-xs">
                    <span className="font-bold text-slate-800 dark:text-slate-200 truncate pr-2">{s.officer.name}</span>
                    <div className="flex items-center gap-1.5">
                      {/* Morning status & edit button */}
                      <button
                        onClick={() => handleEditReport(s.officer.id, 'morning')}
                        className={`px-2 py-1 rounded text-[10px] font-bold border flex items-center gap-1 cursor-pointer transition-all hover:scale-105 ${
                          s.morningSubmitted 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800' 
                            : 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                        }`}
                        title={s.morningSubmitted ? `Đã báo cáo lúc ${s.morningTime} (Nhấn để chỉnh sửa)` : 'Chưa báo cáo sáng (Nhấn để nhập)'}
                      >
                        {s.morningSubmitted ? `Sáng: ✅ ${s.morningTime} ✏️` : 'Sáng: ❌ ➕'}
                      </button>

                      {/* Afternoon status & edit button */}
                      <button
                        onClick={() => handleEditReport(s.officer.id, 'afternoon')}
                        className={`px-2 py-1 rounded text-[10px] font-bold border flex items-center gap-1 cursor-pointer transition-all hover:scale-105 ${
                          s.afternoonSubmitted 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800' 
                            : 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                        }`}
                        title={s.afternoonSubmitted ? `Đã báo cáo lúc ${s.afternoonTime} (Nhấn để chỉnh sửa)` : 'Chưa báo cáo chiều (Nhấn để nhập)'}
                      >
                        {s.afternoonSubmitted ? `Chiều: ✅ ${s.afternoonTime} ✏️` : 'Chiều: ❌ ➕'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Master Consolidated Report Table */}
          <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6 print:p-0 print:shadow-none print:border-none">
            {/* Report Header for printing */}
            <div className="text-center space-y-1.5 pb-4 border-b border-slate-100 dark:border-slate-800">
              <p className="text-xs font-bold text-[#00387B] dark:text-blue-400 uppercase tracking-wider">ỦY BAN NHÂN DÂN PHƯỜNG CẦU KIỆU</p>
              <h3 className="font-extrabold text-slate-850 dark:text-slate-100 uppercase tracking-tight text-sm">
                BẢNG THỐNG KÊ TIẾP NHẬN HỒ SƠ - CHỨNG THỰC HÀNG NGÀY
              </h3>
              <p className="text-xs text-slate-500 font-bold italic font-mono">Ngày thống kê: {selectedDate}</p>
            </div>

            {/* Main statistics table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-350 font-bold border-b border-slate-200 dark:border-slate-700 text-center">
                    <th className="py-2.5 px-2 text-left w-12 border border-slate-200 dark:border-slate-700" rowSpan={2}>STT</th>
                    <th className="py-2.5 px-3 text-left border border-slate-200 dark:border-slate-700" rowSpan={2}>Lĩnh vực / Chỉ tiêu thụ lý</th>
                    <th className="py-1.5 px-2 border border-slate-200 dark:border-slate-700" colSpan={4}>BUỔI SÁNG</th>
                    <th className="py-1.5 px-2 border border-slate-200 dark:border-slate-700" colSpan={4}>BUỔI CHIỀU</th>
                    <th className="py-1.5 px-2 border border-slate-200 dark:border-slate-700" colSpan={4}>CẢ NGÀY (TỔNG)</th>
                  </tr>
                  <tr className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-bold border-b border-slate-200 dark:border-slate-700 text-center">
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700" title="Hồ sơ nhận">HS Nhận</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700 text-amber-600 dark:text-amber-400" title="Hồ sơ hướng dẫn">HS H.Dẫn</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Bản</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Tiền (đ)</th>

                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700" title="Hồ sơ nhận">HS Nhận</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700 text-amber-600 dark:text-amber-400" title="Hồ sơ hướng dẫn">HS H.Dẫn</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Bản</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Tiền (đ)</th>

                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700" title="Hồ sơ nhận">HS Nhận</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700 text-amber-600 dark:text-amber-400" title="Hồ sơ hướng dẫn">HS H.Dẫn</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Bản</th>
                    <th className="py-1 px-1 border border-slate-200 dark:border-slate-700">Tiền (đ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {/* Row 1 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">1</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Chứng thực bản sao từ bản chính</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_ban}</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctBanSao_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctBanSao_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctBanSao_ban}</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctBanSao_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_hoSo + combinedAfternoon.ctBanSao_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.ctBanSao_huongDan || 0) + (combinedAfternoon.ctBanSao_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban}</td>
                    <td className="py-2 px-1 text-right font-bold font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">{(combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien).toLocaleString('vi-VN')}</td>
                  </tr>

                  {/* Row 2 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">2</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Chứng thực chữ ký</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_ban}</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctChuKy_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctChuKy_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctChuKy_ban}</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.ctChuKy_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_hoSo + combinedAfternoon.ctChuKy_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.ctChuKy_huongDan || 0) + (combinedAfternoon.ctChuKy_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban}</td>
                    <td className="py-2 px-1 text-right font-bold font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">{(combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien).toLocaleString('vi-VN')}</td>
                  </tr>

                  {/* Row 3 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">3</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Hộ tịch</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.hoTich_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.hoTich_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.hoTich_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.hoTich_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.hoTich_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.hoTich_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.hoTich_huongDan || 0) + (combinedAfternoon.hoTich_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-bold font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">{(combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien).toLocaleString('vi-VN')}</td>
                  </tr>

                  {/* Row 4 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">4</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Lĩnh vực Kinh tế</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.kinhTe_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.kinhTe_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.kinhTe_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.kinhTe_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.kinhTe_hoSo + combinedAfternoon.kinhTe_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.kinhTe_huongDan || 0) + (combinedAfternoon.kinhTe_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* Row 5 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">5</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Lĩnh vực Đất Đai - Tài nguyên Môi trường</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.datDaiMoiTruong_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.datDaiMoiTruong_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.datDaiMoiTruong_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.datDaiMoiTruong_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.datDaiMoiTruong_huongDan || 0) + (combinedAfternoon.datDaiMoiTruong_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* Row 6 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">6</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Lĩnh vực Hạ tầng - Đô thị</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.haTangDoThi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.haTangDoThi_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.haTangDoThi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.haTangDoThi_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.haTangDoThi_huongDan || 0) + (combinedAfternoon.haTangDoThi_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* Row 7 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">7</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Lĩnh vực Văn hóa - Xã hội</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.vanHoaXaHoi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.vanHoaXaHoi_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.vanHoaXaHoi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.vanHoaXaHoi_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.vanHoaXaHoi_huongDan || 0) + (combinedAfternoon.vanHoaXaHoi_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* Row 8 */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">8</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Bảo hiểm Y tế</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.bhYTe_truongHop}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.bhYTe_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.bhYTe_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.bhYTe_truongHop}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.bhYTe_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.bhYTe_tien.toLocaleString('vi-VN')}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.bhYTe_huongDan || 0) + (combinedAfternoon.bhYTe_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-right font-bold font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">{(combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien).toLocaleString('vi-VN')}</td>
                  </tr>

                  {/* Row 9 (Ngành dọc) */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">9</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Hồ sơ Thuế (Ngành dọc)</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_thue}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_thue_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.nganhDoc_thue}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.nganhDoc_thue_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.nganhDoc_thue_huongDan || 0) + (combinedAfternoon.nganhDoc_thue_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* Row 10 (Ngành dọc BHXH) */}
                  <tr>
                    <td className="py-2 px-2 text-center border border-slate-200 dark:border-slate-700">10</td>
                    <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">Hồ sơ BHXH (Ngành dọc)</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_bhxh}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_bhxh_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{combinedAfternoon.nganhDoc_bhxh}</td>
                    <td className="py-2 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{combinedAfternoon.nganhDoc_bhxh_huongDan || 0}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">{combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh}</td>
                    <td className="py-2 px-1 text-center font-semibold font-mono text-amber-600 dark:text-amber-400 bg-amber-50/20 border border-slate-200 dark:border-slate-700">{(combinedMorning.nganhDoc_bhxh_huongDan || 0) + (combinedAfternoon.nganhDoc_bhxh_huongDan || 0)}</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/20 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-2 px-1 text-center text-slate-300 font-mono bg-blue-50/30 border border-slate-200 dark:border-slate-700">—</td>
                  </tr>

                  {/* TOTAL SUM ROW */}
                  <tr className="bg-slate-100 dark:bg-slate-800 font-extrabold text-slate-900 dark:text-slate-100">
                    <td className="py-3 px-2 text-center border border-slate-200 dark:border-slate-700" colSpan={2}>CỘNG TỔNG HỒ SƠ TIẾP NHẬN</td>
                    <td className="py-3 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{morningTotalDossiers}</td>
                    <td className="py-3 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{morningTotalGuided}</td>
                    <td className="py-3 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-3 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{(combinedMorning.ctBanSao_tien + combinedMorning.ctChuKy_tien + combinedMorning.hoTich_tien + combinedMorning.bhYTe_tien).toLocaleString('vi-VN')}</td>
                    <td className="py-3 px-1 text-center font-mono border border-slate-200 dark:border-slate-700">{afternoonTotalDossiers}</td>
                    <td className="py-3 px-1 text-center font-mono text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-700">{afternoonTotalGuided}</td>
                    <td className="py-3 px-1 text-center text-slate-300 font-mono border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-3 px-1 text-right font-mono border border-slate-200 dark:border-slate-700">{(combinedAfternoon.ctBanSao_tien + combinedAfternoon.ctChuKy_tien + combinedAfternoon.hoTich_tien + combinedAfternoon.bhYTe_tien).toLocaleString('vi-VN')}</td>
                    <td className="py-3 px-1 text-center font-mono bg-slate-200 dark:bg-slate-700 border border-slate-200 dark:border-slate-700">{morningTotalDossiers + afternoonTotalDossiers}</td>
                    <td className="py-3 px-1 text-center font-mono text-amber-600 dark:text-amber-400 bg-amber-50/40 border border-slate-200 dark:border-slate-700">{morningTotalGuided + afternoonTotalGuided}</td>
                    <td className="py-3 px-1 text-center text-slate-300 font-mono bg-slate-200 dark:bg-slate-700 border border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-3 px-1 text-right font-mono bg-slate-200 dark:bg-slate-700 border border-slate-200 dark:border-slate-700">{(combinedMorning.ctBanSao_tien + combinedMorning.ctChuKy_tien + combinedMorning.hoTich_tien + combinedMorning.bhYTe_tien + combinedAfternoon.ctBanSao_tien + combinedAfternoon.ctChuKy_tien + combinedAfternoon.hoTich_tien + combinedAfternoon.bhYTe_tien).toLocaleString('vi-VN')} đ</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Paper Dossiers section (Pink table from attached file) */}
            <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowDown className="w-4 h-4 text-pink-500" />
                Số lượng hồ sơ giấy tiếp nhận trực tiếp trong ngày (Nhận trực tiếp tại quầy)
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-4">
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Lĩnh vực Hộ tịch</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.hoTich}</p>
                </div>
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Lĩnh vực Đất đai</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.datDai}</p>
                </div>
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Tài nguyên - Môi trường</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.taiNguyenMoiTruong}</p>
                </div>
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Lĩnh vực Tư pháp</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.hoTich2}</p>
                </div>
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Bảo trợ xã hội</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.baoTroXaHoi}</p>
                </div>
                <div className="bg-pink-50/30 dark:bg-pink-950/10 border border-pink-100 dark:border-pink-900/40 p-3 rounded-lg text-center">
                  <p className="text-[10px] font-bold text-pink-600 dark:text-pink-400 uppercase tracking-tight">Hạ tầng - Đô thị</p>
                  <p className="text-xl font-black text-pink-800 dark:text-pink-300 mt-1">{combinedPaperDossiers.haTangDoThi}</p>
                </div>
              </div>
            </div>

            {/* --- SECTOR SUMMARY TABLE (Tổng hợp theo từng Lĩnh Vực Cụ Thể) --- */}
            <div className="space-y-3 pt-6 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                  Tổng hợp số liệu theo từng Lĩnh vực cụ thể
                </h4>
                <span className="text-[11px] text-slate-400 italic">Tổng hợp điện tử + Hồ sơ giấy nhận trực tiếp</span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-bold border-b border-slate-200 dark:border-slate-700">
                      <th className="p-2.5 text-center w-12 border-r border-slate-200 dark:border-slate-700">STT</th>
                      <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Cụ thể</th>
                      <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Tổng số HS tiếp nhận</th>
                      <th className="p-2.5 text-center w-28 text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">HS Hướng dẫn</th>
                      <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Số bản / Trường hợp</th>
                      <th className="p-2.5 text-right w-36 border-r border-slate-200 dark:border-slate-700">Lệ phí / Thu hộ (VNĐ)</th>
                      <th className="p-2.5">Ghi chú & Tỷ trọng</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150 dark:divide-slate-800 bg-white dark:bg-slate-850">
                    {/* Row 1: Chứng thực */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">1</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Chứng thực (Bản sao & Chữ ký)
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.ctBanSao_hoSo + combinedAfternoon.ctBanSao_hoSo) + (combinedMorning.ctChuKy_hoSo + combinedAfternoon.ctChuKy_hoSo)}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.ctBanSao_huongDan || 0) + (combinedAfternoon.ctBanSao_huongDan || 0) + (combinedMorning.ctChuKy_huongDan || 0) + (combinedAfternoon.ctChuKy_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center font-mono border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban) + (combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban)} bản
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">
                        {((combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien) + (combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien)).toLocaleString('vi-VN')} đ
                      </td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        Bản sao: {combinedMorning.ctBanSao_hoSo + combinedAfternoon.ctBanSao_hoSo} HS | Chữ ký: {combinedMorning.ctChuKy_hoSo + combinedAfternoon.ctChuKy_hoSo} HS
                      </td>
                    </tr>

                    {/* Row 2: Hộ tịch */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">2</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Hộ tịch
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo) + combinedPaperDossiers.hoTich + combinedPaperDossiers.hoTich2}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.hoTich_huongDan || 0) + (combinedAfternoon.hoTich_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien).toLocaleString('vi-VN')} đ
                      </td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        {combinedMorning.hoTich_hoSo + combinedAfternoon.hoTich_hoSo} HS điện tử + {combinedPaperDossiers.hoTich + combinedPaperDossiers.hoTich2} HS giấy
                      </td>
                    </tr>

                    {/* Row 3: Kinh tế */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">3</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Kinh tế
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {combinedMorning.kinhTe_hoSo + combinedAfternoon.kinhTe_hoSo}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.kinhTe_huongDan || 0) + (combinedAfternoon.kinhTe_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        Đăng ký hộ kinh doanh & giấy phép
                      </td>
                    </tr>

                    {/* Row 4: Đất đai - Môi trường */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">4</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Đất đai - Tài nguyên Môi trường
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo) + combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.datDaiMoiTruong_huongDan || 0) + (combinedAfternoon.datDaiMoiTruong_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        {combinedMorning.datDaiMoiTruong_hoSo + combinedAfternoon.datDaiMoiTruong_hoSo} HS điện tử + {combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong} HS giấy
                      </td>
                    </tr>

                    {/* Row 5: Hạ tầng đô thị */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">5</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Hạ tầng - Đô thị
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo) + combinedPaperDossiers.haTangDoThi}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.haTangDoThi_huongDan || 0) + (combinedAfternoon.haTangDoThi_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        {combinedMorning.haTangDoThi_hoSo + combinedAfternoon.haTangDoThi_hoSo} HS điện tử + {combinedPaperDossiers.haTangDoThi} HS giấy
                      </td>
                    </tr>

                    {/* Row 6: Văn hóa - Xã hội */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">6</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Văn hóa - Xã hội & Bảo trợ XH
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo) + combinedPaperDossiers.baoTroXaHoi}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.vanHoaXaHoi_huongDan || 0) + (combinedAfternoon.vanHoaXaHoi_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        {combinedMorning.vanHoaXaHoi_hoSo + combinedAfternoon.vanHoaXaHoi_hoSo} HS VH-XH + {combinedPaperDossiers.baoTroXaHoi} HS Bảo trợ XH
                      </td>
                    </tr>

                    {/* Row 7: BHYT */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">7</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Bảo hiểm Y tế (BHYT)
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.bhYTe_huongDan || 0) + (combinedAfternoon.bhYTe_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center font-mono border-r border-slate-200 dark:border-slate-700">
                        {combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop} trường hợp
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien).toLocaleString('vi-VN')} đ
                      </td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        Thu tiền gia hạn / đóng mới BHYT hộ gia đình
                      </td>
                    </tr>

                    {/* Row 8: Ngành dọc */}
                    <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">8</td>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                        Lĩnh vực Ngành dọc Liên thông (Thuế & BHXH)
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue) + (combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh)}
                      </td>
                      <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.nganhDoc_thue_huongDan || 0) + (combinedAfternoon.nganhDoc_thue_huongDan || 0) + (combinedMorning.nganhDoc_bhxh_huongDan || 0) + (combinedAfternoon.nganhDoc_bhxh_huongDan || 0)}
                      </td>
                      <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                      <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                      <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">
                        Thuế: {combinedMorning.nganhDoc_thue + combinedAfternoon.nganhDoc_thue} HS | BHXH: {combinedMorning.nganhDoc_bhxh + combinedAfternoon.nganhDoc_bhxh} HS
                      </td>
                    </tr>

                    {/* Total Row */}
                    <tr className="bg-indigo-100/70 dark:bg-indigo-950/80 font-black text-slate-900 dark:text-slate-100 text-xs">
                      <td className="p-3 text-center border-r border-slate-200 dark:border-slate-700" colSpan={2}>
                        TỔNG CỘNG TOÀN BỘ CÁC LĨNH VỰC
                      </td>
                      <td className="p-3 text-center font-mono text-indigo-700 dark:text-indigo-300 text-sm border-r border-slate-200 dark:border-slate-700">
                        {morningTotalDossiers + afternoonTotalDossiers + combinedPaperDossiers.hoTich + combinedPaperDossiers.datDai + combinedPaperDossiers.taiNguyenMoiTruong + combinedPaperDossiers.hoTich2 + combinedPaperDossiers.baoTroXaHoi + combinedPaperDossiers.haTangDoThi}
                      </td>
                      <td className="p-3 text-center font-mono text-amber-700 dark:text-amber-300 text-sm border-r border-slate-200 dark:border-slate-700">
                        {morningTotalGuided + afternoonTotalGuided}
                      </td>
                      <td className="p-3 text-center font-mono border-r border-slate-200 dark:border-slate-700">
                        {(combinedMorning.ctBanSao_ban + combinedAfternoon.ctBanSao_ban + combinedMorning.ctChuKy_ban + combinedAfternoon.ctChuKy_ban + combinedMorning.bhYTe_truongHop + combinedAfternoon.bhYTe_truongHop)} lượt
                      </td>
                      <td className="p-3 text-right font-mono text-emerald-700 dark:text-emerald-300 text-sm border-r border-slate-200 dark:border-slate-700">
                        {((combinedMorning.ctBanSao_tien + combinedAfternoon.ctBanSao_tien) + (combinedMorning.ctChuKy_tien + combinedAfternoon.ctChuKy_tien) + (combinedMorning.hoTich_tien + combinedAfternoon.hoTich_tien) + (combinedMorning.bhYTe_tien + combinedAfternoon.bhYTe_tien)).toLocaleString('vi-VN')} đ
                      </td>
                      <td className="p-3 text-indigo-900 dark:text-indigo-200 italic">
                        Tổng hợp điện tử + Giấy tiếp nhận trực tiếp toàn bộ quầy
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* --- DIFFICULTIES, PROPOSALS & SOLUTIONS SECTION --- */}
            <div className="space-y-4 pt-6 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  Khó khăn, vướng mắc, đề xuất, kiến nghị & Giải pháp cụ thể trong ngày
                </h4>
                <span className="text-[11px] text-slate-400 italic">Báo cáo từ chuyên viên Một cửa</span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                      <th className="p-2.5 text-center w-12 border-r border-slate-200 dark:border-slate-700">STT</th>
                      <th className="p-2.5 w-44 border-r border-slate-200 dark:border-slate-700">Cán bộ / Chuyên viên</th>
                      <th className="p-2.5 text-center w-28 border-r border-slate-200 dark:border-slate-700">Phiên</th>
                      <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">🚨 Khó khăn, vướng mắc phát sinh</th>
                      <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">💡 Đề xuất, kiến nghị & Giải pháp cụ thể</th>
                      <th className="p-2.5 text-center w-28 border-r border-slate-200 dark:border-slate-700">Thời gian</th>
                      <th className="p-2.5 text-center w-24">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150 dark:divide-slate-800 bg-white dark:bg-slate-850">
                    {reportsForDate.map((r, i) => (
                      <tr key={r.id || i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700 text-slate-500">{i + 1}</td>
                        <td className="p-2.5 border-r border-slate-200 dark:border-slate-700">
                          <p className="font-bold text-slate-800 dark:text-slate-200">{r.officerName}</p>
                        </td>
                        <td className="p-2.5 text-center border-r border-slate-200 dark:border-slate-700">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            r.session === 'morning' 
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300' 
                              : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300'
                          }`}>
                            {r.session === 'morning' ? '🌅 Buổi sáng' : '🌇 Buổi chiều'}
                          </span>
                        </td>
                        <td className="p-2.5 border-r border-slate-200 dark:border-slate-700">
                          {r.difficulties ? (
                            <p className="text-red-700 dark:text-red-300 font-medium italic text-justify">
                              "{r.difficulties}"
                            </p>
                          ) : (
                            <p className="text-slate-400 italic">Không có phát sinh khó khăn, vướng mắc.</p>
                          )}
                        </td>
                        <td className="p-2.5 border-r border-slate-200 dark:border-slate-700">
                          {r.suggestions ? (
                            <p className="text-blue-700 dark:text-blue-300 font-medium italic text-justify">
                              "{r.suggestions}"
                            </p>
                          ) : (
                            <p className="text-slate-400 italic">Không có đề xuất, giải pháp bổ sung.</p>
                          )}
                        </td>
                        <td className="p-2.5 text-center font-mono text-[11px] text-slate-500 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700">
                          {r.reportedAt ? new Date(r.reportedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : '—'}
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            onClick={() => handleEditReport(r.officerId, r.session)}
                            className="px-2 py-1 text-[11px] font-bold text-blue-700 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 border border-blue-200 dark:border-blue-800 rounded-md cursor-pointer transition-all hover:scale-105 inline-flex items-center gap-1"
                            title="Chỉnh sửa báo cáo này"
                          >
                            ✏️ Sửa
                          </button>
                        </td>
                      </tr>
                    ))}

                    {reportsForDate.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-6 text-center text-slate-400 italic">
                          Chưa có báo cáo từ chuyên viên trong ngày {selectedDate}.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: PERIODIC SUMMARY & AUDIT (Tháng / Quý / Năm) --- */}
      {activeTab === 'period_summary' && (
        <div className="space-y-6">
          {/* Controls & Period Selector Bar */}
          <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 no-print">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  Báo cáo Tổng hợp Số liệu & Đánh giá Chấp hành Báo cáo ({pLabel})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Tổng hợp số liệu hồ sơ chi tiết từng lĩnh vực và chốt số liệu các ngày/buổi công chức không thực hiện báo cáo
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportPeriodExcel}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <FileSpreadsheet className="w-4 h-4" /> Xuất Excel Giai đoạn
                </button>
                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg text-xs cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <Printer className="w-4 h-4" /> In Báo cáo
                </button>
              </div>
            </div>

            {/* Filter selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-150 dark:border-slate-750">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Loại Kỳ Báo Cáo</label>
                <div className="flex gap-1 bg-white dark:bg-slate-750 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setPeriodType('month')}
                    className={`flex-1 py-1 text-xs font-bold rounded transition-colors ${periodType === 'month' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}
                  >
                    Tháng
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodType('quarter')}
                    className={`flex-1 py-1 text-xs font-bold rounded transition-colors ${periodType === 'quarter' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}
                  >
                    Quý
                  </button>
                  <button
                    type="button"
                    onClick={() => setPeriodType('year')}
                    className={`flex-1 py-1 text-xs font-bold rounded transition-colors ${periodType === 'year' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}
                  >
                    Năm
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Chọn Năm</label>
                <select
                  value={periodYear}
                  onChange={(e) => setPeriodYear(Number(e.target.value))}
                  className="w-full text-xs font-bold px-3 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                >
                  <option value={2025}>2025</option>
                  <option value={2026}>2026</option>
                  <option value={2027}>2027</option>
                </select>
              </div>

              {periodType === 'month' && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Chọn Tháng</label>
                  <select
                    value={periodMonth}
                    onChange={(e) => setPeriodMonth(Number(e.target.value))}
                    className="w-full text-xs font-bold px-3 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                      <option key={m} value={m}>Tháng {m}</option>
                    ))}
                  </select>
                </div>
              )}

              {periodType === 'quarter' && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Chọn Quý</label>
                  <select
                    value={periodQuarter}
                    onChange={(e) => setPeriodQuarter(Number(e.target.value))}
                    className="w-full text-xs font-bold px-3 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                  >
                    <option value={1}>Quý I (Tháng 1 - Tháng 3)</option>
                    <option value={2}>Quý II (Tháng 4 - Tháng 6)</option>
                    <option value={3}>Quý III (Tháng 7 - Tháng 9)</option>
                    <option value={4}>Quý IV (Tháng 10 - Tháng 12)</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Lọc Theo Cán Bộ / Công Chức</label>
                <select
                  value={auditOfficerFilter}
                  onChange={(e) => setAuditOfficerFilter(e.target.value)}
                  className="w-full text-xs font-bold px-3 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                >
                  <option value="">-- Tất cả chuyên viên --</option>
                  {specialistOfficers.map(o => (
                    <option key={o.id} value={o.id}>{o.name} ({o.role || 'Chuyên viên'})</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Metric Overview Banner */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-center">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Tổng HS Tiếp Nhận</p>
              <p className="text-xl font-black text-blue-600 dark:text-blue-400 mt-0.5">
                {periodTotals.ctBanSao_hoSo + periodTotals.ctChuKy_hoSo + periodTotals.hoTich_hoSo + periodTotals.kinhTe_hoSo + periodTotals.datDaiMoiTruong_hoSo + periodTotals.haTangDoThi_hoSo + periodTotals.vanHoaXaHoi_hoSo + periodTotals.bhYTe_truongHop + periodTotals.nganhDoc_thue + periodTotals.nganhDoc_bhxh + periodTotals.paper_hoTich + periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong + periodTotals.paper_hoTich2 + periodTotals.paper_baoTroXaHoi + periodTotals.paper_haTangDoThi}
              </p>
              <span className="text-[9px] text-slate-400 italic">Hồ sơ điện tử & Sổ giấy</span>
            </div>

            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-center">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Lượt Hướng Dẫn</p>
              <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-0.5">
                {periodTotals.ctBanSao_huongDan + periodTotals.ctChuKy_huongDan + periodTotals.hoTich_huongDan + periodTotals.kinhTe_huongDan + periodTotals.datDaiMoiTruong_huongDan + periodTotals.haTangDoThi_huongDan + periodTotals.vanHoaXaHoi_huongDan + periodTotals.bhYTe_huongDan + periodTotals.nganhDoc_thue_huongDan + periodTotals.nganhDoc_bhxh_huongDan}
              </p>
              <span className="text-[9px] text-slate-400 italic">Hướng dẫn công dân</span>
            </div>

            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-center">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Lệ Phí & Thu Hộ</p>
              <p className="text-lg font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                {(periodTotals.ctBanSao_tien + periodTotals.ctChuKy_tien + periodTotals.hoTich_tien + periodTotals.bhYTe_tien).toLocaleString('vi-VN')} đ
              </p>
              <span className="text-[9px] text-slate-400 italic">Lệ phí chứng thực / BHYT</span>
            </div>

            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-center">
              <p className="text-[10px] font-bold text-red-500 uppercase tracking-tight">Buổi Chưa Nộp BC</p>
              <p className="text-xl font-black text-red-600 dark:text-red-400 mt-0.5">
                {totalMissedAllOfficers}
              </p>
              <span className="text-[9px] text-slate-400 italic">Cần chấn chỉnh Kỷ luật</span>
            </div>

            <div className="bg-white dark:bg-slate-850 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-center col-span-2 md:col-span-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Tỷ Lệ Chấp Hành</p>
              <p className={`text-xl font-black mt-0.5 ${overallComplianceRate >= 90 ? 'text-emerald-600' : overallComplianceRate >= 75 ? 'text-amber-600' : 'text-red-600'}`}>
                {overallComplianceRate}%
              </p>
              <span className="text-[9px] text-slate-400 italic">Trên tổng buổi quy định</span>
            </div>
          </div>

          {/* Part 1: Detailed Sector Summary Table */}
          <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-slate-100 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                1. Tổng hợp số lượng hồ sơ chi tiết từng lĩnh vực ({pLabel})
              </h4>
              <span className="text-xs font-mono font-bold text-blue-600 dark:text-blue-400">Từ {pStart} đến {pEnd}</span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                    <th className="p-2.5 text-center w-12 border-r border-slate-200 dark:border-slate-700">STT</th>
                    <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Cụ thể</th>
                    <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Tổng số HS tiếp nhận</th>
                    <th className="p-2.5 text-center w-28 text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">HS Hướng dẫn</th>
                    <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Số bản / Trường hợp</th>
                    <th className="p-2.5 text-right w-36 border-r border-slate-200 dark:border-slate-700">Lệ phí / Thu hộ (VNĐ)</th>
                    <th className="p-2.5">Ghi chú & Tỷ trọng</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-800 bg-white dark:bg-slate-850">
                  {/* Row 1: Chứng thực */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">1</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Chứng thực (Bản sao & Chữ ký)</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.ctBanSao_hoSo + periodTotals.ctChuKy_hoSo}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.ctBanSao_huongDan + periodTotals.ctChuKy_huongDan}</td>
                    <td className="p-2.5 text-center font-mono border-r border-slate-200 dark:border-slate-700">{periodTotals.ctBanSao_ban + periodTotals.ctChuKy_ban} bản</td>
                    <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">{(periodTotals.ctBanSao_tien + periodTotals.ctChuKy_tien).toLocaleString('vi-VN')} đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">Bản sao: {periodTotals.ctBanSao_hoSo} HS | Chữ ký: {periodTotals.ctChuKy_hoSo} HS</td>
                  </tr>

                  {/* Row 2: Hộ tịch */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">2</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Hộ tịch</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.hoTich_hoSo + periodTotals.paper_hoTich + periodTotals.paper_hoTich2}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.hoTich_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.hoTich_tien.toLocaleString('vi-VN')} đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">{periodTotals.hoTich_hoSo} HS điện tử + {periodTotals.paper_hoTich + periodTotals.paper_hoTich2} HS giấy</td>
                  </tr>

                  {/* Row 3: Kinh tế */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">3</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Kinh tế</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.kinhTe_hoSo}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.kinhTe_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">Đăng ký hộ kinh doanh & giấy phép</td>
                  </tr>

                  {/* Row 4: Đất đai - Môi trường */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">4</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Đất đai - Tài nguyên Môi trường</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.datDaiMoiTruong_hoSo + periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.datDaiMoiTruong_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">{periodTotals.datDaiMoiTruong_hoSo} HS điện tử + {periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong} HS giấy</td>
                  </tr>

                  {/* Row 5: Hạ tầng - Đô thị */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">5</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Hạ tầng - Đô thị</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.haTangDoThi_hoSo + periodTotals.paper_haTangDoThi}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.haTangDoThi_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">{periodTotals.haTangDoThi_hoSo} HS điện tử + {periodTotals.paper_haTangDoThi} HS giấy</td>
                  </tr>

                  {/* Row 6: Văn hóa - Xã hội */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">6</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Văn hóa - Xã hội & BTXH</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.vanHoaXaHoi_hoSo + periodTotals.paper_baoTroXaHoi}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.vanHoaXaHoi_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">{periodTotals.vanHoaXaHoi_hoSo} HS VH-XH + {periodTotals.paper_baoTroXaHoi} HS Bảo trợ XH</td>
                  </tr>

                  {/* Row 7: BHYT */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">7</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Bảo hiểm Y tế (BHYT)</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.bhYTe_truongHop}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.bhYTe_huongDan}</td>
                    <td className="p-2.5 text-center font-mono border-r border-slate-200 dark:border-slate-700">{periodTotals.bhYTe_truongHop} trường hợp</td>
                    <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.bhYTe_tien.toLocaleString('vi-VN')} đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">Gia hạn & đăng ký BHYT hộ gia đình</td>
                  </tr>

                  {/* Row 8: Ngành dọc */}
                  <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">8</td>
                    <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">Lĩnh vực Ngành dọc Liên thông (Thuế & BHXH)</td>
                    <td className="p-2.5 text-center font-mono font-bold text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.nganhDoc_thue + periodTotals.nganhDoc_bhxh}</td>
                    <td className="p-2.5 text-center font-mono font-bold text-amber-600 dark:text-amber-400 border-r border-slate-200 dark:border-slate-700">{periodTotals.nganhDoc_thue_huongDan + periodTotals.nganhDoc_bhxh_huongDan}</td>
                    <td className="p-2.5 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-2.5 text-right font-mono text-slate-400 border-r border-slate-200 dark:border-slate-700">0 đ</td>
                    <td className="p-2.5 text-slate-500 dark:text-slate-400 italic">Thuế: {periodTotals.nganhDoc_thue} HS | BHXH: {periodTotals.nganhDoc_bhxh} HS</td>
                  </tr>

                  {/* Total row */}
                  <tr className="bg-slate-100 dark:bg-slate-800 font-extrabold text-slate-900 dark:text-slate-100 text-xs border-t-2 border-slate-300 dark:border-slate-600">
                    <td className="p-3 text-center border-r border-slate-200 dark:border-slate-700" colSpan={2}>TỔNG CỘNG TẤT CẢ LĨNH VỰC</td>
                    <td className="p-3 text-center font-mono text-blue-700 dark:text-blue-300 text-sm border-r border-slate-200 dark:border-slate-700">
                      {periodTotals.ctBanSao_hoSo + periodTotals.ctChuKy_hoSo + periodTotals.hoTich_hoSo + periodTotals.kinhTe_hoSo + periodTotals.datDaiMoiTruong_hoSo + periodTotals.haTangDoThi_hoSo + periodTotals.vanHoaXaHoi_hoSo + periodTotals.bhYTe_truongHop + periodTotals.nganhDoc_thue + periodTotals.nganhDoc_bhxh + periodTotals.paper_hoTich + periodTotals.paper_datDai + periodTotals.paper_taiNguyenMoiTruong + periodTotals.paper_hoTich2 + periodTotals.paper_baoTroXaHoi + periodTotals.paper_haTangDoThi}
                    </td>
                    <td className="p-3 text-center font-mono text-amber-700 dark:text-amber-300 text-sm border-r border-slate-200 dark:border-slate-700">
                      {periodTotals.ctBanSao_huongDan + periodTotals.ctChuKy_huongDan + periodTotals.hoTich_huongDan + periodTotals.kinhTe_huongDan + periodTotals.datDaiMoiTruong_huongDan + periodTotals.haTangDoThi_huongDan + periodTotals.vanHoaXaHoi_huongDan + periodTotals.bhYTe_huongDan + periodTotals.nganhDoc_thue_huongDan + periodTotals.nganhDoc_bhxh_huongDan}
                    </td>
                    <td className="p-3 text-center text-slate-300 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="p-3 text-right font-mono text-emerald-700 dark:text-emerald-300 text-sm border-r border-slate-200 dark:border-slate-700">
                      {(periodTotals.ctBanSao_tien + periodTotals.ctChuKy_tien + periodTotals.hoTich_tien + periodTotals.bhYTe_tien).toLocaleString('vi-VN')} đ
                    </td>
                    <td className="p-3 text-slate-500 italic">Tổng kết giai đoạn {pLabel}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Part 2: Audit & Monitoring of Missed Daily Reports */}
          <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-extrabold text-xs text-red-600 dark:text-red-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
                  2. Báo cáo chốt số liệu công chức từng lĩnh vực không thực hiện báo cáo hàng ngày ({pLabel})
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Tổng số ngày làm việc tính từ {pStart} đến nay: <strong>{periodWorkdays.length} ngày</strong> ({periodWorkdays.length * 2} buổi báo cáo quy định / công chức)
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 no-print">
                <div className="flex items-center gap-1.5">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">Trạng thái:</label>
                  <select
                    value={auditStatusFilter}
                    onChange={(e) => setAuditStatusFilter(e.target.value as any)}
                    className="text-xs font-bold px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none shadow-xs"
                  >
                    <option value="all">Tất cả trạng thái báo cáo</option>
                    <option value="missed">Chỉ hiển thị cán bộ THIẾU báo cáo</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400">Chọn công chức:</label>
                  <select
                    value={auditOfficerFilter}
                    onChange={(e) => setAuditOfficerFilter(e.target.value)}
                    className="text-xs font-bold px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none shadow-xs max-w-[240px]"
                  >
                    <option value="">-- Tất cả công chức / chuyên viên --</option>
                    {specialistOfficers.map(o => (
                      <option key={o.id} value={o.id}>{o.name} ({o.role || 'Chuyên viên'})</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Audit Summary Table by Officer */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                    <th className="p-2.5 text-center w-12 border-r border-slate-200 dark:border-slate-700">STT</th>
                    <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Họ và tên Cán bộ / Công chức</th>
                    <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Lĩnh vực chuyên môn</th>
                    <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Số buổi quy định</th>
                    <th className="p-2.5 text-center w-28 text-emerald-600 border-r border-slate-200 dark:border-slate-700">Số buổi ĐÃ NỘP</th>
                    <th className="p-2.5 text-center w-28 text-red-600 font-extrabold border-r border-slate-200 dark:border-slate-700">Số buổi THIẾU</th>
                    <th className="p-2.5 text-center w-28 border-r border-slate-200 dark:border-slate-700">Thiếu cả ngày</th>
                    <th className="p-2.5 text-center w-28 border-r border-slate-200 dark:border-slate-700">Tỷ lệ hoàn thành</th>
                    <th className="p-2.5 text-center w-36">Đánh giá chấp hành</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-800 bg-white dark:bg-slate-850">
                  {officerAudits
                    .filter(a => auditOfficerFilter ? a.officer.id === auditOfficerFilter : true)
                    .filter(a => auditStatusFilter === 'missed' ? a.missedSessionsTotal > 0 : true)
                    .map((a, idx) => (
                      <tr key={a.officer.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700">{idx + 1}</td>
                        <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                          {a.officer.name}
                        </td>
                        <td className="p-2.5 text-slate-600 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700">
                          {a.officer.role || 'Chuyên viên'}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold border-r border-slate-200 dark:border-slate-700">
                          {a.totalRequiredSessions} buổi ({periodWorkdays.length} ngày)
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-emerald-600 dark:text-emerald-400 border-r border-slate-200 dark:border-slate-700">
                          {a.submittedSessions} buổi
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-red-600 dark:text-red-400 border-r border-slate-200 dark:border-slate-700">
                          {a.missedSessionsTotal > 0 ? (
                            <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 rounded font-black">
                              {a.missedSessionsTotal} buổi
                            </span>
                          ) : (
                            <span className="text-emerald-600 font-normal">0</span>
                          )}
                        </td>
                        <td className="p-2.5 text-center font-mono text-slate-600 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700">
                          {a.missedFullDaysCount > 0 ? `${a.missedFullDaysCount} ngày` : '0'}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold border-r border-slate-200 dark:border-slate-700">
                          <span className={a.completionRate >= 90 ? 'text-emerald-600' : a.completionRate >= 75 ? 'text-amber-600' : 'text-red-600'}>
                            {a.completionRate}%
                          </span>
                        </td>
                        <td className="p-2.5 text-center">
                          {a.missedSessionsTotal === 0 ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Hoàn thành tốt
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-700 bg-red-50 dark:bg-red-950/40 px-2 py-0.5 rounded border border-red-200">
                              <AlertTriangle className="w-3 h-3 text-red-600" /> Cần chấn chỉnh ({a.missedSessionsTotal} buổi)
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            {/* Detailed Log Table of Specific Missed Dates & Sessions */}
            <div className="pt-2 space-y-3">
              <h5 className="font-bold text-xs text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-red-500" />
                Danh sách ngày & buổi cụ thể công chức từng lĩnh vực không thực hiện báo cáo ({pLabel})
              </h5>

              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700 max-h-80 overflow-y-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="sticky top-0 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="p-2.5 text-center w-12 border-r border-slate-200 dark:border-slate-700">STT</th>
                      <th className="p-2.5 text-center w-32 border-r border-slate-200 dark:border-slate-700">Ngày chưa nộp</th>
                      <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Họ và tên Cán bộ / Công chức</th>
                      <th className="p-2.5 border-r border-slate-200 dark:border-slate-700">Lĩnh vực phụ trách</th>
                      <th className="p-2.5 text-center w-48 border-r border-slate-200 dark:border-slate-700">Buổi thiếu báo cáo</th>
                      <th className="p-2.5 text-center w-36">Đánh giá kỷ luật</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-150 dark:divide-slate-800 bg-white dark:bg-slate-850">
                    {(() => {
                      const missedList: Array<{
                        date: string;
                        officerName: string;
                        position: string;
                        session: 'Sáng' | 'Chiều' | 'Cả ngày (Sáng & Chiều)';
                      }> = [];

                      officerAudits
                        .filter(a => auditOfficerFilter ? a.officer.id === auditOfficerFilter : true)
                        .forEach(a => {
                          a.missedDetails.forEach(m => {
                            missedList.push({
                              date: m.date,
                              officerName: a.officer.name,
                              position: a.officer.role || 'Chuyên viên',
                              session: m.missedSession
                            });
                          });
                        });

                      // Sort by date descending
                      missedList.sort((x, y) => y.date.localeCompare(x.date));

                      if (missedList.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="p-6 text-center text-emerald-600 dark:text-emerald-400 font-bold italic">
                              🎉 100% Công chức các lĩnh vực đã thực hiện đầy đủ báo cáo trong giai đoạn {pLabel}.
                            </td>
                          </tr>
                        );
                      }

                      return missedList.map((m, idx) => (
                        <tr key={`${m.officerName}-${m.date}-${m.session}-${idx}`} className="hover:bg-red-50/40 dark:hover:bg-red-950/20">
                          <td className="p-2.5 text-center font-bold border-r border-slate-200 dark:border-slate-700 text-slate-400">{idx + 1}</td>
                          <td className="p-2.5 text-center font-mono font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                            {m.date}
                          </td>
                          <td className="p-2.5 font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                            {m.officerName}
                          </td>
                          <td className="p-2.5 text-slate-600 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700">
                            {m.position}
                          </td>
                          <td className="p-2.5 text-center border-r border-slate-200 dark:border-slate-700">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                              m.session.includes('Cả ngày')
                                ? 'bg-red-100 dark:bg-red-900/60 text-red-800 dark:text-red-200'
                                : 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200'
                            }`}>
                              Thiếu Buổi {m.session}
                            </span>
                          </td>
                          <td className="p-2.5 text-center text-red-500 font-bold italic text-[11px]">
                            Chưa gửi báo cáo
                          </td>
                        </tr>
                      ));
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: SUBMIT REPORT FORM --- */}
      {activeTab === 'submit' && (
        <form onSubmit={handleSubmitReport} className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden p-6 space-y-6">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-800 dark:text-slate-200">Soạn & Cập nhật báo cáo chỉ tiêu hành chính</h3>
              <p className="text-xs text-slate-400 mt-1">
                Khung giờ quy định: Buổi Sáng ({reportConfig.morningStart} - {reportConfig.morningEnd}) & Chiều ({reportConfig.afternoonStart} - {reportConfig.afternoonEnd})
              </p>
            </div>

            {/* Time warning banner */}
            <div className={`p-2.5 rounded-lg border text-xs flex items-center gap-2 font-bold ${
              isCurrentSessionAllowed 
                ? 'bg-emerald-50 border-emerald-100 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-300' 
                : 'bg-red-50 border-red-200 text-red-700 dark:bg-red-950/20 dark:text-red-400'
            }`}>
              <Clock className="w-4 h-4 shrink-0" />
              <div>
                <p>Khung giờ hiện tại: {currentWindowLabel}</p>
                <p className="font-mono text-[10px] opacity-80">Giờ thực tế: {currentTime}</p>
              </div>
            </div>
          </div>

          {/* Status Mode Banner */}
          {!isCurrentSessionAllowed ? (
            <div className="p-3.5 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl flex items-start gap-3 text-xs text-red-800 dark:text-red-300">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-extrabold text-sm">⛔ Khóa chức năng nhập/sửa báo cáo ngoài khung giờ</p>
                <p className="mt-0.5 leading-relaxed">
                  {reportSession === 'morning' && isAfternoonWindow ? (
                    <span>Hiện tại đang trong <strong>Khung giờ Buổi Chiều</strong> ({reportConfig.afternoonStart} - {reportConfig.afternoonEnd}). Báo cáo Buổi Sáng chỉ được nộp/sửa vào buổi sáng ({reportConfig.morningStart} - {reportConfig.morningEnd}). Buổi chiều không được nhập lại hay sửa báo cáo buổi sáng.</span>
                  ) : reportSession === 'afternoon' && isMorningWindow ? (
                    <span>Hiện tại đang trong <strong>Khung giờ Buổi Sáng</strong> ({reportConfig.morningStart} - {reportConfig.morningEnd}). Báo cáo Buổi Chiều chỉ được nộp/sửa vào buổi chiều ({reportConfig.afternoonStart} - {reportConfig.afternoonEnd}).</span>
                  ) : (
                    <span>Hiện tại đang ngoài khung giờ quy định (Sáng: {reportConfig.morningStart}-{reportConfig.morningEnd}, Chiều: {reportConfig.afternoonStart}-{reportConfig.afternoonEnd}). Chuyên viên không thể nộp hoặc cập nhật báo cáo lúc này.</span>
                  )}
                </p>
              </div>
            </div>
          ) : (
            <div className={`p-3.5 border rounded-xl flex items-center justify-between text-xs ${
              dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId && (reportSession === 'morning' ? !!r.morning : !!r.afternoon))
                ? 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200'
                : 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
            }`}>
              <div className="flex items-center gap-2.5">
                <span className="text-lg">
                  {dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId && (reportSession === 'morning' ? !!r.morning : !!r.afternoon)) ? '✏️' : '📝'}
                </span>
                <div>
                  <p className="font-extrabold text-sm">
                    {dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId && (reportSession === 'morning' ? !!r.morning : !!r.afternoon))
                      ? 'Đang ở chế độ: Chỉnh sửa & Cập nhật Báo cáo'
                      : 'Đang ở chế độ: Nhập Báo cáo Mới'}
                  </p>
                  <p className="opacity-90 mt-0.5">
                    Cán bộ: <span className="font-bold">{officers.find(o => o.id === reportingOfficerId)?.name || 'Chưa chọn'}</span> | Phiên: <span className="font-bold">Buổi {reportSession === 'morning' ? 'Sáng' : 'Chiều'}</span> | Ngày: <span className="font-mono font-bold">{selectedDate}</span>
                  </p>
                </div>
              </div>
              {dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId && (reportSession === 'morning' ? !!r.morning : !!r.afternoon)) && (
                <span className="px-2.5 py-1 bg-blue-600 text-white font-bold rounded-lg text-[11px] shrink-0">
                  Đã có dữ liệu - Sẵn sàng cập nhật
                </span>
              )}
            </div>
          )}

          {/* Connected Records Real-time Banner */}
          {(() => {
            const selectedOfficerObj = officers.find(o => o.id === reportingOfficerId);
            const selectedOfficerName = selectedOfficerObj?.name || '';
            const dateRecords = records.filter(r => r.createdDate === selectedDate);
            const officerRecordsToday = selectedOfficerName
              ? dateRecords.filter(r => (r.officerName || '').toLowerCase().trim() === selectedOfficerName.toLowerCase().trim())
              : dateRecords;

            const m02Count = officerRecordsToday.filter(r => r.formType === 'mau02').length;
            const m03Count = officerRecordsToday.filter(r => r.formType === 'mau03').length;
            const m05Count = officerRecordsToday.filter(r => r.formType === 'mau05').length;
            const totalRecordsToday = officerRecordsToday.length;

            return (
              <div className="p-3.5 bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs text-indigo-900 dark:text-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
                <div className="flex items-start gap-2.5">
                  <Link className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm">Kết nối Dữ liệu Phiếu đã lập trong ngày ({selectedDate})</span>
                      <span className="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded-full">
                        Tức thì & Tự động
                      </span>
                    </div>
                    <p className="mt-1 text-slate-600 dark:text-slate-300 leading-relaxed">
                      Chuyên viên <strong className="text-indigo-900 dark:text-indigo-100">{selectedOfficerName || 'tất cả'}</strong> đã lập tổng cộng <strong className="text-indigo-700 dark:text-indigo-300 font-bold">{totalRecordsToday} Phiếu hành chính</strong> trong ngày:
                      <span className="ml-1 font-semibold">({m02Count} Mẫu 02 - Bổ sung, {m03Count} Mẫu 03 - Từ chối, {m05Count} Mẫu 05 - Dừng giải quyết)</span>.
                    </p>
                  </div>
                </div>
                {totalRecordsToday > 0 && (
                  <div className="shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        alert(`🔗 Hệ thống tự động kết nối thành công: Đã ghi nhận ${totalRecordsToday} Phiếu đã lập vào hệ thống cơ sở dữ liệu báo cáo.`);
                      }}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm flex items-center gap-1.5 transition-all text-xs cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      Kết nối dữ liệu
                    </button>
                  </div>
                )}
              </div>
            );
          })()}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Officer select */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Cán bộ báo cáo</label>
              <select
                disabled={currentUser?.role === 'officer'}
                value={reportingOfficerId}
                onChange={(e) => setReportingOfficerId(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer disabled:opacity-60"
              >
                <option value="">-- Chọn chuyên viên --</option>
                {specialistOfficers.map(o => (
                  <option key={o.id} value={o.id}>{o.name} ({o.role})</option>
                ))}
              </select>
            </div>

            {/* Session select */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Phiên làm việc</label>
              <select
                value={reportSession}
                onChange={(e) => handleSessionChange(e.target.value as any)}
                className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer"
              >
                <option value="morning">🌅 Báo cáo Buổi Sáng (Khung giờ: {reportConfig.morningStart} - {reportConfig.morningEnd})</option>
                <option value="afternoon">🌇 Báo cáo Buổi Chiều (Khung giờ: {reportConfig.afternoonStart} - {reportConfig.afternoonEnd})</option>
              </select>
            </div>

            {/* Date Select */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Ngày lập báo cáo</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Section Indicators Table Input Form */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-l-4 border-blue-600 pl-2">
              Chỉ tiêu tiếp nhận & Lệ phí buổi {reportSession === 'morning' ? 'Sáng' : 'Chiều'}
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Box 1: Chứng thực bản sao */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-3">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase">1. Chứng thực bản sao</h5>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctBanSao_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, ctBanSao_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase mb-0.5" title="Số hồ sơ hướng dẫn">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctBanSao_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, ctBanSao_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none text-center font-mono font-bold text-amber-700 dark:text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Số Bản</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctBanSao_ban}
                      onChange={(e) => setSectionData({ ...sectionData, ctBanSao_ban: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Tiền (đ)</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctBanSao_tien}
                      onChange={(e) => setSectionData({ ...sectionData, ctBanSao_tien: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-right font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Box 2: Chứng thực chữ ký */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-3">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase">2. Chứng thực chữ ký</h5>
                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctChuKy_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, ctChuKy_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase mb-0.5" title="Số hồ sơ hướng dẫn">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctChuKy_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, ctChuKy_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none text-center font-mono font-bold text-amber-700 dark:text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Số Bản</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctChuKy_ban}
                      onChange={(e) => setSectionData({ ...sectionData, ctChuKy_ban: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Tiền (đ)</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.ctChuKy_tien}
                      onChange={(e) => setSectionData({ ...sectionData, ctChuKy_tien: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-right font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Box 3: Hộ tịch */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-3">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase">3. Hộ tịch</h5>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Số hồ sơ</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.hoTich_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, hoTich_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase mb-0.5" title="Số hồ sơ hướng dẫn">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.hoTich_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, hoTich_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none text-center font-mono font-bold text-amber-700 dark:text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Lệ phí (đ)</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.hoTich_tien}
                      onChange={(e) => setSectionData({ ...sectionData, hoTich_tien: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-right font-mono font-bold"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Other fields dossier counts */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">4. Kinh tế</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[9px] text-slate-400 font-medium">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.kinhTe_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, kinhTe_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-amber-600 dark:text-amber-400 font-medium">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.kinhTe_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, kinhTe_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none font-mono font-bold text-center text-amber-700 dark:text-amber-300"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">5. Đất đai - Môi trường</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[9px] text-slate-400 font-medium">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.datDaiMoiTruong_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, datDaiMoiTruong_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-amber-600 dark:text-amber-400 font-medium">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.datDaiMoiTruong_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, datDaiMoiTruong_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none font-mono font-bold text-center text-amber-700 dark:text-amber-300"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">6. Hạ tầng - Đô thị</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[9px] text-slate-400 font-medium">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.haTangDoThi_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, haTangDoThi_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-amber-600 dark:text-amber-400 font-medium">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.haTangDoThi_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, haTangDoThi_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none font-mono font-bold text-center text-amber-700 dark:text-amber-300"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">7. Văn hóa - Xã hội</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[9px] text-slate-400 font-medium">Số HS</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.vanHoaXaHoi_hoSo}
                      onChange={(e) => setSectionData({ ...sectionData, vanHoaXaHoi_hoSo: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-amber-600 dark:text-amber-400 font-medium">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.vanHoaXaHoi_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, vanHoaXaHoi_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none font-mono font-bold text-center text-amber-700 dark:text-amber-300"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* BHYT & Ngành dọc */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase">8. Bảo hiểm Y tế</h5>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Trường hợp</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.bhYTe_truongHop}
                      onChange={(e) => setSectionData({ ...sectionData, bhYTe_truongHop: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase mb-0.5" title="Số hồ sơ hướng dẫn">H.Dẫn</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.bhYTe_huongDan || 0}
                      onChange={(e) => setSectionData({ ...sectionData, bhYTe_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none font-mono font-bold text-center text-amber-700 dark:text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Tiền (đ)</label>
                    <input
                      type="number"
                      min={0}
                      value={sectionData.bhYTe_tien}
                      onChange={(e) => setSectionData({ ...sectionData, bhYTe_tien: Math.max(0, parseInt(e.target.value) || 0) })}
                      className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-right font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Ngành dọc */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-850 rounded-xl space-y-2 sm:col-span-2">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase">Ngành dọc tiếp nhận liên thông</h5>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">Thuế</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[9px] text-slate-400">Số HS</label>
                        <input
                          type="number"
                          min={0}
                          value={sectionData.nganhDoc_thue}
                          onChange={(e) => setSectionData({ ...sectionData, nganhDoc_thue: Math.max(0, parseInt(e.target.value) || 0) })}
                          className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-amber-600 dark:text-amber-400">H.Dẫn</label>
                        <input
                          type="number"
                          min={0}
                          value={sectionData.nganhDoc_thue_huongDan || 0}
                          onChange={(e) => setSectionData({ ...sectionData, nganhDoc_thue_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                          className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none text-center font-mono font-bold text-amber-700 dark:text-amber-300"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">BHXH</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[9px] text-slate-400">Số HS</label>
                        <input
                          type="number"
                          min={0}
                          value={sectionData.nganhDoc_bhxh}
                          onChange={(e) => setSectionData({ ...sectionData, nganhDoc_bhxh: Math.max(0, parseInt(e.target.value) || 0) })}
                          className="w-full text-xs px-2 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded focus:outline-none text-center font-mono font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-amber-600 dark:text-amber-400">H.Dẫn</label>
                        <input
                          type="number"
                          min={0}
                          value={sectionData.nganhDoc_bhxh_huongDan || 0}
                          onChange={(e) => setSectionData({ ...sectionData, nganhDoc_bhxh_huongDan: Math.max(0, parseInt(e.target.value) || 0) })}
                          className="w-full text-xs px-2 py-1.5 border border-amber-200 dark:border-amber-700/50 bg-amber-50/30 dark:bg-amber-950/20 rounded focus:outline-none text-center font-mono font-bold text-amber-700 dark:text-amber-300"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Paper dossiers direct receipt table (Pink Table) */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider border-l-4 border-pink-500 pl-2">
              Số lượng hồ sơ tiếp nhận trực tiếp trong ngày (Hồ sơ GIẤY)
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">Hộ tịch</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.hoTich}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, hoTich: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>

              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">Đất đai</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.datDai}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, datDai: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>

              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">TN - Môi trường</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.taiNguyenMoiTruong}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, taiNguyenMoiTruong: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>

              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">Tư pháp</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.hoTich2}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, hoTich2: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>

              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">Bảo trợ XH</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.baoTroXaHoi}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, baoTroXaHoi: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>

              <div className="p-3 bg-pink-50/20 dark:bg-pink-950/5 border border-pink-100 dark:border-pink-950 rounded-xl space-y-1">
                <label className="block text-[10px] font-bold text-pink-700 dark:text-pink-400 uppercase">Hạ tầng - Đô thị</label>
                <input
                  type="number"
                  min={0}
                  value={paperDossiers.haTangDoThi}
                  onChange={(e) => setPaperDossiers({ ...paperDossiers, haTangDoThi: Math.max(0, parseInt(e.target.value) || 0) })}
                  className="w-full text-xs px-2 py-1 border border-pink-200 dark:border-pink-900 dark:bg-slate-800 rounded focus:outline-none font-mono font-bold text-center"
                />
              </div>
            </div>
          </div>

          {/* Difficulties and Suggestions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">🚨 Khó khăn, vướng mắc trong ngày (nếu có)</label>
              <textarea
                rows={3}
                value={difficulties}
                onChange={(e) => setDifficulties(e.target.value)}
                placeholder="Ghi nhận cụ thể các hồ sơ ách tắc hoặc lỗi phần mềm một cửa..."
                className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-lg focus:outline-none resize-none text-justify"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">💡 Đề xuất, kiến nghị, giải pháp (nếu có)</label>
              <textarea
                rows={3}
                value={suggestions}
                onChange={(e) => setSuggestions(e.target.value)}
                placeholder="Đề nghị bổ sung thêm phôi chứng thực hoặc thiết bị scan hồ sơ..."
                className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-lg focus:outline-none resize-none text-justify"
              />
            </div>
          </div>

          {/* Override Checkbox if outside limit */}
          {!canReportNow && currentUser?.role === 'admin' && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-xl border border-amber-200 flex items-start gap-3 text-xs">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-amber-800 dark:text-amber-300">Admin Bypass Mode</p>
                <p className="text-amber-700 dark:text-amber-400 mb-2">Hệ thống đang ở ngoài khung giờ báo cáo tiêu chuẩn. Bạn là Admin nên có quyền gửi ghi đè.</p>
                <label className="flex items-center gap-2 cursor-pointer font-bold text-amber-900">
                  <input
                    type="checkbox"
                    checked={forceSubmit}
                    onChange={(e) => setForceSubmit(e.target.checked)}
                    className="rounded border-amber-300 text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                  />
                  Xác nhận nộp báo cáo ngoài giờ hành chính
                </label>
              </div>
            </div>
          )}

          {/* Submit Action */}
          <div className="flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-4">
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 rounded-lg font-bold text-xs cursor-pointer"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              disabled={!isCurrentSessionAllowed}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 dark:disabled:bg-slate-800 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-bold rounded-lg text-xs cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
            >
              {dailyReports.find(r => r.date === selectedDate && r.officerId === reportingOfficerId && (reportSession === 'morning' ? !!r.morning : !!r.afternoon)) ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" /> Cập nhật Báo cáo
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" /> Gửi báo cáo
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* --- TAB 3: CONFIGURATION --- */}
      {activeTab === 'config' && currentUser?.role === 'admin' && (
        <form onSubmit={handleSaveConfig} className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6 max-w-xl no-print">
          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200">Cấu hình khung giờ báo cáo</h3>
            <p className="text-xs text-slate-400 mt-1">Thiết lập thời gian bắt đầu và kết thúc việc nộp báo cáo hàng ngày của cán bộ</p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {/* Morning box */}
            <div className="space-y-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-150">
              <h4 className="text-xs font-bold text-slate-700 uppercase">Khung giờ buổi Sáng</h4>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Thời gian nhận (E.g., 10:30)</label>
                <input
                  type="text"
                  required
                  value={cfgMorningStart}
                  onChange={(e) => setCfgMorningStart(e.target.value)}
                  className="w-full text-xs px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded font-mono font-semibold"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Khóa lúc (E.g., 12:00)</label>
                <input
                  type="text"
                  required
                  value={cfgMorningEnd}
                  onChange={(e) => setCfgMorningEnd(e.target.value)}
                  className="w-full text-xs px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded font-mono font-semibold"
                />
              </div>
            </div>

            {/* Afternoon box */}
            <div className="space-y-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-150">
              <h4 className="text-xs font-bold text-slate-700 uppercase">Khung giờ buổi Chiều</h4>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Thời gian nhận (E.g., 15:30)</label>
                <input
                  type="text"
                  required
                  value={cfgAfternoonStart}
                  onChange={(e) => setCfgAfternoonStart(e.target.value)}
                  className="w-full text-xs px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded font-mono font-semibold"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Khóa lúc (E.g., 18:00)</label>
                <input
                  type="text"
                  required
                  value={cfgAfternoonEnd}
                  onChange={(e) => setCfgAfternoonEnd(e.target.value)}
                  className="w-full text-xs px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded font-mono font-semibold"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 rounded-lg font-bold text-xs cursor-pointer"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs cursor-pointer transition-colors"
            >
              Lưu cấu hình
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
