import React from 'react';
import { Record } from '../types';
import { PrintService } from '../services/PrintService';
import { Printer } from 'lucide-react';
import { logAudit } from '../utils';

interface PrintButtonProps {
  record: Record;
  printRef?: React.RefObject<HTMLDivElement | null>;
  className?: string;
  onClick?: () => void;
  currentUser?: { username: string };
}

export default function PrintButton({ record, printRef, className, onClick, currentUser }: PrintButtonProps) {
  const handlePrint = () => {
    if (onClick) {
      onClick();
    }
    
    // Log the print action
    const username = currentUser?.username || 'Cán bộ';
    logAudit(
      username,
      'In Phiếu',
      `In phiếu quy trình số ${record.ticketNo || 'N/A'} cho công dân ${record.citizenName || 'N/A'}`
    );

    // If a ref is provided, print its contents, otherwise fall back to programmatic text printing
    if (printRef?.current) {
      const contents = printRef.current.innerHTML;
      PrintService.printHtml(contents, `In Phieu - ${record.ticketNo}`);
    } else {
      // Direct window.print of current page as fallback
      window.print();
    }
  };

  return (
    <button
      onClick={handlePrint}
      className={className || "flex items-center gap-1.5 px-3.5 py-1.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors cursor-pointer"}
      id={`btn-print-${record.id}`}
      title="In trực tiếp ra máy in hành chính"
    >
      <Printer className="w-4 h-4" />
      In Phiếu
    </button>
  );
}
