import React, { useState } from 'react';
import { Record } from '../types';
import { PdfService } from '../services/PdfService';
import { FileText, Loader2 } from 'lucide-react';
import { logAudit } from '../utils';

interface ExportPdfButtonProps {
  record: Record;
  className?: string;
  onClick?: () => void;
  currentUser?: { username: string };
}

export default function ExportPdfButton({ record, className, onClick, currentUser }: ExportPdfButtonProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleExportPDF = async () => {
    if (onClick) {
      onClick();
    }

    setIsGenerating(true);

    try {
      // 1. Generate standard administrative PDF via service
      const doc = await PdfService.generateDocument(record);
      
      // 2. Determine correct filename according to the spec:
      // Format: Phieu_[Loại phiếu]_[Mã hồ sơ]_[Ngày].pdf
      const filename = PdfService.getFilename(record);
      
      // 3. Save standard PDF
      doc.save(filename);

      // 4. Log audit action
      const username = currentUser?.username || 'Cán bộ';
      logAudit(
        username,
        'Xuất PDF',
        `Xuất file PDF ký số cho hồ sơ số ${record.recordId || record.ticketNo || 'N/A'}`
      );
    } catch (error) {
      console.error('Failed to export PDF:', error);
      alert('Đã xảy ra lỗi khi tạo file PDF. Vui lòng thử lại.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <button
      onClick={handleExportPDF}
      disabled={isGenerating}
      className={className || "flex items-center gap-1.5 px-3.5 py-1.5 text-sm font-medium text-white bg-red-600 hover:bg-red-700 disabled:bg-red-400 rounded-lg shadow-sm transition-colors cursor-pointer"}
      id={`btn-pdf-${record.id}`}
      title="Xuất file PDF định dạng vector hỗ trợ ký số"
    >
      {isGenerating ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          Đang xuất...
        </>
      ) : (
        <>
          <FileText className="w-4 h-4" />
          Xuất PDF
        </>
      )}
    </button>
  );
}
