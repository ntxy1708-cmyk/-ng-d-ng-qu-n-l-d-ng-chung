import React, { useState } from 'react';
import { Officer } from '../types';
import { 
  Search, Plus, Edit, Trash2, FileSpreadsheet, Check, X, ShieldAlert, Users, Phone, Calendar, Award, BookOpen, UserCheck, IdCard, DollarSign, MapPin, Flag, Mail, FileText
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface OfficerManagementViewProps {
  officers: Officer[];
  onAddOfficer: (officer: Omit<Officer, 'id'>) => Promise<void>;
  onDeleteOfficer: (id: string) => Promise<void>;
  onUpdateOfficer: (id: string, officer: Partial<Officer>) => Promise<void>;
  currentUser: { username: string; role: string } | null;
}

// Helper to calculate age from DOB string: actual year minus birth year, auto-updating each year
export const calculateAge = (dobStr?: string): string | number => {
  if (!dobStr || !dobStr.trim()) return '—';
  const dateOnly = dobStr.trim().split('T')[0];
  const parts = dateOnly.split(/[\/\-]/);
  let year = 0;

  if (parts.length === 3) {
    if (parts[0].length === 4) {
      year = parseInt(parts[0], 10);
    } else if (parts[2].length === 4) {
      year = parseInt(parts[2], 10);
    } else if (parts[2].length === 2) {
      const y2 = parseInt(parts[2], 10);
      year = y2 > 30 ? 1900 + y2 : 2000 + y2;
    }
  } else if (parts.length === 1) {
    const cleanDigits = parts[0].replace(/\D/g, '');
    if (cleanDigits.length === 4) {
      year = parseInt(cleanDigits, 10);
    }
  }

  const currentYear = new Date().getFullYear();
  if (!year || isNaN(year) || year < 1920 || year > currentYear) return '—';

  const age = currentYear - year;
  return age >= 0 ? age : '—';
};

export default function OfficerManagementView({
  officers,
  onAddOfficer,
  onDeleteOfficer,
  onUpdateOfficer,
  currentUser
}: OfficerManagementViewProps) {
  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [partyFilter, setPartyFilter] = useState<'all' | 'party' | 'non_party'>('all');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  // Age Filter state
  const [ageFilter, setAgeFilter] = useState<'all' | 'under_30' | '30_40' | '41_50' | '51_60' | 'over_60' | 'custom'>('all');
  const [customMinAge, setCustomMinAge] = useState<string>('');
  const [customMaxAge, setCustomMaxAge] = useState<string>('');

  // Modal State for Create / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOfficerId, setEditingOfficerId] = useState<string | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formDob, setFormDob] = useState('');
  const [formRole, setFormRole] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formLevel, setFormLevel] = useState('');
  const [formMajor, setFormMajor] = useState('');
  const [formIt, setFormIt] = useState('');
  const [formLanguage, setFormLanguage] = useState('');
  const [formPolitical, setFormPolitical] = useState('');
  const [formIsPartyMember, setFormIsPartyMember] = useState(false);
  
  // Additional new fields: Hệ số lương, CCCD, Địa chỉ, Ngày vào Đảng, Email, Dân tộc, Quê quán, Ghi chú
  const [formSalaryCoeff, setFormSalaryCoeff] = useState('');
  const [formCitizenId, setFormCitizenId] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formPartyJoinDate, setFormPartyJoinDate] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formEthnicity, setFormEthnicity] = useState('');
  const [formHometown, setFormHometown] = useState('');
  const [formNotes, setFormNotes] = useState('');

  // Check permission (Admin can do CRUD, other staff can only view and export)
  const canManage = currentUser?.role === 'admin';

  // Get unique values for filters
  const levels = Array.from(new Set(officers.map(o => o.level).filter(Boolean))) as string[];
  const roles = Array.from(new Set(officers.map(o => o.role).filter(Boolean))) as string[];

  // Filter officers
  const filteredOfficers = officers.filter(o => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      o.name.toLowerCase().includes(searchLower) ||
      o.role.toLowerCase().includes(searchLower) ||
      (o.phone || '').includes(searchTerm) ||
      (o.citizenId || '').includes(searchTerm) ||
      (o.address || '').toLowerCase().includes(searchLower) ||
      (o.salaryCoeff || '').includes(searchTerm) ||
      (o.email || '').toLowerCase().includes(searchLower) ||
      (o.major?.toLowerCase() || '').includes(searchLower) ||
      (o.level?.toLowerCase() || '').includes(searchLower);

    const matchesParty = 
      partyFilter === 'all' ? true :
      partyFilter === 'party' ? o.isPartyMember === true :
      o.isPartyMember !== true;

    const matchesLevel = 
      levelFilter === 'all' ? true :
      o.level === levelFilter;

    const matchesRole = 
      roleFilter === 'all' ? true :
      o.role === roleFilter;

    // Age calculation & filtering (actual year - birth year)
    const ageVal = calculateAge(o.dob);
    const numericAge = typeof ageVal === 'number' ? ageVal : null;

    let matchesAge = true;
    if (ageFilter === 'under_30') {
      matchesAge = numericAge !== null && numericAge < 30;
    } else if (ageFilter === '30_40') {
      matchesAge = numericAge !== null && numericAge >= 30 && numericAge <= 40;
    } else if (ageFilter === '41_50') {
      matchesAge = numericAge !== null && numericAge >= 41 && numericAge <= 50;
    } else if (ageFilter === '51_60') {
      matchesAge = numericAge !== null && numericAge >= 51 && numericAge <= 60;
    } else if (ageFilter === 'over_60') {
      matchesAge = numericAge !== null && numericAge > 60;
    } else if (ageFilter === 'custom') {
      if (numericAge === null) {
        matchesAge = false;
      } else {
        const min = customMinAge ? parseInt(customMinAge, 10) : 0;
        const max = customMaxAge ? parseInt(customMaxAge, 10) : 200;
        matchesAge = numericAge >= min && numericAge <= max;
      }
    }

    return matchesSearch && matchesParty && matchesLevel && matchesRole && matchesAge;
  });

  // Calculate statistics for filtered list
  const validAges = filteredOfficers
    .map(o => calculateAge(o.dob))
    .filter((a): a is number => typeof a === 'number');
  
  const avgAge = validAges.length > 0 
    ? (validAges.reduce((sum, val) => sum + val, 0) / validAges.length).toFixed(1) 
    : null;

  const openAddModal = () => {
    setEditingOfficerId(null);
    setFormName('');
    setFormDob('');
    setFormRole('Chuyên viên');
    setFormPhone('');
    setFormLevel('');
    setFormMajor('');
    setFormIt('');
    setFormLanguage('');
    setFormPolitical('');
    setFormIsPartyMember(false);
    setFormSalaryCoeff('');
    setFormCitizenId('');
    setFormAddress('');
    setFormPartyJoinDate('');
    setFormEmail('');
    setFormEthnicity('Kinh');
    setFormHometown('');
    setFormNotes('');
    setIsModalOpen(true);
  };

  const openEditModal = (o: Officer) => {
    setEditingOfficerId(o.id);
    setFormName(o.name || '');
    setFormDob(o.dob || '');
    setFormRole(o.role || '');
    setFormPhone(o.phone || '');
    setFormLevel(o.level || '');
    setFormMajor(o.major || '');
    setFormIt(o.it || '');
    setFormLanguage(o.language || '');
    setFormPolitical(o.political || '');
    setFormIsPartyMember(!!o.isPartyMember);
    setFormSalaryCoeff(o.salaryCoeff || '');
    setFormCitizenId(o.citizenId || '');
    setFormAddress(o.address || '');
    setFormPartyJoinDate(o.partyJoinDate || '');
    setFormEmail(o.email || '');
    setFormEthnicity(o.ethnicity || 'Kinh');
    setFormHometown(o.hometown || '');
    setFormNotes(o.notes || '');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formRole.trim()) {
      alert('Vui lòng điền đủ các thông tin bắt buộc: Họ tên và Chức vụ!');
      return;
    }

    const payload: Partial<Officer> = {
      name: formName.trim(),
      dob: formDob.trim(),
      role: formRole.trim(),
      phone: formPhone.trim(),
      level: formLevel.trim(),
      major: formMajor.trim(),
      it: formIt.trim(),
      language: formLanguage.trim(),
      political: formPolitical.trim(),
      isPartyMember: formIsPartyMember,
      salaryCoeff: formSalaryCoeff.trim(),
      citizenId: formCitizenId.trim(),
      address: formAddress.trim(),
      partyJoinDate: formPartyJoinDate.trim(),
      email: formEmail.trim(),
      ethnicity: formEthnicity.trim(),
      hometown: formHometown.trim(),
      notes: formNotes.trim()
    };

    try {
      if (editingOfficerId) {
        await onUpdateOfficer(editingOfficerId, payload);
        alert('Cập nhật thông tin cán bộ thành công!');
      } else {
        await onAddOfficer(payload as Omit<Officer, 'id'>);
        alert('Thêm mới cán bộ thành công!');
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
      alert('Đã có lỗi xảy ra khi lưu thông tin.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Bạn có chắc chắn muốn xóa cán bộ "${name}" khỏi hệ thống?`)) return;
    try {
      await onDeleteOfficer(id);
      alert('Xóa cán bộ thành công!');
    } catch (err) {
      console.error(err);
      alert('Đã có lỗi xảy ra khi xóa.');
    }
  };

  // Export to Excel
  const exportToExcel = () => {
    if (filteredOfficers.length === 0) {
      alert('Không có dữ liệu cán bộ để trích xuất!');
      return;
    }

    const data = filteredOfficers.map((o, index) => ({
      'STT': index + 1,
      'Họ và tên': o.name,
      'Ngày sinh': o.dob || '',
      'Tuổi': calculateAge(o.dob),
      'Số CCCD / Định danh': o.citizenId || '',
      'Hệ số lương': o.salaryCoeff || '',
      'Chức vụ': o.role,
      'Số điện thoại': o.phone,
      'Email': o.email || '',
      'Địa chỉ': o.address || '',
      'Đảng viên': o.isPartyMember ? 'Có' : 'Không',
      'Ngày vào Đảng': o.partyJoinDate || '',
      'Trình độ chuyên môn': o.level || '',
      'Chuyên ngành đào tạo': o.major || '',
      'Lý luận chính trị': o.political || '',
      'Tin học': o.it || '',
      'Ngoại ngữ': o.language || '',
      'Dân tộc': o.ethnicity || '',
      'Quê quán': o.hometown || '',
      'Ghi chú': o.notes || ''
    }));

    const ws = XLSX.utils.json_to_sheet([]);
    
    // Add title rows
    XLSX.utils.sheet_add_aoa(ws, [
      ['DANH SÁCH CÁN BỘ, CÔNG CHỨC LÝ LỊCH TRÍCH NGANG'],
      ['TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG PHƯỜNG CẦU KIỆU'],
      [''],
    ], { origin: 'A1' });

    // Add main data table
    XLSX.utils.sheet_add_json(ws, data, { origin: 'A4', skipHeader: false });

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Danh sách Cán bộ');

    // Auto fit column widths
    const max_len = [5, 25, 14, 8, 18, 12, 25, 15, 25, 35, 12, 15, 18, 35, 18, 20, 15, 12, 25, 25];
    ws['!cols'] = max_len.map(w => ({ wch: w }));

    XLSX.writeFile(wb, `Danh_sach_Can_bo_Cau_Kieu_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header and stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide text-sm">
              Quản lý Cán bộ, Công chức Trung tâm
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Tra cứu, cập nhật lý lịch cán bộ (Hệ số lương, Số CCCD, Địa chỉ, Ngày vào Đảng, Trình độ...)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportToExcel}
            className="flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900 rounded-lg py-2 px-3 hover:bg-emerald-100 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" /> Trích xuất Excel ({filteredOfficers.length})
          </button>

          {canManage && (
            <button
              onClick={openAddModal}
              className="flex items-center justify-center gap-1 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" /> Thêm cán bộ mới
            </button>
          )}
        </div>
      </div>

      {/* Filter panel */}
      <div className="bg-white dark:bg-slate-855 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-blue-500" /> Bộ lọc & Tìm kiếm cán bộ
          </h4>

          {/* Age & Record statistics summary */}
          <div className="flex items-center gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold border border-slate-200 dark:border-slate-700">
              Tổng số: <strong className="text-blue-600 dark:text-blue-400">{filteredOfficers.length}</strong> / {officers.length} cán bộ
            </span>
            {avgAge && (
              <span className="px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 font-semibold border border-blue-100 dark:border-blue-900 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-blue-500" />
                Độ tuổi trung bình: <strong>{avgAge} tuổi</strong>
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Text search */}
          <div className="relative lg:col-span-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Họ tên, CCCD, HS lương, SĐT, địa chỉ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Age Filter */}
          <div>
            <select
              value={ageFilter}
              onChange={(e) => setAgeFilter(e.target.value as any)}
              className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer font-medium bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              <option value="all">🎂 Tất cả độ tuổi</option>
              <option value="under_30">Dưới 30 tuổi (&lt; 30 tuổi)</option>
              <option value="30_40">Từ 30 đến 40 tuổi</option>
              <option value="41_50">Từ 41 đến 50 tuổi</option>
              <option value="51_60">Từ 51 đến 60 tuổi</option>
              <option value="over_60">Trên 60 tuổi (&gt; 60 tuổi)</option>
              <option value="custom">⚙️ Tùy chỉnh khoảng tuổi...</option>
            </select>
          </div>

          {/* Role Filter */}
          <div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">Tất cả Chức vụ</option>
              {roles.map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {/* Level Filter */}
          <div>
            <select
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">Tất cả Trình độ</option>
              {levels.map(l => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>

          {/* Party member Filter */}
          <div>
            <select
              value={partyFilter}
              onChange={(e) => setPartyFilter(e.target.value as any)}
              className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none cursor-pointer"
            >
              <option value="all">Tất cả (Đảng viên & Quần chúng)</option>
              <option value="party">Chỉ Đảng viên</option>
              <option value="non_party">Chỉ Quần chúng</option>
            </select>
          </div>
        </div>

        {/* Custom Age Inputs (shown when ageFilter === 'custom') */}
        {ageFilter === 'custom' && (
          <div className="flex items-center gap-3 p-3 bg-blue-50/60 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900 rounded-lg animate-in fade-in duration-150">
            <span className="text-xs font-bold text-blue-900 dark:text-blue-300 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-600" /> Nhập khoảng tuổi:
            </span>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="18"
                max="100"
                placeholder="Từ tuổi (vd: 25)"
                value={customMinAge}
                onChange={(e) => setCustomMinAge(e.target.value)}
                className="w-32 text-xs px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-md focus:outline-none focus:border-blue-500 font-mono"
              />
              <span className="text-xs text-slate-400 font-bold">-</span>
              <input
                type="number"
                min="18"
                max="100"
                placeholder="Đến tuổi (vd: 45)"
                value={customMaxAge}
                onChange={(e) => setCustomMaxAge(e.target.value)}
                className="w-32 text-xs px-2.5 py-1.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-md focus:outline-none focus:border-blue-500 font-mono"
              />
              {(customMinAge || customMaxAge) && (
                <button
                  type="button"
                  onClick={() => { setCustomMinAge(''); setCustomMaxAge(''); }}
                  className="text-[11px] text-slate-500 hover:text-red-600 underline cursor-pointer ml-2"
                >
                  Xóa lọc tuổi
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Officers List Table */}
      <div className="bg-white dark:bg-slate-855 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs text-nowrap">
            <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-3 w-10 text-center">STT</th>
                <th className="py-3 px-3">Họ và tên</th>
                <th className="py-3 px-3">Ngày sinh</th>
                <th className="py-3 px-3 text-center">Tuổi</th>
                <th className="py-3 px-3">CCCD / Định danh</th>
                <th className="py-3 px-3 text-center">Hệ số lương</th>
                <th className="py-3 px-3">Chức vụ</th>
                <th className="py-3 px-3">Số điện thoại</th>
                <th className="py-3 px-3">Địa chỉ thường trú</th>
                <th className="py-3 px-3">Trình độ / Chuyên ngành</th>
                <th className="py-3 px-3">Đảng viên / Ngày vào Đảng</th>
                <th className="py-3 px-3 text-center">Hành động</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredOfficers.map((o, idx) => (
                <tr key={o.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 text-center text-slate-400 font-mono font-bold">{idx + 1}</td>
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-800 dark:text-slate-200">{o.name}</p>
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-700 dark:text-slate-300 font-medium">
                    {o.dob || <span className="text-slate-300 italic">—</span>}
                  </td>
                  <td className="py-3 px-3 text-center font-mono">
                    {calculateAge(o.dob) !== '—' ? (
                      <span className="bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-400 border border-blue-100 dark:border-blue-900 font-bold px-2 py-0.5 rounded text-[11px]">
                        {calculateAge(o.dob)} tuổi
                      </span>
                    ) : (
                      <span className="text-slate-300 italic">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold text-slate-700 dark:text-slate-300">
                    {o.citizenId ? (
                      <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                        {o.citizenId}
                      </span>
                    ) : (
                      <span className="text-slate-300 italic">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {o.salaryCoeff ? (
                      <span className="bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900 font-mono font-bold px-2 py-0.5 rounded text-[11px]">
                        {o.salaryCoeff}
                      </span>
                    ) : (
                      <span className="text-slate-300 italic">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300 font-medium">{o.role}</td>
                  <td className="py-3 px-3 font-mono text-slate-600 dark:text-slate-400">
                    {o.phone || <span className="text-slate-300 italic">—</span>}
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400 max-w-[180px] truncate" title={o.address}>
                    {o.address || <span className="text-slate-300 italic">—</span>}
                  </td>
                  <td className="py-3 px-3">
                    <div className="space-y-0.5 max-w-[180px] truncate" title={`${o.level || ''} - ${o.major || ''}`}>
                      {o.level && (
                        <span className="bg-blue-50 dark:bg-blue-950/20 text-blue-600 dark:text-blue-400 font-bold px-1.5 py-0.5 rounded text-[10px] mr-1">
                          {o.level}
                        </span>
                      )}
                      <span className="text-slate-500 italic text-[11px]">{o.major || '—'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    {o.isPartyMember ? (
                      <div className="space-y-0.5">
                        <span className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 font-bold px-2 py-0.5 rounded text-[10px] inline-flex items-center gap-1">
                          <Check className="w-3 h-3" /> Đảng viên
                        </span>
                        {o.partyJoinDate && (
                          <p className="text-[10px] text-slate-400 font-mono">Vào Đảng: {o.partyJoinDate}</p>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => openEditModal(o)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-200 rounded cursor-pointer transition-colors"
                        title={canManage ? "Chỉnh sửa lý lịch" : "Xem chi tiết"}
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      {canManage && (
                        <button
                          onClick={() => handleDelete(o.id, o.name)}
                          className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded cursor-pointer transition-colors"
                          title="Xóa cán bộ"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredOfficers.length === 0 && (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-400 italic">
                    Không tìm thấy cán bộ nào phù hợp với bộ lọc tìm kiếm.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-850 rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-8">
            <div className="px-6 py-4 bg-[#00387B] text-white flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-200" />
                {editingOfficerId ? `Cập nhật hồ sơ lý lịch: ${formName}` : 'Thêm mới cán bộ, công chức'}
              </h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-blue-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {!canManage && (
                <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 p-3 rounded-lg flex items-start gap-2 text-xs">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold">Chế độ xem thông tin</p>
                    <p>Tài khoản của bạn không có quyền thay đổi thông tin cán bộ. Vui lòng liên hệ Admin.</p>
                  </div>
                </div>
              )}

              {/* Section 1: Định danh & Cá nhân */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-1.5">
                  <IdCard className="w-4 h-4 text-blue-600" />
                  1. Thông tin Cá nhân & Định danh
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 mb-1">Họ và tên cán bộ *</label>
                    <input
                      type="text"
                      required
                      disabled={!canManage}
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="E.g., Nguyễn Văn A"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Số Căn cước công dân (CCCD)</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formCitizenId}
                      onChange={(e) => setFormCitizenId(e.target.value)}
                      placeholder="E.g., 079085001234"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center justify-between">
                      <span>Ngày sinh (dd/mm/yyyy)</span>
                      {formDob && calculateAge(formDob) !== '—' && (
                        <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-1.5 py-0.5 rounded border border-blue-100 dark:border-blue-900">
                          {calculateAge(formDob)} tuổi ({new Date().getFullYear()})
                        </span>
                      )}
                    </label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formDob}
                      onChange={(e) => setFormDob(e.target.value)}
                      placeholder="E.g., 15/08/1988 hoặc 1988"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Dân tộc</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formEthnicity}
                      onChange={(e) => setFormEthnicity(e.target.value)}
                      placeholder="E.g., Kinh"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Quê quán</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formHometown}
                      onChange={(e) => setFormHometown(e.target.value)}
                      placeholder="E.g., Phường Cầu Kiệu, TP. Hồ Chí Minh"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="md:col-span-3">
                    <label className="block text-xs font-bold text-slate-500 mb-1">Địa chỉ thường trú / Hiện nay</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formAddress}
                      onChange={(e) => setFormAddress(e.target.value)}
                      placeholder="E.g., 68 Huỳnh Văn Bánh, Phường Cầu Kiệu, Quận Phú Nhuận"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Thông tin Công tác & Lương */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-1.5">
                  <DollarSign className="w-4 h-4 text-amber-600" />
                  2. Thông tin Chức vụ & Lương
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1">Chức vụ / Chức danh *</label>
                    <input
                      type="text"
                      required
                      disabled={!canManage}
                      value={formRole}
                      onChange={(e) => setFormRole(e.target.value)}
                      placeholder="E.g., Phó Giám đốc Trung tâm, Chuyên viên..."
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-700 dark:text-amber-400 mb-1">Hệ số lương</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formSalaryCoeff}
                      onChange={(e) => setFormSalaryCoeff(e.target.value)}
                      placeholder="E.g., 4.40"
                      className="w-full text-xs px-3 py-2 border border-amber-300 dark:border-amber-800 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-amber-500 font-mono font-bold text-amber-800 dark:text-amber-300 bg-amber-50/30"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Số điện thoại</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      placeholder="E.g., 0909xxxxxx"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div className="md:col-span-4">
                    <label className="block text-xs font-bold text-slate-500 mb-1">Email công vụ / Cá nhân</label>
                    <input
                      type="email"
                      disabled={!canManage}
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      placeholder="E.g., cb.caukieu@tphcm.gov.vn"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Trình độ chuyên môn & Lý luận */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-1.5">
                  <Award className="w-4 h-4 text-teal-600" />
                  3. Trình độ Đào tạo & Chuyên môn
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Trình độ chuyên môn</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formLevel}
                      onChange={(e) => setFormLevel(e.target.value)}
                      placeholder="E.g., Thạc sỹ, Đại học, Cao đẳng"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Chuyên ngành đào tạo</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formMajor}
                      onChange={(e) => setFormMajor(e.target.value)}
                      placeholder="E.g., Cử nhân Luật, Khoa học Môi trường"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Trình độ Tin học</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formIt}
                      onChange={(e) => setFormIt(e.target.value)}
                      placeholder="E.g., Chứng chỉ Ứng dụng CNTT cơ bản"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">Trình độ Ngoại ngữ</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formLanguage}
                      onChange={(e) => setFormLanguage(e.target.value)}
                      placeholder="E.g., Toeic 575, Trình độ B, IELTS"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1">Lý luận chính trị</label>
                    <input
                      type="text"
                      disabled={!canManage}
                      value={formPolitical}
                      onChange={(e) => setFormPolitical(e.target.value)}
                      placeholder="E.g., Cao cấp, Trung cấp, Sơ cấp"
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 4: Thông tin Đảng viên */}
              <div className="space-y-3 bg-red-50/40 dark:bg-red-950/10 p-3 rounded-xl border border-red-100 dark:border-red-900/30">
                <h4 className="text-xs font-bold text-red-700 dark:text-red-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Flag className="w-4 h-4 text-red-600" />
                  4. Thông tin Đảng viên
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
                  <div>
                    <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-bold text-slate-700 dark:text-slate-300">
                      <input
                        type="checkbox"
                        disabled={!canManage}
                        checked={formIsPartyMember}
                        onChange={(e) => setFormIsPartyMember(e.target.checked)}
                        className="rounded border-slate-300 text-red-600 focus:ring-red-500 w-4 h-4 cursor-pointer"
                      />
                      Là Đảng viên Đảng Cộng sản Việt Nam
                    </label>
                  </div>

                  {formIsPartyMember && (
                    <div>
                      <label className="block text-xs font-bold text-red-700 dark:text-red-400 mb-1">Ngày kết nạp vào Đảng (dd/mm/yyyy)</label>
                      <input
                        type="text"
                        disabled={!canManage}
                        value={formPartyJoinDate}
                        onChange={(e) => setFormPartyJoinDate(e.target.value)}
                        placeholder="E.g., 03/02/2012"
                        className="w-full text-xs px-3 py-2 border border-red-200 dark:border-red-900 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-red-500 font-mono"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Section 5: Ghi chú */}
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">Ghi chú bổ sung</label>
                <textarea
                  rows={2}
                  disabled={!canManage}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Ghi chú quá trình công tác, quy hoạch, khen thưởng..."
                  className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Action buttons */}
              <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 rounded-lg font-bold text-xs cursor-pointer transition-colors"
                >
                  Đóng
                </button>
                {canManage && (
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs cursor-pointer transition-colors flex items-center gap-1 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    Lưu thông tin cán bộ
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
