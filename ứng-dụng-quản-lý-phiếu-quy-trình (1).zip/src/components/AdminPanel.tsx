import React, { useState } from 'react';
import { User, Procedure, Officer, ReasonTemplate, FormType, PROCEDURE_FIELDS } from '../types';
import { 
  Users, Landmark, Award, MessageSquare, Plus, Trash2, Edit, X,
  Search, ShieldAlert, ClipboardList, Briefcase, FileText
} from 'lucide-react';

interface AdminPanelProps {
  users: User[];
  procedures: Procedure[];
  officers: Officer[];
  reasons: ReasonTemplate[];
  onAddUser: (u: Omit<User, 'id'>) => Promise<void>;
  onDeleteUser: (id: string) => Promise<void>;
  onUpdateUser?: (id: string, u: Partial<User>) => Promise<void>;
  onAddProcedure: (p: Omit<Procedure, 'id'>) => Promise<void>;
  onDeleteProcedure: (id: string) => Promise<void>;
  onUpdateProcedure?: (id: string, p: Partial<Procedure>) => Promise<void>;
  onAddOfficer: (o: Omit<Officer, 'id'>) => Promise<void>;
  onDeleteOfficer: (id: string) => Promise<void>;
  onUpdateOfficer?: (id: string, o: Partial<Officer>) => Promise<void>;
  onAddReason: (r: Omit<ReasonTemplate, 'id'>) => Promise<void>;
  onDeleteReason: (id: string) => Promise<void>;
  onUpdateReason?: (id: string, r: Partial<ReasonTemplate>) => Promise<void>;
  currentUser: User;
}

type TabType = 'procedures' | 'officers' | 'reasons' | 'users';

export default function AdminPanel({
  users, procedures, officers, reasons,
  onAddUser, onDeleteUser, onUpdateUser,
  onAddProcedure, onDeleteProcedure, onUpdateProcedure,
  onAddOfficer, onDeleteOfficer, onUpdateOfficer,
  onAddReason, onDeleteReason, onUpdateReason,
  currentUser
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<TabType>('procedures');
  const [searchQuery, setSearchQuery] = useState('');

  // Form states & Editing States
  const [procCode, setProcCode] = useState('');
  const [procName, setProcName] = useState('');
  const [procField, setProcField] = useState('Hộ tịch');
  const [editingProcId, setEditingProcId] = useState<string | null>(null);

  const [offName, setOffName] = useState('');
  const [offPhone, setOffPhone] = useState('');
  const [offRole, setOffRole] = useState('Công chức Tiếp nhận & Trả kết quả');
  const [offSalaryCoeff, setOffSalaryCoeff] = useState('');
  const [offCitizenId, setOffCitizenId] = useState('');
  const [offAddress, setOffAddress] = useState('');
  const [offPartyJoinDate, setOffPartyJoinDate] = useState('');
  const [offIsPartyMember, setOffIsPartyMember] = useState(false);
  const [offEmail, setOffEmail] = useState('');
  const [editingOffId, setEditingOffId] = useState<string | null>(null);

  const [rsnFormType, setRsnFormType] = useState<FormType>('mau03');
  const [rsnTitle, setRsnTitle] = useState('');
  const [rsnContent, setRsnContent] = useState('');
  const [editingRsnId, setEditingRsnId] = useState<string | null>(null);

  const [usrUsername, setUsrUsername] = useState('');
  const [usrFullName, setUsrFullName] = useState('');
  const [usrRole, setUsrRole] = useState<'admin' | 'officer'>('officer');
  const [editingUsrId, setEditingUsrId] = useState<string | null>(null);

  // --- ACTIONS FOR PROCEDURES ---
  const handleAddProc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!procCode || !procName) return;

    if (editingProcId) {
      if (onUpdateProcedure) {
        await onUpdateProcedure(editingProcId, { code: procCode, name: procName, field: procField });
      }
      setEditingProcId(null);
    } else {
      await onAddProcedure({ code: procCode, name: procName, field: procField });
    }
    setProcCode('');
    setProcName('');
    setProcField('Hộ tịch');
  };

  const startEditProc = (p: Procedure) => {
    setEditingProcId(p.id);
    setProcCode(p.code);
    setProcName(p.name);
    setProcField(p.field);
  };

  const cancelEditProc = () => {
    setEditingProcId(null);
    setProcCode('');
    setProcName('');
    setProcField('Hộ tịch');
  };

  // --- ACTIONS FOR OFFICERS ---
  const handleAddOff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!offName) return;

    const payload = {
      name: offName,
      phone: offPhone,
      role: offRole,
      salaryCoeff: offSalaryCoeff,
      citizenId: offCitizenId,
      address: offAddress,
      partyJoinDate: offPartyJoinDate,
      isPartyMember: offIsPartyMember,
      email: offEmail
    };

    if (editingOffId) {
      if (onUpdateOfficer) {
        await onUpdateOfficer(editingOffId, payload);
      }
      setEditingOffId(null);
    } else {
      await onAddOfficer(payload);
    }
    setOffName('');
    setOffPhone('');
    setOffRole('Công chức Tiếp nhận & Trả kết quả');
    setOffSalaryCoeff('');
    setOffCitizenId('');
    setOffAddress('');
    setOffPartyJoinDate('');
    setOffIsPartyMember(false);
    setOffEmail('');
  };

  const startEditOff = (o: Officer) => {
    setEditingOffId(o.id);
    setOffName(o.name);
    setOffPhone(o.phone);
    setOffRole(o.role);
    setOffSalaryCoeff(o.salaryCoeff || '');
    setOffCitizenId(o.citizenId || '');
    setOffAddress(o.address || '');
    setOffPartyJoinDate(o.partyJoinDate || '');
    setOffIsPartyMember(!!o.isPartyMember);
    setOffEmail(o.email || '');
  };

  const cancelEditOff = () => {
    setEditingOffId(null);
    setOffName('');
    setOffPhone('');
    setOffRole('Công chức Tiếp nhận & Trả kết quả');
    setOffSalaryCoeff('');
    setOffCitizenId('');
    setOffAddress('');
    setOffPartyJoinDate('');
    setOffIsPartyMember(false);
    setOffEmail('');
  };

  // --- ACTIONS FOR REASONS ---
  const handleAddRsn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rsnTitle || !rsnContent) return;

    if (editingRsnId) {
      if (onUpdateReason) {
        await onUpdateReason(editingRsnId, { formType: rsnFormType, title: rsnTitle, content: rsnContent });
      }
      setEditingRsnId(null);
    } else {
      await onAddReason({ formType: rsnFormType, title: rsnTitle, content: rsnContent });
    }
    setRsnTitle('');
    setRsnContent('');
    setRsnFormType('mau03');
  };

  const startEditRsn = (r: ReasonTemplate) => {
    setEditingRsnId(r.id);
    setRsnFormType(r.formType);
    setRsnTitle(r.title);
    setRsnContent(r.content);
  };

  const cancelEditRsn = () => {
    setEditingRsnId(null);
    setRsnFormType('mau03');
    setRsnTitle('');
    setRsnContent('');
  };

  // --- ACTIONS FOR USERS ---
  const handleAddUsr = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usrUsername || !usrFullName) return;

    if (editingUsrId) {
      if (onUpdateUser) {
        await onUpdateUser(editingUsrId, { username: usrUsername, fullName: usrFullName, role: usrRole });
      }
      setEditingUsrId(null);
    } else {
      await onAddUser({ username: usrUsername, fullName: usrFullName, role: usrRole });
    }
    setUsrUsername('');
    setUsrFullName('');
    setUsrRole('officer');
  };

  const startEditUsr = (u: User) => {
    setEditingUsrId(u.id);
    setUsrUsername(u.username);
    setUsrFullName(u.fullName);
    setUsrRole(u.role);
  };

  const cancelEditUsr = () => {
    setEditingUsrId(null);
    setUsrUsername('');
    setUsrFullName('');
    setUsrRole('officer');
  };


  // Filter items
  const filteredProcedures = procedures.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.field.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredOfficers = officers.filter(o => 
    o.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (o.phone || '').includes(searchQuery) ||
    o.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredReasons = reasons.filter(r => 
    r.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    r.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = users.filter(u => 
    u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isSystemAdmin = currentUser.role === 'admin';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar Navigation */}
      <div className="bg-white dark:bg-slate-850 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col gap-1 h-fit" id="admin_nav_sidebar">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-3 mb-3">Danh mục Quản trị</h3>
        <button
          id="btn_tab_procedures"
          onClick={() => { setActiveTab('procedures'); setSearchQuery(''); }}
          className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'procedures'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
        >
          <Landmark className="w-4 h-4" />
          Thủ tục hành chính
        </button>
        <button
          id="btn_tab_officers"
          onClick={() => { setActiveTab('officers'); setSearchQuery(''); }}
          className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'officers'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          Đội ngũ cán bộ
        </button>
        <button
          id="btn_tab_reasons"
          onClick={() => { setActiveTab('reasons'); setSearchQuery(''); }}
          className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'reasons'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Lý do soạn sẵn
        </button>
        <button
          id="btn_tab_users"
          onClick={() => { setActiveTab('users'); setSearchQuery(''); }}
          disabled={!isSystemAdmin}
          className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all disabled:opacity-50 cursor-pointer ${
            activeTab === 'users'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Người dùng hệ thống
        </button>
        {!isSystemAdmin && (
          <div className="mt-4 p-3 bg-red-50/50 dark:bg-red-950/20 rounded-lg flex gap-2 border border-red-100 dark:border-red-950/50" id="admin_no_permission_warning">
            <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
            <p className="text-[11px] text-red-700 dark:text-red-300">
              Chức năng Quản lý người dùng yêu cầu quyền Quản trị viên (Admin).
            </p>
          </div>
        )}
      </div>

      {/* Main Panel Content Area */}
      <div className="lg:col-span-3 space-y-6" id="admin_main_workspace">
        {/* Search Header Bar */}
        <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3" id="admin_search_bar">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            id="admin_search_input"
            type="text"
            placeholder={`Tìm kiếm trong mục ${
              activeTab === 'procedures' ? 'Thủ tục hành chính' :
              activeTab === 'officers' ? 'Danh sách cán bộ' :
              activeTab === 'reasons' ? 'Mẫu lý do soạn sẵn' : 'Người dùng hệ thống'
            }...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 text-sm bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-250"
          />
        </div>

        {/* Tab 1: PROCEDURES */}
        {activeTab === 'procedures' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="panel_tab_procedures">
            {/* Create / Edit form */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm h-fit" id="form_procedures">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-1.5 text-sm">
                <Plus className="w-4 h-4 text-blue-600" />
                {editingProcId ? 'Cập nhật thủ tục' : 'Thêm thủ tục mới'}
              </h4>
              <form onSubmit={handleAddProc} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Mã thủ tục (Unique Code)</label>
                  <input
                    id="input_proc_code"
                    type="text"
                    required
                    placeholder="E.g., TP-KHAISINH"
                    value={procCode}
                    onChange={(e) => setProcCode(e.target.value.toUpperCase().replace(/\s+/g, '-'))}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Tên thủ tục hành chính</label>
                  <input
                    id="input_proc_name"
                    type="text"
                    required
                    placeholder="E.g., Đăng ký khai sinh mới"
                    value={procName}
                    onChange={(e) => setProcName(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Lĩnh vực chuyên môn</label>
                  <input
                    id="input_proc_field"
                    type="text"
                    required
                    list="proc_fields_list"
                    placeholder="E.g., Tư pháp - Hộ tịch"
                    value={procField}
                    onChange={(e) => setProcField(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                  <datalist id="proc_fields_list">
                    {PROCEDURE_FIELDS.map(f => (
                      <option key={f} value={f} />
                    ))}
                  </datalist>
                </div>
                <div className="flex gap-2">
                  <button
                    id="btn_submit_proc"
                    type="submit"
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                  >
                    {editingProcId ? 'Lưu cập nhật' : 'Tạo thủ tục'}
                  </button>
                  {editingProcId && (
                    <button
                      id="btn_cancel_proc"
                      type="button"
                      onClick={cancelEditProc}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center"
                      title="Hủy sửa"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List */}
            <div className="md:col-span-2 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" id="list_procedures">
              <div className="px-5 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-700 dark:text-slate-300">Danh mục thủ tục hành chính</span>
                <span className="text-xs font-bold text-slate-400">{filteredProcedures.length} thủ tục</span>
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto max-h-[400px]">
                {filteredProcedures.map((p) => (
                  <div key={p.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-slate-800/20 group">
                    <div className="space-y-1 pr-4">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded">
                          {p.code}
                        </span>
                        <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full">
                          {p.field}
                        </span>
                      </div>
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{p.name}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => startEditProc(p)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-lg transition-all cursor-pointer"
                        title="Chỉnh sửa"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteProcedure(p.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-all cursor-pointer"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {filteredProcedures.length === 0 && (
                  <div className="p-8 text-center text-slate-400 italic text-sm">Không tìm thấy thủ tục nào phù hợp.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: OFFICERS */}
        {activeTab === 'officers' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="panel_tab_officers">
            {/* Create / Edit form */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm h-fit" id="form_officers">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-1.5 text-sm">
                <Plus className="w-4 h-4 text-blue-600" />
                {editingOffId ? 'Cập nhật cán bộ' : 'Thêm cán bộ mới'}
              </h4>
              <form onSubmit={handleAddOff} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Họ tên cán bộ công chức *</label>
                  <input
                    id="input_off_name"
                    type="text"
                    required
                    placeholder="E.g., Nguyễn Văn Hùng"
                    value={offName}
                    onChange={(e) => setOffName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Số Căn cước công dân (CCCD)</label>
                  <input
                    id="input_off_citizen_id"
                    type="text"
                    placeholder="E.g., 079085001234"
                    value={offCitizenId}
                    onChange={(e) => setOffCitizenId(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-amber-700 dark:text-amber-400 mb-1">Hệ số lương</label>
                    <input
                      id="input_off_salary_coeff"
                      type="text"
                      placeholder="E.g., 4.40"
                      value={offSalaryCoeff}
                      onChange={(e) => setOffSalaryCoeff(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-amber-300 dark:border-amber-800 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none font-mono font-bold text-amber-800 dark:text-amber-300 bg-amber-50/20"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Số điện thoại</label>
                    <input
                      id="input_off_phone"
                      type="text"
                      placeholder="E.g., 0901234567"
                      value={offPhone}
                      onChange={(e) => setOffPhone(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Chức vụ / Chức danh *</label>
                  <input
                    id="input_off_role"
                    type="text"
                    required
                    list="officer_roles_list"
                    placeholder="E.g., Phó Giám đốc Trung tâm, Chuyên viên..."
                    value={offRole}
                    onChange={(e) => setOffRole(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                  <datalist id="officer_roles_list">
                    <option value="Phó Giám đốc Trung tâm" />
                    <option value="Chuyên viên" />
                    <option value="Công chức Tiếp nhận & Trả kết quả" />
                    <option value="Công chức Tư pháp - Hộ tịch" />
                    <option value="Công chức Địa chính - Xây dựng" />
                  </datalist>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Địa chỉ thường trú / Nơi ở</label>
                  <input
                    id="input_off_address"
                    type="text"
                    placeholder="E.g., 68 Huỳnh Văn Bánh, Phường Cầu Kiệu"
                    value={offAddress}
                    onChange={(e) => setOffAddress(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="p-2.5 bg-red-50/40 dark:bg-red-950/10 rounded-lg border border-red-100 dark:border-red-900/30 space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={offIsPartyMember}
                      onChange={(e) => setOffIsPartyMember(e.target.checked)}
                      className="rounded border-slate-300 text-red-600 focus:ring-red-500 w-3.5 h-3.5 cursor-pointer"
                    />
                    Là Đảng viên
                  </label>
                  {offIsPartyMember && (
                    <div>
                      <label className="block text-[11px] font-bold text-red-700 dark:text-red-400 mb-1">Ngày vào Đảng</label>
                      <input
                        type="text"
                        placeholder="E.g., 03/02/2012"
                        value={offPartyJoinDate}
                        onChange={(e) => setOffPartyJoinDate(e.target.value)}
                        className="w-full text-xs px-2.5 py-1.5 border border-red-200 dark:border-red-900 dark:bg-slate-800 dark:text-slate-200 rounded focus:outline-none font-mono"
                      />
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    id="btn_submit_off"
                    type="submit"
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                  >
                    {editingOffId ? 'Lưu cập nhật' : 'Thêm cán bộ'}
                  </button>
                  {editingOffId && (
                    <button
                      id="btn_cancel_off"
                      type="button"
                      onClick={cancelEditOff}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center"
                      title="Hủy sửa"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List */}
            <div className="md:col-span-2 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" id="list_officers">
              <div className="px-5 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-700 dark:text-slate-300">Danh sách cán bộ phường</span>
                <span className="text-xs font-bold text-slate-400">{filteredOfficers.length} cán bộ</span>
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto max-h-[400px]">
                {filteredOfficers.map((o) => (
                  <div key={o.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-slate-800/20 group">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-200">{o.name}</p>
                        {o.salaryCoeff && (
                          <span className="bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">
                            HS: {o.salaryCoeff}
                          </span>
                        )}
                        {o.isPartyMember && (
                          <span className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 font-bold px-1.5 py-0.2 rounded text-[10px]">
                            Đảng viên {o.partyJoinDate ? `(${o.partyJoinDate})` : ''}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">{o.role}</p>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-slate-400">
                        <span className="font-mono">SĐT: {o.phone || '—'}</span>
                        {o.citizenId && <span className="font-mono">CCCD: {o.citizenId}</span>}
                        {o.address && <span className="truncate max-w-[200px]" title={o.address}>ĐC: {o.address}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => startEditOff(o)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-lg transition-all cursor-pointer"
                        title="Chỉnh sửa"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteOfficer(o.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-all cursor-pointer"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {filteredOfficers.length === 0 && (
                  <div className="p-8 text-center text-slate-400 italic text-sm">Không tìm thấy cán bộ nào.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: REASONS */}
        {activeTab === 'reasons' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="panel_tab_reasons">
            {/* Create / Edit form */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm h-fit" id="form_reasons">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-1.5 text-sm">
                <Plus className="w-4 h-4 text-blue-600" />
                {editingRsnId ? 'Cập nhật lý do mẫu' : 'Thêm lý do mẫu'}
              </h4>
              <form onSubmit={handleAddRsn} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Loại biểu mẫu áp dụng</label>
                  <select
                    id="select_rsn_type"
                    value={rsnFormType}
                    onChange={(e) => setRsnFormType(e.target.value as FormType)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  >
                    <option value="mau03">Phiếu Từ chối (Mẫu 03)</option>
                    <option value="mau02">Yêu cầu Bổ sung (Mẫu 02)</option>
                    <option value="mau05">Thông báo Dừng (Mẫu 05)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Tên gợi nhớ (Tiêu đề ngắn)</label>
                  <input
                    id="input_rsn_title"
                    type="text"
                    required
                    placeholder="E.g., Thiếu tài liệu đất đai"
                    value={rsnTitle}
                    onChange={(e) => setRsnTitle(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Nội dung chi tiết lý do</label>
                  <textarea
                    id="input_rsn_content"
                    required
                    rows={4}
                    placeholder="E.g., Đối chiếu với hồ sơ địa chính..."
                    value={rsnContent}
                    onChange={(e) => setRsnContent(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 resize-none"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    id="btn_submit_rsn"
                    type="submit"
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                  >
                    {editingRsnId ? 'Lưu cập nhật' : 'Tạo lý do mẫu'}
                  </button>
                  {editingRsnId && (
                    <button
                      id="btn_cancel_rsn"
                      type="button"
                      onClick={cancelEditRsn}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center"
                      title="Hủy sửa"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List */}
            <div className="md:col-span-2 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" id="list_reasons">
              <div className="px-5 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-700 dark:text-slate-300">Danh sách các lý do mẫu</span>
                <span className="text-xs font-bold text-slate-400">{filteredReasons.length} mẫu lý do</span>
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto max-h-[420px]">
                {filteredReasons.map((r) => (
                  <div key={r.id} className="p-4 flex items-start justify-between hover:bg-slate-50/50 dark:hover:bg-slate-800/20 group">
                    <div className="space-y-1.5 pr-4">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          r.formType === 'mau02' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300' :
                          r.formType === 'mau03' ? 'bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-300' :
                          'bg-blue-100 text-blue-800 dark:bg-blue-950/30 dark:text-blue-300'
                        }`}>
                          {r.formType === 'mau02' ? 'Bổ sung' : r.formType === 'mau03' ? 'Từ chối' : 'Dừng'}
                        </span>
                        <span className="font-bold text-sm text-slate-850 dark:text-slate-200">{r.title}</span>
                      </div>
                      <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed text-justify italic">
                        "{r.content}"
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => startEditRsn(r)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-lg transition-all cursor-pointer"
                        title="Chỉnh sửa"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteReason(r.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-all cursor-pointer"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {filteredReasons.length === 0 && (
                  <div className="p-8 text-center text-slate-400 italic text-sm">Không tìm thấy mẫu lý do nào.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: USERS (Requires Admin System Role) */}
        {activeTab === 'users' && isSystemAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="panel_tab_users">
            {/* Create / Edit form */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm h-fit" id="form_users">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-1.5 text-sm">
                <Plus className="w-4 h-4 text-blue-600" />
                {editingUsrId ? 'Cập nhật tài khoản' : 'Thêm tài khoản cán bộ'}
              </h4>
              <form onSubmit={handleAddUsr} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Tên đăng nhập (Username)</label>
                  <input
                    id="input_usr_username"
                    type="text"
                    required
                    placeholder="E.g., minh.nd"
                    value={usrUsername}
                    onChange={(e) => setUsrUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Họ tên cán bộ đầy đủ</label>
                  <input
                    id="input_usr_fullname"
                    type="text"
                    required
                    placeholder="E.g., Nguyễn Đức Minh"
                    value={usrFullName}
                    onChange={(e) => setUsrFullName(e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Quyền hạn hệ thống</label>
                  <select
                    id="select_usr_role"
                    value={usrRole}
                    onChange={(e) => setUsrRole(e.target.value as 'admin' | 'officer')}
                    className="w-full text-sm px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                  >
                    <option value="officer">Cán bộ xử lý (Officer)</option>
                    <option value="admin">Quản trị viên (Admin)</option>
                  </select>
                </div>
                <div className="p-3 bg-amber-55/10 rounded-lg border border-amber-500/20">
                  <p className="text-[10px] text-amber-700 dark:text-amber-400">
                    Mật khẩu mặc định khởi tạo ban đầu cho tất cả tài khoản cán bộ mới là <span className="font-bold">123</span>. Cán bộ có thể đổi lại mật khẩu khi đăng nhập.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    id="btn_submit_usr"
                    type="submit"
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                  >
                    {editingUsrId ? 'Lưu cập nhật' : 'Tạo tài khoản cán bộ'}
                  </button>
                  {editingUsrId && (
                    <button
                      id="btn_cancel_usr"
                      type="button"
                      onClick={cancelEditUsr}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center"
                      title="Hủy sửa"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List */}
            <div className="md:col-span-2 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" id="list_users">
              <div className="px-5 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between">
                <span className="font-semibold text-sm text-slate-700 dark:text-slate-300">Tài khoản cán bộ sử dụng phần mềm</span>
                <span className="text-xs font-bold text-slate-400">{filteredUsers.length} tài khoản</span>
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto max-h-[400px]">
                {filteredUsers.map((u) => (
                  <div key={u.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-slate-800/20 group">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-800 dark:text-slate-200">{u.fullName}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          u.role === 'admin' ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/30 dark:text-indigo-300' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}>
                          {u.role === 'admin' ? 'Quản trị viên' : 'Cán bộ'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-550 dark:text-slate-400 font-mono">Tên đăng nhập: {u.username}</p>
                    </div>
                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => startEditUsr(u)}
                        className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-lg transition-all cursor-pointer"
                        title="Chỉnh sửa"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      {u.username !== currentUser.username ? (
                        <button
                          onClick={() => onDeleteUser(u.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-all cursor-pointer"
                          title="Xóa"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400 italic font-medium px-2 py-1">Đang đăng nhập</span>
                      )}
                    </div>
                  </div>
                ))}
                {filteredUsers.length === 0 && (
                  <div className="p-8 text-center text-slate-400 italic text-sm">Không tìm thấy tài khoản người dùng nào.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
