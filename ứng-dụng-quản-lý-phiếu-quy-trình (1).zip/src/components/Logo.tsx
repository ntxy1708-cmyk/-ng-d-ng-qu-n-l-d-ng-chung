import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export function LogoHorizontal({ className = '', size = 48 }: LogoProps) {
  return (
    <div className={`flex items-center gap-3 ${className}`} style={{ height: size }}>
      <svg
        viewBox="0 0 500 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-auto"
      >
        {/* Five-Hand Star Logo on the Left */}
        <g transform="translate(70, 60) scale(0.55)">
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i} transform={`rotate(${i * 72})`}>
              {/* Red Wrist / Sleeve */}
              <path
                d="M -50,15 C -48,-15 -28,-42 5,-42 C 18,-42 28,-36 34,-28 L 22,-20 C 18,-24 12,-28 5,-28 C -15,-28 -28,-15 -30,15 Z"
                fill="#E30613"
              />
              {/* Yellow Inner Fold */}
              <path
                d="M -15,-28 L 5,-28 C -3,-22 -9,-14 -12,-6 Z"
                fill="#FFF200"
              />
              {/* 5 Parallel Fingers (Authentic CCHC Logo) */}
              <line x1="8" y1="-34" x2="38" y2="-34" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="10" y1="-26" x2="46" y2="-26" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="12" y1="-18" x2="54" y2="-18" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="14" y1="-10" x2="62" y2="-10" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="16" y1="-2" x2="56" y2="-2" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
            </g>
          ))}
        </g>

        {/* Text "TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG" on the right */}
        <text
          x="160"
          y="35"
          fontFamily="'Inter', sans-serif"
          fontWeight="700"
          fontSize="15"
          fill="#00387B"
          letterSpacing="0.08em"
        >
          TRUNG TÂM PHỤC VỤ
        </text>
        <text
          x="160"
          y="72"
          fontFamily="'Inter', sans-serif"
          fontWeight="800"
          fontSize="30"
          fill="#00387B"
          letterSpacing="0.05em"
        >
          HÀNH CHÍNH CÔNG
        </text>

        {/* Subtitle blue banner "PHƯỜNG CẦU KIỆU - TP. HỒ CHÍ MINH" */}
        <rect x="160" y="85" width="325" height="22" rx="4" fill="#00387B" />
        <text
          x="322.5"
          y="99"
          fontFamily="'Inter', sans-serif"
          fontWeight="700"
          fontSize="10"
          fill="#FFFFFF"
          textAnchor="middle"
          letterSpacing="0.12em"
        >
          PHƯỜNG CẦU KIỆU - TP. HỒ CHÍ MINH
        </text>
      </svg>
    </div>
  );
}

export function LogoCircular({ className = '', size = 120 }: LogoProps) {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        <defs>
          <path id="top-path" d="M 28,100 A 72,72 0 0,1 172,100" fill="none" />
          <path id="bottom-path" d="M 172,100 A 72,72 0 0,1 28,100" fill="none" />
        </defs>

        {/* Circular Outer Border */}
        <circle cx="100" cy="100" r="94" stroke="#00387B" strokeWidth="4" />
        <circle cx="100" cy="100" r="88" stroke="#00387B" strokeWidth="1.5" />
        <circle cx="100" cy="100" r="58" stroke="#00387B" strokeWidth="1" strokeDasharray="3,3" opacity="0.4" />

        {/* Text inside circle */}
        <text fill="#00387B" fontSize="9.5" fontWeight="800" fontFamily="'Inter', sans-serif" letterSpacing="0.02em">
          <textPath href="#top-path" startOffset="50%" textAnchor="middle">
            TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG
          </textPath>
        </text>
        <text fill="#00387B" fontSize="8.5" fontWeight="700" fontFamily="'Inter', sans-serif" letterSpacing="0.04em">
          <textPath href="#bottom-path" startOffset="50%" textAnchor="middle">
            PHƯỜNG CẦU KIỆU - TP. HỒ CHÍ MINH
          </textPath>
        </text>

        {/* Center Graphic: 5-Hand Star */}
        <g transform="translate(100, 100) scale(0.65)">
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i} transform={`rotate(${i * 72})`}>
              {/* Red Wrist / Sleeve */}
              <path
                d="M -50,15 C -48,-15 -28,-42 5,-42 C 18,-42 28,-36 34,-28 L 22,-20 C 18,-24 12,-28 5,-28 C -15,-28 -28,-15 -30,15 Z"
                fill="#E30613"
              />
              {/* Yellow Inner Fold */}
              <path
                d="M -15,-28 L 5,-28 C -3,-22 -9,-14 -12,-6 Z"
                fill="#FFF200"
              />
              {/* 5 Parallel Fingers (Authentic CCHC Logo) */}
              <line x1="8" y1="-34" x2="38" y2="-34" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="10" y1="-26" x2="46" y2="-26" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="12" y1="-18" x2="54" y2="-18" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="14" y1="-10" x2="62" y2="-10" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
              <line x1="16" y1="-2" x2="56" y2="-2" stroke="#E30613" strokeWidth="5.5" strokeLinecap="round" />
            </g>
          ))}
        </g>
      </svg>
    </div>
  );
}
