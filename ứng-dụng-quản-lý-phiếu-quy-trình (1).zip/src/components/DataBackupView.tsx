import React, { useState, useEffect } from 'react';
import { 
  Database, 
  ShieldCheck, 
  Download, 
  Upload, 
  RotateCcw, 
  HardDrive, 
  FileText, 
  Users, 
  Clock, 
  History, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Lock, 
  Server,
  Layers,
  Save
} from 'lucide-react';

interface DataBackupViewProps {
  currentUser: { username: string; role: string; fullName?: string } | null;
  onRefreshAllData?: () => void;
}

interface BackupStatus {
  dbExists: boolean;
  fileSizeBytes: number;
  lastModified: string;
  totalRecords: number;
  totalOfficers: number;
  totalDailyReports: number;
  totalAuditLogs: number;
  totalProcedures: number;
  totalTemplates: number;
  snapshotsCount: number;
  lastSnapshot: string | null;
  persistenceStatus: string;
}

interface SnapshotItem {
  filename: string;
  sizeBytes: number;
  createdTime: string;
  isLatest: boolean;
}

export default function DataBackupView({ currentUser, onRefreshAllData }: DataBackupViewProps) {
  const [status, setStatus] = useState<BackupStatus | null>(null);
  const [snapshots, setSnapshots] = useState<SnapshotItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Restore file selection state
  const [selectedFileContent, setSelectedFileContent] = useState<any>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isRestoreModalOpen, setIsRestoreModalOpen] = useState(false);

  // Snapshot trigger state
  const [customLabel, setCustomLabel] = useState('');
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);

  // Browser local mirror state
  const [localMirrorTime, setLocalMirrorTime] = useState<string | null>(null);

  useEffect(() => {
    fetchBackupStatus();
    fetchSnapshots();
    checkLocalMirror();
  }, []);

  const checkLocalMirror = () => {
    try {
      const mirror = localStorage.getItem('caukieu_local_db_mirror_ts');
      if (mirror) setLocalMirrorTime(new Date(mirror).toLocaleString('vi-VN'));
    } catch (e) {
      console.error(e);
    }
  };

  const fetchBackupStatus = async () => {
    try {
      const res = await fetch('/api/backup/status');
      const data = await res.json();
      if (data.success) {
        setStatus(data);
      }
    } catch (err) {
      console.error('Failed to fetch backup status', err);
    }
  };

  const fetchSnapshots = async () => {
    try {
      const res = await fetch('/api/backup/snapshots');
      const data = await res.json();
      if (data.success) {
        setSnapshots(data.snapshots || []);
      }
    } catch (err) {
      console.error('Failed to fetch snapshots', err);
    }
  };

  const handleDownloadBackup = () => {
    window.location.href = '/api/backup/download';
    setMessage({ type: 'success', text: 'Đã phát lệnh tải xuống bản sao lưu toàn bộ dữ liệu hệ thống (.json).' });
  };

  const handleCreateSnapshot = async () => {
    setIsCreatingSnapshot(true);
    setMessage(null);
    try {
      const res = await fetch('/api/backup/trigger-snapshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ label: customLabel || 'manual_user', username: currentUser?.username || 'Admin' })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: data.message });
        setCustomLabel('');
        fetchBackupStatus();
        fetchSnapshots();
      } else {
        setMessage({ type: 'error', text: data.message || 'Tạo snapshot thất bại' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setIsCreatingSnapshot(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!json || typeof json !== 'object') {
          throw new Error('Định dạng tệp JSON không hợp lệ');
        }
        setSelectedFileContent(json);
        setIsRestoreModalOpen(true);
      } catch (err: any) {
        setMessage({ type: 'error', text: 'Lỗi đọc tệp sao lưu: ' + err.message });
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = async () => {
    if (!selectedFileContent) return;
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/backup/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backupData: selectedFileContent,
          username: currentUser?.username || 'Admin'
        })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: `${data.message} (${data.stats?.records} hồ sơ, ${data.stats?.officers} cán bộ)` });
        setIsRestoreModalOpen(false);
        setSelectedFileContent(null);
        fetchBackupStatus();
        fetchSnapshots();
        if (onRefreshAllData) onRefreshAllData();
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Lỗi khi khôi phục dữ liệu: ' + err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleRestoreSnapshot = async (filename: string) => {
    if (!window.confirm(`Bạn có chắc chắn muốn khôi phục dữ liệu về thời điểm snapshot "${filename}"? Hệ thống sẽ tạo bản sao lưu an toàn của dữ liệu hiện tại trước khi khôi phục.`)) {
      return;
    }

    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/backup/restore-snapshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, username: currentUser?.username || 'Admin' })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: data.message });
        fetchBackupStatus();
        fetchSnapshots();
        if (onRefreshAllData) onRefreshAllData();
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Thất bại: ' + err.message });
    } finally {
      setLoading(false);
    }
  };

  // Sync current data to browser localStorage mirror
  const handleSaveLocalMirror = async () => {
    try {
      const res = await fetch('/api/records');
      const records = await res.json();
      const offRes = await fetch('/api/officers');
      const officers = await offRes.json();
      const repRes = await fetch('/api/daily-reports');
      const reports = await repRes.json();

      const mirrorData = {
        timestamp: new Date().toISOString(),
        records,
        officers,
        reports
      };

      localStorage.setItem('caukieu_local_db_mirror', JSON.stringify(mirrorData));
      localStorage.setItem('caukieu_local_db_mirror_ts', mirrorData.timestamp);
      checkLocalMirror();
      setMessage({ type: 'success', text: 'Đã lưu một bản sao dữ liệu dự phòng vào bộ nhớ trình duyệt local của thiết bị thành công.' });
    } catch (err: any) {
      setMessage({ type: 'error', text: 'Lỗi lưu bản sao trình duyệt: ' + err.message });
    }
  };

  const formatKB = (bytes?: number) => {
    if (!bytes) return '0 KB';
    return (bytes / 1024).toFixed(1) + ' KB';
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-blue-900/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-400 via-sky-500 to-transparent pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              BẢO TỒN DỮ LIỆU TUYỆT ĐỐI KHÔNG MẤT MÁT
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <Database className="w-7 h-7 text-blue-400" />
              Bảo tồn & Khôi phục Dữ liệu Gốc Hệ thống
            </h1>
            <p className="text-xs text-blue-200/80 max-w-2xl leading-relaxed">
              Mọi dữ liệu hồ sơ, danh sách cán bộ, nhật ký báo cáo hàng ngày đều được duy trì tự động qua các lần nâng cấp, cập nhật giao diện hoặc tái thiết kế tính năng.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => { fetchBackupStatus(); fetchSnapshots(); }}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 border border-slate-700 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-blue-400" /> Làm mới
            </button>
            <button
              onClick={handleDownloadBackup}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" /> Tải Sao lưu Full (.JSON)
            </button>
          </div>
        </div>
      </div>

      {/* Notification Toast */}
      {message && (
        <div className={`p-4 rounded-xl border flex items-center gap-3 text-xs font-semibold shadow-sm animate-in fade-in duration-200 ${
          message.type === 'success' 
            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
            : 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
          )}
          <span className="flex-1">{message.text}</span>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold px-2 cursor-pointer">✕</button>
        </div>
      )}

      {/* Data Health & Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-100 dark:border-blue-900 flex items-center gap-0 justify-center text-blue-600 shrink-0">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Hồ sơ công chức</p>
            <p className="text-2xl font-black text-slate-800 dark:text-slate-100">{status?.totalRecords ?? '—'}</p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">Bảo vệ nguyên vẹn</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 dark:bg-purple-950/50 border border-purple-100 dark:border-purple-900 flex items-center justify-center text-purple-600 shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Danh sách Cán bộ</p>
            <p className="text-2xl font-black text-slate-800 dark:text-slate-100">{status?.totalOfficers ?? '—'}</p>
            <p className="text-[11px] text-purple-600 dark:text-purple-400 font-medium">Tự động duy trì thông tin</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-100 dark:border-amber-900 flex items-center justify-center text-amber-600 shrink-0">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Nhật ký Báo cáo</p>
            <p className="text-2xl font-black text-slate-800 dark:text-slate-100">{status?.totalDailyReports ?? '—'}</p>
            <p className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">Lưu trữ lịch sử đầy đủ</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-100 dark:border-emerald-900 flex items-center justify-center text-emerald-600 shrink-0">
            <HardDrive className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Dung lượng Database</p>
            <p className="text-2xl font-black text-slate-800 dark:text-slate-100">{formatKB(status?.fileSizeBytes)}</p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
              <Server className="w-3 h-3" /> Cập nhật: {status?.lastModified ? new Date(status.lastModified).toLocaleTimeString('vi-VN') : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Feature Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Panel 1: Trigger Manual Snapshot & Restore from JSON file */}
        <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600">
              <Save className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">1. Tạo bản Snapshot thủ công & Khôi phục file</h3>
              <p className="text-xs text-slate-400">Chủ động lưu snapshot trước khi thay đổi hoặc tải lên bản sao lưu từ máy tính</p>
            </div>
          </div>

          {/* Trigger Snapshot */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-3">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-blue-500" /> Tạo điểm lưu Snapshot tức thì
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Ghi chú snapshot (E.g.: truoc_khi_nang_cap_app)"
                value={customLabel}
                onChange={(e) => setCustomLabel(e.target.value)}
                className="flex-1 text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
              />
              <button
                onClick={handleCreateSnapshot}
                disabled={isCreatingSnapshot}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition shadow-sm cursor-pointer whitespace-nowrap disabled:opacity-50"
              >
                {isCreatingSnapshot ? 'Đang tạo...' : 'Lưu Snapshot'}
              </button>
            </div>
          </div>

          {/* Upload Restore File */}
          <div className="p-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/70 dark:border-amber-900/40 space-y-3">
            <p className="text-xs font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-amber-600" /> Khôi phục toàn bộ dữ liệu từ tệp JSON sao lưu
            </p>
            <p className="text-[11px] text-amber-800/80 dark:text-amber-400">
              Chọn tệp dữ liệu dạng <code className="font-mono bg-amber-100 dark:bg-amber-900/60 px-1 rounded text-amber-900 dark:text-amber-200">.json</code> đã tải về trước đó để ghi đè an toàn khôi phục trạng thái.
            </p>
            <label className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition cursor-pointer shadow-sm w-full">
              <Upload className="w-4 h-4" />
              <span>{fileName ? `Đã chọn: ${fileName}` : 'Chọn tệp sao lưu (.json) từ máy tính'}</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>
        </div>

        {/* Panel 2: Browser Local Storage Mirror & Architecture Guarantee */}
        <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">2. Cơ chế Dự phòng Đa tầng & Bảo vệ Trình duyệt</h3>
              <p className="text-xs text-slate-400">Cam kết không mất dữ liệu khi tái thiết kế phần mềm</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-emerald-500" /> Bản sao dự phòng trên Trình duyệt (Local Mirror)
              </p>
              {localMirrorTime && (
                <span className="text-[10px] font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                  Lần lưu cuối: {localMirrorTime}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Dữ liệu được nhân bản song song vào bộ nhớ Local Storage của thiết bị để tạo lớp bảo vệ thứ 2 độc lập với Server.
            </p>
            <button
              onClick={handleSaveLocalMirror}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition shadow-sm cursor-pointer flex items-center gap-2"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Đồng bộ sao lưu vào bộ nhớ Local Trình duyệt
            </button>
          </div>

          {/* Architecture Commitments Checklist */}
          <div className="space-y-2 pt-1">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Cam kết Kỹ thuật Bảo tồn Dữ liệu:</h4>
            <ul className="text-xs space-y-2 text-slate-600 dark:text-slate-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Safe Schema Merge:</strong> Khi cập nhật mã nguồn (E.g. thêm cột, chức năng mới), hệ thống tự hợp nhất schema mà không xóa bất kỳ bản ghi hay danh mục đã tạo.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Auto Pre-upgrade Snapshot:</strong> Tự động chụp lại phiên bản trước mỗi đợt nâng cấp phần mềm.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Duy trì thông tin cán bộ & lịch sử báo cáo:</strong> Không bao giờ bị làm trống khi reset hay nâng cấp máy chủ.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Snapshot History Table */}
      <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden space-y-4 p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <History className="w-4 h-4 text-blue-600" />
              Lịch sử các bản Snapshot Tự động & Thủ công ({snapshots.length} bản)
            </h3>
            <p className="text-xs text-slate-400">Các thời điểm lưu trữ tự động được tạo ra trước khi nâng cấp hoặc sửa đổi phần mềm</p>
          </div>
          <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700">
            Lưu giữ tối đa 30 bản snapshot gần nhất
          </span>
        </div>

        {snapshots.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            Chưa có bản snapshot nào được tạo. Hãy nhấn nút "Lưu Snapshot" để chủ động lưu lại.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <th className="p-3 font-bold">STT</th>
                  <th className="p-3 font-bold">Tên tệp Snapshot</th>
                  <th className="p-3 font-bold">Dung lượng</th>
                  <th className="p-3 font-bold">Thời gian tạo</th>
                  <th className="p-3 font-bold text-right">Thao tác khôi phục</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {snapshots.map((snap, idx) => (
                  <tr key={snap.filename} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="p-3 font-mono font-bold text-slate-400">{idx + 1}</td>
                    <td className="p-3 font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {snap.filename}
                      {snap.isLatest && (
                        <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200">
                          Mới nhất
                        </span>
                      )}
                    </td>
                    <td className="p-3 font-mono text-slate-500">{formatKB(snap.sizeBytes)}</td>
                    <td className="p-3 text-slate-500">{new Date(snap.createdTime).toLocaleString('vi-VN')}</td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => handleRestoreSnapshot(snap.filename)}
                        disabled={loading}
                        className="px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-400 font-bold text-[11px] rounded border border-amber-300 dark:border-amber-800 transition cursor-pointer"
                      >
                        Khôi phục bản này
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirmation Modal for Restore */}
      {isRestoreModalOpen && selectedFileContent && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-amber-600">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">Xác nhận khôi phục Dữ liệu</h3>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Bạn đang chuẩn bị khôi phục dữ liệu từ tệp tệp sao lưu <strong className="font-mono text-blue-600">{fileName}</strong>. Dữ liệu hiện tại sẽ được tự động tạo một bản Snapshot an toàn trước khi thay thế.
            </p>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border text-xs space-y-1.5 font-mono">
              <p className="font-bold text-slate-700 dark:text-slate-200">Thống kê nội dung trong file tệp khôi phục:</p>
              <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] text-slate-600 dark:text-slate-400">
                <div>• Số hồ sơ: <strong>{selectedFileContent.records?.length || 0}</strong></div>
                <div>• Cán bộ: <strong>{selectedFileContent.officers?.length || 0}</strong></div>
                <div>• Báo cáo ngày: <strong>{selectedFileContent.dailyReports?.length || 0}</strong></div>
                <div>• Lịch sử nhật ký: <strong>{selectedFileContent.auditLogs?.length || 0}</strong></div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => { setIsRestoreModalOpen(false); setSelectedFileContent(null); }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmRestore}
                disabled={loading}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-md transition cursor-pointer"
              >
                {loading ? 'Đang khôi phục...' : 'Đồng ý Khôi phục ngay'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
