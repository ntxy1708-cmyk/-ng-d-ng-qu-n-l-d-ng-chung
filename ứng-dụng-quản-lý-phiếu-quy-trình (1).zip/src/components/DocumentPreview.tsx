import React, { useRef, useState, useEffect } from 'react';
import { Record } from '../types';
import { formatDateVN, getDateParts } from '../utils';
import { Download, Eye, FileText } from 'lucide-react';
import ExportPdfButton from './ExportPdfButton';

interface DocumentPreviewProps {
  record: Record;
  onPrint?: () => void;
  onExportWord?: () => void;
  autoPrint?: boolean;
}

export default function DocumentPreview({ record, onPrint, onExportWord, autoPrint }: DocumentPreviewProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const dateParts = getDateParts(record.createdDate);
  const [showPdfGuide, setShowPdfGuide] = useState(false);

  useEffect(() => {
    if (autoPrint) {
      setShowPdfGuide(true);
    }
  }, [autoPrint, record.id]);

  const handleExportPDF = () => {
    setShowPdfGuide(true);
  };

  const handleConfirmPDFExport = () => {
    setShowPdfGuide(false);
    handlePrint();
  };

  const handlePrint = () => {
    if (onPrint) onPrint();
    
    const printContents = printRef.current?.innerHTML;
    if (!printContents) return;

    // Create a hidden iframe for isolated print context
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);
    
    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>In Phiếu - Phường Cầu Kiệu</title>
            <style>
              @page {
                size: A4;
                margin: 2cm;
              }
              body {
                font-family: "Times New Roman", Times, serif;
                color: #000;
                background: #fff;
                margin: 0;
                padding: 0;
                font-size: 14px;
                line-height: 1.55;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
              .document-paper {
                width: 100%;
                background: #fff;
              }
              /* Grid layout as tables for clean printing */
              .grid {
                display: table !important;
                width: 100% !important;
                table-layout: fixed !important;
              }
              .grid-cols-2 > div {
                display: table-cell !important;
                width: 50% !important;
                vertical-align: top !important;
              }
              /* Alignments */
              .text-center {
                text-align: center !important;
              }
              .text-right {
                text-align: right !important;
              }
              .text-justify {
                text-align: justify !important;
              }
              /* Font styles */
              .font-bold {
                font-weight: bold !important;
              }
              .font-semibold {
                font-weight: 600 !important;
              }
              .font-medium {
                font-weight: 500 !important;
              }
              .italic {
                font-style: italic !important;
              }
              .uppercase {
                text-transform: uppercase !important;
              }
              /* Spacing and margins */
              .my-6 {
                margin-top: 1.5rem !important;
                margin-bottom: 1.5rem !important;
              }
              .my-3 {
                margin-top: 1rem !important;
                margin-bottom: 1rem !important;
              }
              .my-4 {
                margin-top: 1.25rem !important;
                margin-bottom: 1.25rem !important;
              }
              .my-1.5 {
                margin-top: 0.375rem !important;
                margin-bottom: 0.375rem !important;
              }
              .mb-1 {
                margin-bottom: 0.25rem !important;
              }
              .mb-6 {
                margin-bottom: 1.5rem !important;
              }
              .pb-4 {
                padding-bottom: 1rem !important;
              }
              .pb-2 {
                padding-bottom: 0.5rem !important;
              }
              .mt-12 {
                margin-top: 3rem !important;
              }
              .mt-1 {
                margin-top: 0.25rem !important;
              }
              .pt-4 {
                padding-top: 1rem !important;
              }
              .space-y-4 > * + * {
                margin-top: 1rem !important;
              }
              .space-y-1.5 > * + * {
                margin-top: 0.375rem !important;
              }
              .pl-4 {
                padding-left: 1rem !important;
              }
              .h-20 {
                height: 5rem !important;
              }
              .w-16 {
                width: 4rem !important;
              }
              .w-24 {
                width: 6rem !important;
              }
              .h-[1px] {
                height: 1px !important;
              }
              .bg-black {
                background-color: #000 !important;
              }
              .mx-auto {
                margin-left: auto !important;
                margin-right: auto !important;
              }
              /* Flex elements with border-b dotted lines */
              .flex {
                display: table !important;
                width: 100% !important;
              }
              .flex > span {
                display: table-cell !important;
                vertical-align: bottom !important;
              }
              .shrink-0 {
                width: auto !important;
                white-space: nowrap !important;
                padding-right: 4px !important;
              }
              .shrink-1 {
                width: 100% !important;
              }
              .border-b {
                border-bottom: 1px solid #000 !important;
              }
              .border-dashed {
                border-bottom-style: dotted !important;
              }
              .border-gray-400 {
                border-bottom-color: #444 !important;
              }
              .px-1 {
                padding-left: 0.25rem !important;
                padding-right: 0.25rem !important;
              }
              .indent-8 {
                text-indent: 2rem !important;
              }
              /* Font sizes */
              .text-[14px] {
                font-size: 14px !important;
              }
              .text-[13px] {
                font-size: 13px !important;
              }
              .text-[12px] {
                font-size: 12px !important;
              }
              .text-[11px] {
                font-size: 11px !important;
              }
              .text-[10px] {
                font-size: 10px !important;
              }
              .text-blue-900 {
                color: #000 !important;
              }
              .text-slate-850 {
                color: #000 !important;
              }
              .text-red-950 {
                color: #000 !important;
              }
              .bg-red-50\/20 {
                background: none !important;
                border: 1px solid #000 !important;
                padding: 0.5rem !important;
                margin: 0.5rem 0 !important;
              }
              .border-l-2 {
                border-left-width: 2px !important;
              }
              .border-red-500 {
                border-color: #000 !important;
              }
              .rounded {
                border-radius: 4px !important;
              }
              .text-gray-400 {
                display: none !important; /* Hide guidance placeholders on print */
              }
              .no-print {
                display: none !important;
              }
            </style>
          </head>
          <body>
            <div class="document-paper">
              ${printContents}
            </div>
            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.print();
                  setTimeout(function() {
                    window.parent.document.body.removeChild(window.frameElement);
                  }, 200);
                }, 300);
              };
            </script>
          </body>
        </html>
      `);
      doc.close();
    }
  };

  const renderDottedText = (label: string, value: string | undefined, totalDotsLength = 80) => {
    const val = value ? value.trim() : '';
    if (!val) {
      const dotCount = Math.max(8, totalDotsLength - label.length);
      return (
        <div className="flex items-end leading-relaxed text-[14px]">
          <span className="font-medium shrink-0 text-gray-800">{label}</span>
          <span className="text-gray-400 shrink-1 truncate">{'.'.repeat(dotCount)}</span>
        </div>
      );
    }

    if (val.includes('\n')) {
      const lines = val.split('\n');
      return (
        <div className="space-y-1 text-[14px] leading-relaxed">
          <div className="flex items-end">
            <span className="font-medium shrink-0 text-gray-800">{label}</span>
            <span className="font-semibold text-blue-900 border-b border-dashed border-gray-400 px-1 shrink-1 max-w-full text-justify">{lines[0]}</span>
          </div>
          {lines.slice(1).map((l, i) => (
            <div key={i} className="pl-4 font-semibold text-blue-900 border-b border-dashed border-gray-400 text-justify">
              {l}
            </div>
          ))}
        </div>
      );
    }

    const dotCount = Math.max(8, totalDotsLength - label.length - val.length);
    const dots = '.'.repeat(dotCount);
    return (
      <div className="flex items-end leading-relaxed text-[14px]">
        <span className="font-medium shrink-0 text-gray-800">{label}</span>
        <span className="font-semibold text-blue-900 border-b border-dashed border-gray-400 px-1 shrink-1 truncate max-w-full">{val}</span>
        <span className="text-gray-400 shrink-1 truncate">{dots}</span>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-100 dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
      {/* Top Header Panel */}
      <div className="no-print flex items-center justify-between px-5 py-3 bg-white dark:bg-slate-850 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          <span className="font-semibold text-slate-700 dark:text-slate-300">Nội dung văn bản in</span>
        </div>
        <div className="flex items-center gap-2">
          <ExportPdfButton record={record} />
          <button
            onClick={onExportWord}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-sm font-medium text-[#00387B] dark:text-blue-300 bg-blue-50 dark:bg-blue-950/30 hover:bg-blue-100 dark:hover:bg-blue-950/60 rounded-lg transition-colors border border-blue-200 dark:border-blue-900 cursor-pointer"
            id="btn-export-word"
          >
            <Download className="w-4 h-4" />
            Xuất Word
          </button>
        </div>
      </div>

      {/* Main Sheet Container */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 flex justify-center items-start">
        <div
          ref={printRef}
          className="document-paper w-full max-w-[210mm] min-h-[297mm] bg-white p-[1.5cm] md:p-[2cm] shadow-md border border-slate-300 text-black flex flex-col justify-between"
          style={{ fontFamily: '"Times New Roman", Times, serif', lineHeight: '1.4' }}
        >
          {/* Main Form Content */}
          <div>
            {/* Header section (Two columns table) */}
            <div className="grid grid-cols-2 gap-4 text-center items-start border-b border-gray-100 pb-4 mb-6">
              <div>
                <p className="text-[12px] md:text-[13px] uppercase tracking-normal font-normal text-slate-800">
                  UBND PHƯỜNG CẦU KIỆU
                </p>
                <p className="text-[12px] md:text-[13px] uppercase font-bold text-slate-900">
                  TRUNG TÂM PHỤC VỤ HÀNH CHÍNH CÔNG
                </p>
                <div className="w-16 h-[1px] bg-black mx-auto my-1.5" />
                <p className="text-[11px] md:text-[12px] font-medium text-slate-700">
                  Số: {record.ticketNo || '……'} /
                  {record.formType === 'mau02' ? 'PBS-TTPVHCC' : record.formType === 'mau03' ? 'PTC-TTPVHCC' : 'TBD-TTPVHCC'}
                </p>
                <p className="text-[10px] md:text-[11px] text-slate-500 font-normal">
                  (BPTNTKQ)
                </p>
              </div>

              <div>
                <p className="text-[11px] text-right font-medium text-slate-500 mb-1">
                  {record.formType === 'mau02' ? 'Mẫu số 02' : record.formType === 'mau03' ? 'Mẫu số 03' : 'Mẫu số 05'}
                </p>
                <p className="text-[11px] md:text-[12px] uppercase font-bold text-slate-900 leading-tight">
                  CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
                </p>
                <p className="text-[12px] font-bold text-slate-900">
                  Độc lập - Tự do - Hạnh phúc
                </p>
                <div className="w-24 h-[1px] bg-black mx-auto my-1.5" />
                <p className="text-[12px] md:text-[13px] italic text-slate-800">
                  Cầu Kiệu, ngày {dateParts.day} tháng {dateParts.month} năm {dateParts.year}
                </p>
              </div>
            </div>

            {/* Document Title */}
            <div className="text-center my-6">
              <h1 className="text-[14pt] md:text-[14pt] font-bold uppercase leading-snug">
                {record.formType === 'mau02' && 'PHIẾU YÊU CẦU BỔ SUNG, HOÀN THIỆN HỒ SƠ'}
                {record.formType === 'mau03' && 'PHIẾU TỪ CHỐI TIẾP NHẬN GIẢI QUYẾT HỒ SƠ'}
                {record.formType === 'mau05' && 'THÔNG BÁO DỪNG GIẢI QUYẾT HỒ SƠ'}
              </h1>
            </div>

            {/* Document Body */}
            <div className="space-y-4 text-justify text-[14px]">
              {record.formType === 'mau02' && (
                <>
                  {renderDottedText('Hồ sơ của Ông (Bà)/Tổ chức: ', record.citizenName)}
                  {renderDottedText('Số định danh cá nhân/tổ chức: ', record.citizenId)}
                  {renderDottedText('Mã hồ sơ (nếu có): ', record.recordId)}
                  {renderDottedText('Địa chỉ: ', record.address)}
                  <div className="grid grid-cols-2 gap-4">
                    {renderDottedText('Số điện thoại: ', record.phone, 40)}
                    {renderDottedText('Email: ', record.email, 40)}
                  </div>
                  {renderDottedText('Nội dung yêu cầu giải quyết: ', record.procedureContent)}
                  
                  <p className="indent-8 leading-relaxed">
                    Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu yêu cầu Ông (Bà)/Tổ chức hoàn thiện hồ sơ gồm những nội dung sau:
                  </p>
                  
                  {(record.papersList && record.papersList.length > 0) || record.rejectionReason ? (
                    <div className="space-y-2 my-3">
                      {record.papersList && record.papersList.length > 0 && (
                        <div className="pl-4 space-y-1">
                          {record.papersList.map((paper, idx) => (
                            <div key={idx} className="flex gap-2 text-[14px] leading-relaxed text-justify">
                              <span className="font-bold shrink-0">{idx + 1}.</span>
                              <div className="text-slate-850 font-medium whitespace-pre-line leading-relaxed text-justify">
                                {paper}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      {record.rejectionReason && (
                        <div className="pl-4 space-y-1 text-justify leading-relaxed whitespace-pre-line">
                          {record.rejectionReason.split('\n').map((line, idx) => (
                            <p key={idx} className="text-blue-900 font-semibold leading-relaxed text-justify">
                              {line}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2 my-3 text-gray-400">
                      <div>……………………………………………………………………………………………………………………………………</div>
                      <div>……………………………………………………………………………………………………………………………………</div>
                      <div>……………………………………………………………………………………………………………………………………</div>
                    </div>
                  )}

                  <p className="indent-8 leading-relaxed">
                    Trong quá trình hoàn thiện hồ sơ nếu có vướng mắc, Ông (Bà)/Tổ chức liên hệ với Ông/Bà <span className="font-semibold">{record.officerName || '……………………'}</span>{record.officerPhone ? <> số điện thoại <span className="font-semibold">{record.officerPhone}</span></> : ' số điện thoại ……………………'} để được hướng dẫn.
                  </p>
                </>
              )}

              {record.formType === 'mau03' && (
                <>
                  <p className="indent-8 leading-relaxed">
                    Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu
                  </p>
                  {renderDottedText('Tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: ', record.citizenName)}
                  {renderDottedText('Số định danh cá nhân/tổ chức: ', record.citizenId)}
                  {renderDottedText('Địa chỉ: ', record.address)}
                  <div className="grid grid-cols-2 gap-4">
                    {renderDottedText('Số điện thoại: ', record.phone, 40)}
                    {renderDottedText('Email: ', record.email, 40)}
                  </div>
                  {renderDottedText('Mã hồ sơ (nếu có): ', record.recordId)}

                  <p className="indent-8 leading-relaxed">
                    Qua xem xét, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo không tiếp nhận giải quyết hồ sơ này với lý do cụ thể như sau:
                  </p>
                  
                  <div className="my-4 p-3 bg-red-50/20 border-l-2 border-red-500 rounded text-[14px] leading-relaxed text-red-950 font-medium text-justify">
                    {record.rejectionReason || '……………………………………………………………………………………………………………………………………'}
                  </div>

                  <p className="indent-8 leading-relaxed">
                    Xin thông báo cho Ông (Bà)/Tổ chức được biết và phối hợp thực hiện.
                  </p>
                </>
              )}

              {record.formType === 'mau05' && (
                <>
                  <p className="indent-8 leading-relaxed">
                    Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả phường Cầu Kiệu đã tiếp nhận hồ sơ của Ông (Bà)/Tổ chức: <span className="font-bold text-blue-900">{record.citizenName || '……………………'}</span>
                  </p>
                  {renderDottedText('Số định danh cá nhân/tổ chức: ', record.citizenId)}
                  {renderDottedText('Mã hồ sơ: ', record.recordId)}
                  {renderDottedText('Nội dung yêu cầu giải quyết: ', record.procedureContent)}

                  <p className="indent-8 leading-relaxed">
                    Qua kiểm tra, đến nay, mã hồ sơ <span className="font-semibold">{record.recordId || '……………………'}</span> chưa có quyết định giải quyết thủ tục hành chính hoặc có văn bản thông báo kết quả giải quyết thủ tục hành chính.
                  </p>

                  <p className="indent-8 leading-relaxed">
                    Theo đề nghị ngày <span className="font-semibold">{record.stopDateRequest ? formatDateVN(record.stopDateRequest) : '……/……/2026'}</span> của Ông (Bà)/Tổ chức về việc dừng thực hiện hồ sơ giải quyết thủ tục hành chính, lý do: <span className="text-blue-900 font-semibold">{record.stopReason || '………………………………'}</span>, Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả thông báo dừng giải quyết hồ sơ nêu trên.
                  </p>

                  <p className="indent-8 leading-relaxed">
                    Đề nghị Ông (Bà)/Tổ chức liên hệ Trung tâm Phục vụ hành chính công/Bộ phận Tiếp nhận và Trả kết quả để nhận lại hồ sơ giấy và phí, lệ phí đã nộp (nếu có).
                  </p>

                  <p className="indent-8 leading-relaxed">
                    Xin thông báo cho Ông (Bà)/Tổ chức được biết.
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Footer Signature Section */}
          <div className="grid grid-cols-2 gap-4 mt-12 pt-4 items-end">
            <div></div> {/* Empty left column for spacing */}
            <div className="text-center text-[14px]">
              <p className="uppercase font-bold tracking-normal text-slate-900">
                {record.formType === 'mau02' && 'NGƯỜI HƯỚNG DẪN'}
                {record.formType === 'mau03' && 'NGƯỜI TIẾP NHẬN HỒ SƠ'}
                {record.formType === 'mau05' && 'THỦ TRƯỞNG CƠ QUAN, ĐƠN VỊ'}
              </p>
              <p className="italic text-[11px] leading-tight text-slate-500 mt-1 max-w-[220px] mx-auto">
                (Ký và ghi rõ họ tên hoặc chữ ký số nếu là biểu mẫu điện tử)
              </p>
              
              <div className="h-20" /> {/* Space for signature */}

              <p className="font-bold text-[14px] text-slate-900">
                {record.formType === 'mau05' ? (record.leaderName || '') : (record.officerName || 'Nguyễn Văn Hùng')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {showPdfGuide && (
        <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-850 rounded-2xl shadow-xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-6 py-4 bg-red-50 dark:bg-red-950/20 border-b border-red-100 dark:border-red-900/40 flex items-center gap-3">
              <div className="p-2 bg-red-100 dark:bg-red-900/40 rounded-lg text-red-600 dark:text-red-400 shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">Xuất file PDF biểu mẫu chuẩn</h3>
                <p className="text-[10px] text-red-600 dark:text-red-400 font-semibold uppercase tracking-wider">Hướng dẫn lưu trữ định dạng A4</p>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4 text-xs text-slate-600 dark:text-slate-350 leading-relaxed">
              <p>Hệ thống sẽ kích hoạt hộp thoại In của trình duyệt. Quý cán bộ thực hiện các bước sau để xuất file PDF chất lượng cao:</p>
              <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-150 dark:border-slate-700 font-medium text-slate-700 dark:text-slate-300">
                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[10px] font-bold shrink-0">1</span>
                  <span>Tại mục <strong>Máy in (Destination)</strong>, chọn <strong>"Lưu dưới dạng PDF" (Save as PDF)</strong>.</span>
                </div>
                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[10px] font-bold shrink-0">2</span>
                  <span>Thiết lập khổ giấy <strong>A4</strong>, Tỷ lệ (Scale) <strong>"Mặc định" (Default)</strong>.</span>
                </div>
                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[10px] font-bold shrink-0">3</span>
                  <span>Tích chọn <strong>"Đồ họa nền" (Background graphics)</strong> để giữ nguyên định dạng viền, màu sắc.</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 italic">Mẹo: Bạn có thể lưu trực tiếp vào ổ đĩa nội bộ hoặc phân phối bản gốc cho công dân qua hòm thư điện tử.</p>
            </div>

            {/* Actions */}
            <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-100 dark:border-slate-700 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setShowPdfGuide(false)}
                className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-200 font-semibold rounded-lg text-xs hover:bg-slate-50 dark:hover:bg-slate-650 transition-colors cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleConfirmPDFExport}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <FileText className="w-3.5 h-3.5" />
                Mở hộp thoại PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
