import React, { useState, useEffect } from 'react';
import { 
  Record, Procedure, Officer, ReasonTemplate, WordTemplate, AuditLog, User, FormType, DailyReport, ReportConfig, PROCEDURE_FIELDS 
} from './types';
import { 
  formatDateVN, getStatusLabel, getFormTypeLabel, logAudit, exportLogbookToExcel, generateWordDocument, getNextTicketNoForField 
} from './utils';
import DocumentPreview from './components/DocumentPreview';
import ExcelImport from './components/ExcelImport';
import TemplateManager from './components/TemplateManager';
import AdminPanel from './components/AdminPanel';
import AuditLogs from './components/AuditLogs';
import OfficerManagementView from './components/OfficerManagementView';
import DailyReportView from './components/DailyReportView';
import DataBackupView from './components/DataBackupView';
import { 
  LayoutDashboard, FileText, FileSpreadsheet, Upload, FileCode, Users, ShieldCheck, 
  Sun, Moon, LogOut, Menu, X, Plus, Trash2, Edit, History, CheckCircle, Search, 
  SlidersHorizontal, ChevronRight, ChevronLeft, Info, Calendar, Phone, Mail, FileUp, ListChecks,
  Download, Clock, Filter, MapPin, Database
} from 'lucide-react';

export default function App() {
  // Theme & Layout state
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [selectedRecordForDetail, setSelectedRecordForDetail] = useState<Record | null>(null);

  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // DB States
  const [records, setRecords] = useState<Record[]>([]);
  const [procedures, setProcedures] = useState<Procedure[]>([]);
  const [officers, setOfficers] = useState<Officer[]>([]);
  const [reasons, setReasons] = useState<ReasonTemplate[]>([]);
  const [templates, setTemplates] = useState<WordTemplate[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [dailyReports, setDailyReports] = useState<DailyReport[]>([]);
  const [reportConfig, setReportConfig] = useState<ReportConfig>({
    morningStart: '10:30',
    morningEnd: '12:30',
    afternoonStart: '16:00',
    afternoonEnd: '18:00'
  });

  // Active record editor state
  const [activeFormType, setActiveFormType] = useState<FormType>('02' as FormType); // Init as 'mau02'
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);
  const [autoPrintActive, setAutoPrintActive] = useState(false);

  // Form Fields State
  const [formTicketNo, setFormTicketNo] = useState('');
  const [formLinhVuc, setFormLinhVuc] = useState('');
  const [formCreatedDate, setFormCreatedDate] = useState(new Date().toISOString().split('T')[0]);
  const [formCitizenName, setFormCitizenName] = useState('');
  const [formCitizenId, setFormCitizenId] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formRecordId, setFormRecordId] = useState('');
  const [formProcedureContent, setFormProcedureContent] = useState('');
  const [formRejectionReason, setFormRejectionReason] = useState('');
  const [formOfficerName, setFormOfficerName] = useState('');
  const [formOfficerPhone, setFormOfficerPhone] = useState('');
  const [formLeaderName, setFormLeaderName] = useState('');
  const [formStopReason, setFormStopReason] = useState('');
  const [formStopDateRequest, setFormStopDateRequest] = useState(new Date().toISOString().split('T')[0]);
  const [formStatus, setFormStatus] = useState<Record['status']>('cho_xu_ly');
  const [formNotes, setFormNotes] = useState('');
  const [formPapersList, setFormPapersList] = useState<string[]>([]);
  const [newPaperInput, setNewPaperInput] = useState('');

  // Sổ theo dõi and records pagination/search state
  const [recordsSearch, setRecordsSearch] = useState('');
  const [recordsStatusFilter, setRecordsStatusFilter] = useState('');
  const [recordsTypeFilter, setRecordsTypeFilter] = useState('');
  const [recordsFieldFilter, setRecordsFieldFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Filter and report state for Sổ theo dõi trực tiếp (Logbook)
  const [logbookCurrentPage, setLogbookCurrentPage] = useState(1);
  const logbookItemsPerPage = 20;
  const [logbookFilterType, setLogbookFilterType] = useState<'all' | 'day' | 'month' | 'quarter' | 'year'>('all');
  const [logbookFilterDay, setLogbookFilterDay] = useState(new Date().toISOString().split('T')[0]);
  const [logbookFilterMonth, setLogbookFilterMonth] = useState(new Date().toISOString().substring(0, 7)); // YYYY-MM
  const [logbookFilterYear, setLogbookFilterYear] = useState(new Date().getFullYear().toString());
  const [logbookFilterQuarter, setLogbookFilterQuarter] = useState(Math.ceil((new Date().getMonth() + 1) / 3).toString()); // "1" | "2" | "3" | "4"
  const [logbookFieldFilter, setLogbookFieldFilter] = useState('');

  // Filter state for Dashboard statistics (thống kê tổng hồ sơ và từng loại phiếu theo ngày, tháng, quý, năm)
  const [dashboardFilterType, setDashboardFilterType] = useState<'all' | 'day' | 'month' | 'quarter' | 'year'>('all');
  const [dashboardFilterDay, setDashboardFilterDay] = useState(new Date().toISOString().split('T')[0]);
  const [dashboardFilterMonth, setDashboardFilterMonth] = useState(new Date().toISOString().substring(0, 7)); // YYYY-MM
  const [dashboardFilterYear, setDashboardFilterYear] = useState(new Date().getFullYear().toString());
  const [dashboardFilterQuarter, setDashboardFilterQuarter] = useState(Math.ceil((new Date().getMonth() + 1) / 3).toString()); // "1" | "2" | "3" | "4"

  // Initial Fetch Data
  const fetchData = async () => {
    try {
      const [recRes, procRes, offRes, rsnRes, tplRes, logRes, usrRes, repRes, cfgRes] = await Promise.all([
        fetch('/api/records').then(res => res.json()),
        fetch('/api/procedures').then(res => res.json()),
        fetch('/api/officers').then(res => res.json()),
        fetch('/api/reasons').then(res => res.json()),
        fetch('/api/templates').then(res => res.json()),
        fetch('/api/audit-logs').then(res => res.json()),
        fetch('/api/users').then(res => res.json()),
        fetch('/api/daily-reports').then(res => res.json()).catch(() => []),
        fetch('/api/report-config').then(res => res.json()).catch(() => ({ morningStart: '10:30', morningEnd: '12:00', afternoonStart: '15:30', afternoonEnd: '18:00' }))
      ]);

      setRecords(recRes);
      setProcedures(procRes);
      setOfficers(offRes);
      setReasons(rsnRes);
      setTemplates(tplRes);
      setAuditLogs(logRes);
      setUsers(usrRes);
      setDailyReports(repRes || []);
      if (cfgRes) setReportConfig(cfgRes);

      // Set default officer selection if officers are loaded
      if (offRes.length > 0 && !formOfficerName) {
        setFormOfficerName(offRes[0].name);
        setFormOfficerPhone(offRes[0].phone);
      }
    } catch (error) {
      console.error('Failed to load initial workspace database:', error);
    }
  };

  useEffect(() => {
    fetchData();
    // Check if user is logged in local storage
    const savedUser = localStorage.getItem('caukieu_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  // Theme effect
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.user);
        localStorage.setItem('caukieu_user', JSON.stringify(data.user));
        // Refresh logs
        const logRes = await fetch('/api/audit-logs').then(r => r.json());
        setAuditLogs(logRes);
        setLoginUsername('');
        setLoginPassword('');
      } else {
        setLoginError(data.message || 'Đăng nhập thất bại.');
      }
    } catch (error) {
      console.error('Login action failed:', error);
      setLoginError('Không thể kết nối tới máy chủ. Vui lòng kiểm tra lại.');
    }
  };

  // Handle Logout
  const handleLogout = async () => {
    if (!currentUser) return;
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: currentUser.username })
      });
      localStorage.removeItem('caukieu_user');
      setCurrentUser(null);
      setCurrentView('dashboard');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Document Editor State Init
  const startNewDocument = (type: FormType) => {
    setActiveFormType(type);
    setEditingRecordId(null);
    setAutoPrintActive(false);
    const defaultField = 'Hộ tịch';
    setFormLinhVuc(defaultField);
    setFormTicketNo(getNextTicketNoForField(defaultField, records));
    setFormCreatedDate(new Date().toISOString().split('T')[0]);
    setFormCitizenName('');
    setFormCitizenId('');
    setFormAddress('');
    setFormPhone('');
    setFormEmail('');
    setFormRecordId('');
    setFormProcedureContent('');
    setFormRejectionReason('');
    setFormLeaderName('');
    setFormStopReason('');
    setFormStopDateRequest(new Date().toISOString().split('T')[0]);
    setFormStatus('cho_xu_ly');
    setFormNotes('');
    setFormPapersList([]);
    
    if (officers.length > 0) {
      setFormOfficerName(officers[0].name);
      setFormOfficerPhone(officers[0].phone);
    }
    setCurrentView('editor');
  };

  // Auto-generate Vietnamese reference numbers based on type (Only numbers, sequential and continuous per form type)
  const generateTemporaryTicketNo = (type: FormType): string => {
    let maxNum = 0;
    records.forEach(r => {
      if (r.formType === type && r.ticketNo) {
        const match = r.ticketNo.match(/^\d+/);
        const num = match ? parseInt(match[0], 10) : parseInt(r.ticketNo, 10);
        if (!isNaN(num) && num > maxNum) {
          maxNum = num;
        }
      }
    });
    const nextNum = maxNum + 1;
    return nextNum < 10 ? `0${nextNum}` : String(nextNum);
  };

  // Auto-generate reference numbers based on selected field/lĩnh vực
  const generateTicketNoForLinhVuc = (_type: FormType, field: string): string => {
    return getNextTicketNoForField(field, records);
  };

  // Quick Loader for existing records to edit
  const loadRecordForEditing = (record: Record, triggerPrint: boolean = false) => {
    setEditingRecordId(record.id);
    setActiveFormType(record.formType);
    setAutoPrintActive(triggerPrint);
    setFormTicketNo(record.ticketNo);
    setFormLinhVuc(record.field || '');
    setFormCreatedDate(record.createdDate);
    setFormCitizenName(record.citizenName);
    setFormCitizenId(record.citizenId);
    setFormAddress(record.address);
    setFormPhone(record.phone);
    setFormEmail(record.email || '');
    setFormRecordId(record.recordId || '');
    setFormProcedureContent(record.procedureContent);
    setFormRejectionReason(record.rejectionReason || '');
    setFormOfficerName(record.officerName);
    setFormOfficerPhone(record.officerPhone || '');
    setFormLeaderName(record.leaderName || '');
    setFormStopReason(record.stopReason || '');
    setFormStopDateRequest(record.stopDateRequest || '');
    setFormStatus(record.status);
    setFormNotes(record.notes || '');
    setFormPapersList(record.papersList || []);
    setCurrentView('editor');
  };

  // Add paper to list
  const handleAddPaper = () => {
    if (!newPaperInput.trim()) return;
    setFormPapersList([...formPapersList, newPaperInput.trim()]);
    setNewPaperInput('');
  };

  const handleRemovePaper = (index: number) => {
    setFormPapersList(formPapersList.filter((_, idx) => idx !== index));
  };

  // Trigger quick inserts of predefined reasons from admin lists
  const handleSelectPredefinedReason = (reasonText: string) => {
    if (activeFormType === 'mau02' || activeFormType === 'mau03') {
      setFormRejectionReason(reasonText);
    } else if (activeFormType === 'mau05') {
      setFormStopReason(reasonText);
    }
  };

  // Save current record to Server Database
  const handleSaveRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCitizenName || !formTicketNo) {
      alert('Vui lòng điền đầy đủ các thông tin bắt buộc: Họ tên công dân và Số hiệu phiếu.');
      return;
    }

    let finalTicketNo = formTicketNo.trim();
    if (/^\d$/.test(finalTicketNo)) {
      finalTicketNo = '0' + finalTicketNo;
      setFormTicketNo(finalTicketNo);
    }

    const payload: Partial<Record> = {
      formType: activeFormType,
      ticketNo: finalTicketNo,
      field: formLinhVuc,
      createdDate: formCreatedDate,
      citizenName: formCitizenName,
      citizenId: formCitizenId,
      address: formAddress,
      phone: formPhone,
      email: formEmail,
      recordId: formRecordId,
      procedureContent: formProcedureContent,
      officerName: formOfficerName,
      status: formStatus,
      notes: formNotes,
      
      // Mẫu 02 specific
      papersList: activeFormType === 'mau02' ? formPapersList : [],
      officerPhone: activeFormType === 'mau02' ? formOfficerPhone : '',
      
      // Mẫu 03 specific
      rejectionReason: activeFormType === 'mau03' || activeFormType === 'mau02' ? formRejectionReason : '',

      // Mẫu 05 specific
      leaderName: activeFormType === 'mau05' ? formLeaderName : '',
      stopReason: activeFormType === 'mau05' ? formStopReason : '',
      stopDateRequest: activeFormType === 'mau05' ? formStopDateRequest : ''
    };

    try {
      let response;
      if (editingRecordId) {
        // Edit record
        response = await fetch(`/api/records/${editingRecordId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, modifier: currentUser?.username || 'Cán bộ' })
        });
      } else {
        // Create record
        response = await fetch('/api/records', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, creator: currentUser?.username || 'Cán bộ' })
        });
      }

      const resData = await response.json();
      if (resData.success) {
        alert(editingRecordId ? 'Cập nhật hồ sơ thành công!' : 'Tạo mới hồ sơ hành chính thành công!');
        setEditingRecordId(null);
        fetchData(); // Refresh UI lists
        setCurrentView('records');
      } else {
        alert('Lỗi khi lưu dữ liệu: ' + resData.message);
      }
    } catch (error) {
      console.error('Save record failed:', error);
      alert('Không thể kết nối máy chủ để lưu hồ sơ.');
    }
  };

  // Delete Record
  const handleDeleteRecord = async (id: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa hồ sơ này khỏi hệ thống? Hành động này sẽ được ghi lịch sử.')) return;
    try {
      const res = await fetch(`/api/records/${id}?username=${currentUser?.username || 'Cán bộ'}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.success) {
        setRecords(records.filter(r => r.id !== id));
        // Register logs
        const logsRes = await fetch('/api/audit-logs').then(r => r.json());
        setAuditLogs(logsRes);
      }
    } catch (error) {
      console.error('Delete record failed:', error);
    }
  };

  // API Call: Create Procedure
  const handleAddProcedure = async (proc: Omit<Procedure, 'id'>) => {
    try {
      const res = await fetch('/api/procedures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...proc, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  // API Call: Delete Procedure
  const handleDeleteProcedure = async (id: string) => {
    if (!confirm('Bạn có muốn xóa thủ tục này?')) return;
    try {
      const res = await fetch(`/api/procedures/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  // API Call: Create Officer
  const handleAddOfficer = async (off: Omit<Officer, 'id'>) => {
    try {
      const res = await fetch('/api/officers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...off, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteOfficer = async (id: string) => {
    if (!confirm('Bạn có muốn xóa cán bộ này?')) return;
    try {
      const res = await fetch(`/api/officers/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  // API Call: Create Reason template
  const handleAddReason = async (rsn: Omit<ReasonTemplate, 'id'>) => {
    try {
      const res = await fetch('/api/reasons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...rsn, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteReason = async (id: string) => {
    if (!confirm('Bạn có muốn xóa lý do này?')) return;
    try {
      const res = await fetch(`/api/reasons/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  // API Call: Create user account
  const handleAddUser = async (u: Omit<User, 'id'>) => {
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...u, creator: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm('Bạn có muốn xóa tài khoản này?')) return;
    try {
      const res = await fetch(`/api/users/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateProcedure = async (id: string, proc: Partial<Procedure>) => {
    try {
      const res = await fetch(`/api/procedures/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...proc, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateOfficer = async (id: string, off: Partial<Officer>) => {
    try {
      const res = await fetch(`/api/officers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...off, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateReason = async (id: string, rsn: Partial<ReasonTemplate>) => {
    try {
      const res = await fetch(`/api/reasons/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...rsn, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateUser = async (id: string, u: Partial<User>) => {
    try {
      const res = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...u, updater: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleSaveDailyReport = async (report: Omit<DailyReport, 'id' | 'reportedAt'>) => {
    try {
      const res = await fetch('/api/daily-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...report, username: currentUser?.username })
      });
      if (res.ok) {
        fetchData();
      } else {
        const errorText = await res.text();
        throw new Error(errorText);
      }
    } catch (error) {
      console.error('Failed to save daily report:', error);
      throw error;
    }
  };

  const handleSaveReportConfig = async (config: ReportConfig) => {
    try {
      const res = await fetch('/api/report-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...config, username: currentUser?.username })
      });
      if (res.ok) {
        fetchData();
      } else {
        const errorText = await res.text();
        throw new Error(errorText);
      }
    } catch (error) {
      console.error('Failed to save report configuration:', error);
      throw error;
    }
  };

  const handleDeleteDailyReport = async (id: string) => {
    try {
      const res = await fetch(`/api/daily-reports/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchData();
      } else {
        const errorText = await res.text();
        throw new Error(errorText);
      }
    } catch (error) {
      console.error('Failed to delete daily report:', error);
      throw error;
    }
  };

  // Template Manager triggers
  const handleUploadTemplate = async (name: string, formType: FormType, base64: string, placeholders: string[]) => {
    try {
      const res = await fetch('/api/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, formType, contentBase64: base64, placeholders, username: currentUser?.username })
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteTemplate = async (id: string) => {
    try {
      const res = await fetch(`/api/templates/${id}?username=${currentUser?.username}`, {
        method: 'DELETE'
      });
      if (res.ok) fetchData();
    } catch (error) {
      console.error(error);
    }
  };

  // Export Record to Word
  const handleExportWordRecord = async (record: Record) => {
    // Log Audit
    await logAudit(currentUser?.username || 'Cán bộ', 'Export', `Xuất tệp Word biểu mẫu ${record.formType} cho công dân ${record.citizenName}`);
    
    // Check if we have an active custom template in server
    const serverTemplate = templates.find(t => t.formType === record.formType && t.isDefault);
    generateWordDocument(record, serverTemplate?.contentBase64);
    
    // Refresh audit logs
    const logRes = await fetch('/api/audit-logs').then(r => r.json());
    setAuditLogs(logRes);
  };

  // Log Browser Print action
  const handlePrintRecord = async (record: Record) => {
    await logAudit(currentUser?.username || 'Cán bộ', 'In', `In trực tiếp biểu mẫu ${record.formType} cho công dân ${record.citizenName}`);
    // Refresh audits
    const logRes = await fetch('/api/audit-logs').then(r => r.json());
    setAuditLogs(logRes);
  };

  // Helper to match field filters strictly or with alias support
  const isFieldMatch = (recField: string, filterVal: string) => {
    if (!filterVal) return true;
    const rF = (recField || 'Hộ tịch').trim().toLowerCase();
    const fV = filterVal.trim().toLowerCase();
    
    if (rF === fV) return true;
    
    if (fV.includes('văn hóa') || fV.includes('van hoa')) {
      return rF.includes('văn hóa') || rF.includes('van hoa') || rF.includes('lao động') || rF.includes('lao dong') || rF.includes('tb&xh');
    }
    if (fV.includes('kinh tế') || fV.includes('kinh te')) {
      return rF.includes('kinh tế') || rF.includes('kinh te');
    }
    if (fV.includes('chứng thực') || fV.includes('tư pháp')) {
      return rF.includes('chứng thực') || rF.includes('tư pháp');
    }
    if (fV.includes('đô thị') || fV.includes('xây dựng') || fV.includes('hạ tầng')) {
      return rF.includes('đô thị') || rF.includes('xây dựng') || rF.includes('hạ tầng');
    }
    if (fV.includes('đất đai') || fV.includes('môi trường') || fV.includes('tài nguyên')) {
      return rF.includes('đất đai') || rF.includes('môi trường') || rF.includes('tài nguyên');
    }

    return rF.includes(fV) || fV.includes(rF);
  };

  // Filtering records for lists
  const filteredRecords = records.filter(r => {
    const searchLower = recordsSearch.toLowerCase();
    const matchesSearch = 
      r.citizenName.toLowerCase().includes(searchLower) ||
      r.citizenId.includes(searchLower) ||
      r.ticketNo.toLowerCase().includes(searchLower) ||
      (r.recordId && r.recordId.toLowerCase().includes(searchLower));

    const matchesStatus = recordsStatusFilter ? r.status === recordsStatusFilter : true;
    const matchesType = recordsTypeFilter ? r.formType === recordsTypeFilter : true;
    const recField = r.field || 'Hộ tịch';
    const matchesField = isFieldMatch(recField, recordsFieldFilter);

    return matchesSearch && matchesStatus && matchesType && matchesField;
  });

  // Filtering records for Sổ theo dõi trực tiếp (Logbook) by day, month, quarter, year & field
  const filteredLogbookRecords = records.filter(r => {
    if (logbookFieldFilter) {
      const recField = r.field || 'Hộ tịch';
      if (!isFieldMatch(recField, logbookFieldFilter)) return false;
    }

    if (!r.createdDate) return false;
    const [yearStr, monthStr] = r.createdDate.split('-');
    
    if (logbookFilterType === 'day') {
      return r.createdDate === logbookFilterDay;
    }
    
    if (logbookFilterType === 'month') {
      const [fYear, fMonth] = logbookFilterMonth.split('-');
      return yearStr === fYear && monthStr === fMonth;
    }
    
    if (logbookFilterType === 'quarter') {
      if (yearStr !== logbookFilterYear) return false;
      const m = parseInt(monthStr, 10);
      if (isNaN(m)) return false;
      const q = Math.ceil(m / 3);
      return q.toString() === logbookFilterQuarter;
    }
    
    if (logbookFilterType === 'year') {
      return yearStr === logbookFilterYear;
    }
    
    return true; // 'all'
  });

  // Logbook 20 items/page pagination calculations
  const logbookTotalPages = Math.max(1, Math.ceil(filteredLogbookRecords.length / logbookItemsPerPage));
  const validLogbookPage = Math.min(logbookCurrentPage, logbookTotalPages);
  const paginatedLogbookRecords = filteredLogbookRecords.slice(
    (validLogbookPage - 1) * logbookItemsPerPage,
    validLogbookPage * logbookItemsPerPage
  );

  // Generate descriptive filename for Excel Report
  const getLogbookReportFilename = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    if (logbookFilterType === 'day') {
      return `Bao_Cao_So_Theo_Doi_Ngay_${logbookFilterDay}`;
    }
    if (logbookFilterType === 'month') {
      return `Bao_Cao_So_Theo_Doi_Thang_${logbookFilterMonth}`;
    }
    if (logbookFilterType === 'quarter') {
      return `Bao_Cao_So_Theo_Doi_Quy_${logbookFilterQuarter}_Nam_${logbookFilterYear}`;
    }
    if (logbookFilterType === 'year') {
      return `Bao_Cao_So_Theo_Doi_Nam_${logbookFilterYear}`;
    }
    return `So_Theo_Doi_Tong_Hop_Den_Ngay_${todayStr}`;
  };

  // Pagination helper
  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage);
  const paginatedRecords = filteredRecords.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Filter records for Dashboard statistics
  const getFilteredDashboardRecords = () => {
    return records.filter(r => {
      if (!r.createdDate) return false;
      const dateStr = r.createdDate; // "YYYY-MM-DD"
      
      if (dashboardFilterType === 'day') {
        return dateStr === dashboardFilterDay;
      }
      
      if (dashboardFilterType === 'month') {
        return dateStr.startsWith(dashboardFilterMonth); // "YYYY-MM"
      }
      
      if (dashboardFilterType === 'quarter') {
        const year = dateStr.substring(0, 4);
        const month = parseInt(dateStr.substring(5, 7), 10);
        const quarter = Math.ceil(month / 3).toString();
        return year === dashboardFilterYear && quarter === dashboardFilterQuarter;
      }
      
      if (dashboardFilterType === 'year') {
        return dateStr.startsWith(dashboardFilterYear); // "YYYY"
      }
      
      return true; // 'all'
    });
  };

  // Stats calculation
  const getDossierStats = () => {
    const filtered = getFilteredDashboardRecords();
    const total = filtered.length;
    const pending = filtered.filter(r => r.status === 'cho_xu_ly').length;
    const supplemented = filtered.filter(r => r.status === 'da_hoan_thien').length;
    const boSung = filtered.filter(r => r.status === 'bo_sung').length;
    const refused = filtered.filter(r => r.status === 'tu_choi').length;
    const stopped = filtered.filter(r => r.status === 'da_dung').length;

    // Detailed counts by document form type
    const countMau02 = filtered.filter(r => r.formType === 'mau02').length;
    const countMau03 = filtered.filter(r => r.formType === 'mau03').length;
    const countMau05 = filtered.filter(r => r.formType === 'mau05').length;

    // Statistics by Field/Lĩnh vực
    const statsByField: { [key: string]: { total: number; mau02: number; mau03: number; mau05: number; maxTicket: number } } = {};

    PROCEDURE_FIELDS.forEach(f => {
      statsByField[f] = { total: 0, mau02: 0, mau03: 0, mau05: 0, maxTicket: 0 };
    });

    filtered.forEach(r => {
      let fieldName = r.field || 'Khác';
      const matched = PROCEDURE_FIELDS.find(pf => pf.toLowerCase() === fieldName.trim().toLowerCase());
      if (matched) fieldName = matched;

      if (!statsByField[fieldName]) {
        statsByField[fieldName] = { total: 0, mau02: 0, mau03: 0, mau05: 0, maxTicket: 0 };
      }

      statsByField[fieldName].total += 1;
      if (r.formType === 'mau02') statsByField[fieldName].mau02 += 1;
      if (r.formType === 'mau03') statsByField[fieldName].mau03 += 1;
      if (r.formType === 'mau05') statsByField[fieldName].mau05 += 1;

      if (r.ticketNo) {
        const match = String(r.ticketNo).match(/\d+/);
        const num = match ? parseInt(match[0], 10) : parseInt(String(r.ticketNo), 10);
        if (!isNaN(num) && num > statsByField[fieldName].maxTicket) {
          statsByField[fieldName].maxTicket = num;
        }
      }
    });

    return { total, pending, supplemented, boSung, refused, stopped, countMau02, countMau03, countMau05, statsByField };
  };

  const stats = getDossierStats();

  // If user is not logged in, show the Login View
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#0B192C] flex flex-col justify-center items-center p-4">
        {/* Login Card */}
        <div className="bg-white dark:bg-slate-850 p-8 rounded-2xl shadow-xl w-full max-w-md border border-slate-200 dark:border-slate-800 flex flex-col items-center space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-base font-extrabold text-[#00387B] dark:text-blue-400 uppercase tracking-wide">
              ỨNG DỤNG QUẢN LÝ DÙNG CHUNG
            </h2>
            <p className="text-[10px] md:text-xs font-bold text-slate-500 uppercase tracking-wider leading-relaxed px-2">
              <span className="block">Trung tâm Phục vụ hành chính công</span>
              <span className="block mt-0.5 text-slate-400 dark:text-slate-500 font-semibold text-[9px] md:text-[11px]">Phường Cầu Kiệu - TP.Hồ Chí Minh</span>
            </p>
          </div>

          {loginError && (
            <div className="w-full p-3 bg-red-50 text-red-700 text-xs font-medium rounded-lg border border-red-200 flex items-center gap-2">
              <Info className="w-4 h-4 text-red-500" />
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="w-full space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tên đăng nhập</label>
              <input
                type="text"
                required
                placeholder="E.g., admin@caukieu"
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full px-4 py-2.5 text-sm border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mật khẩu</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full px-4 py-2.5 text-sm border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-[#00387B] hover:bg-blue-700 text-white font-semibold rounded-lg text-sm transition-colors cursor-pointer"
            >
              Đăng nhập hệ thống
            </button>
          </form>

          {/* Quick accounts help info */}
          <div className="w-full border-t border-slate-100 dark:border-slate-800 pt-4 text-center space-y-2">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Tài khoản kiểm thử nhanh</p>
            <div className="flex flex-wrap justify-center gap-2">
              <button 
                onClick={() => { setLoginUsername('admin@caukieu'); setLoginPassword('123456789'); }}
                className="text-[10px] font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 px-2 py-1 rounded hover:bg-blue-100 transition-colors"
              >
                Quản trị (admin@caukieu / 123456789)
              </button>
              <button 
                onClick={() => { setLoginUsername('hung.nv'); setLoginPassword('123'); }}
                className="text-[10px] font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 px-2 py-1 rounded hover:bg-blue-100 transition-colors"
              >
                Cán bộ (hung.nv / 123)
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Active Document Preview representation for editing
  const dummyActiveRecord: Record = {
    id: editingRecordId || 'temp',
    formType: activeFormType,
    ticketNo: formTicketNo,
    createdDate: formCreatedDate,
    citizenName: formCitizenName,
    citizenId: formCitizenId,
    address: formAddress,
    phone: formPhone,
    email: formEmail,
    recordId: formRecordId,
    procedureContent: formProcedureContent,
    papersList: formPapersList,
    officerPhone: formOfficerPhone,
    rejectionReason: formRejectionReason,
    leaderName: formLeaderName,
    stopReason: formStopReason,
    stopDateRequest: formStopDateRequest,
    officerName: formOfficerName,
    status: formStatus,
    history: []
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex text-slate-800 dark:text-slate-200">
      
      {/* 1. LEFT SIDEBAR MENU PANEL */}
      <aside className={`no-print fixed inset-y-0 left-0 z-40 w-80 bg-[#00387B] dark:bg-slate-900 border-r border-[#004a9e] dark:border-slate-800 flex flex-col justify-between transform transition-transform md:translate-x-0 ${
        mobileMenuOpen ? 'translate-x-0' : '-translate-x-0 hidden md:flex'
      }`}>
        <div className="flex flex-col flex-1 overflow-y-auto">
          {/* Logo brand */}
          <div className="p-6 flex flex-col items-center border-b border-[#004a9e] dark:border-slate-800">
            <span className="text-[13px] text-center font-extrabold leading-tight uppercase text-white opacity-100 block tracking-wider whitespace-nowrap">
              Ứng dụng quản lý dùng chung
            </span>
            <span className="text-xs text-center font-bold leading-tight uppercase text-blue-100 opacity-95 block mt-2 whitespace-nowrap">
              Trung tâm Phục vụ hành chính công
            </span>
            <span className="text-[11px] text-center font-semibold leading-tight uppercase text-blue-200/90 block mt-1 whitespace-nowrap">
              Phường Cầu Kiệu - TP.Hồ Chí Minh
            </span>
          </div>

          {/* User profile */}
          <div className="px-5 py-4 bg-[#004a9e]/30 dark:bg-slate-800/50 border-b border-[#004a9e]/60 dark:border-slate-800 flex items-center justify-between">
            <div className="truncate pr-2">
              <p className="text-sm font-bold text-white truncate whitespace-nowrap">{currentUser.fullName}</p>
              <p className="text-[11px] font-semibold text-blue-200 dark:text-slate-400 uppercase tracking-wider whitespace-nowrap">
                {currentUser.role === 'admin' ? 'Quản trị viên' : 'Cán bộ Một cửa'}
              </p>
            </div>
            <button 
              onClick={handleLogout}
              className="p-1.5 text-blue-200 hover:text-red-400 hover:bg-[#004a9e]/60 dark:hover:bg-red-950/20 rounded-lg transition-colors cursor-pointer shrink-0"
              title="Đăng xuất"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-3.5 space-y-2">
            <button
              onClick={() => { setCurrentView('dashboard'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'dashboard'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <LayoutDashboard className="w-5 h-5 shrink-0" />
              Bảng điều khiển
            </button>

            <p className="text-[11px] font-bold text-blue-200/60 dark:text-slate-500 uppercase px-4 pt-4 pb-1 tracking-wider whitespace-nowrap text-left">Hành chính Công</p>

            <button
              onClick={() => { setCurrentView('daily_report'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'daily_report'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <Clock className="w-5 h-5 shrink-0" />
              Báo cáo hàng ngày
            </button>

            <button
              onClick={() => { setCurrentView('officers_mgmt'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'officers_mgmt'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <Users className="w-5 h-5 shrink-0" />
              Danh sách Cán bộ CC
            </button>

            {/* Quick draft nested menus */}
            <div className="space-y-1.5">
              <p className="text-[11px] font-bold text-blue-200/60 dark:text-slate-500 uppercase px-4 pt-4 pb-1 tracking-wider whitespace-nowrap text-left">Soạn phiếu biểu mẫu</p>
              <button
                onClick={() => { startNewDocument('mau02'); setMobileMenuOpen(false); }}
                className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                  currentView === 'editor' && activeFormType === 'mau02'
                    ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                    : 'text-blue-100/85 hover:text-white hover:bg-[#004a9e]/40'
                }`}
              >
                <Plus className="w-4 h-4 shrink-0" />
                Phiếu Bổ sung (Mẫu 02)
              </button>
              <button
                onClick={() => { startNewDocument('mau03'); setMobileMenuOpen(false); }}
                className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                  currentView === 'editor' && activeFormType === 'mau03'
                    ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                    : 'text-blue-100/85 hover:text-white hover:bg-[#004a9e]/40'
                }`}
              >
                <Plus className="w-4 h-4 shrink-0" />
                Phiếu Từ chối (Mẫu 03)
              </button>
              <button
                onClick={() => { startNewDocument('mau05'); setMobileMenuOpen(false); }}
                className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                  currentView === 'editor' && activeFormType === 'mau05'
                    ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                    : 'text-blue-100/85 hover:text-white hover:bg-[#004a9e]/40'
                }`}
              >
                <Plus className="w-4 h-4 shrink-0" />
                Thông báo Dừng (Mẫu 05)
              </button>
            </div>

            <p className="text-[11px] font-bold text-blue-200/60 dark:text-slate-500 uppercase px-4 pt-4 pb-1 tracking-wider whitespace-nowrap text-left">Kho lưu trữ</p>
            
            <button
              onClick={() => { setCurrentView('records'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'records'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <FileText className="w-5 h-5 shrink-0" />
              Sổ Quản lý hồ sơ
            </button>

            <button
              onClick={() => { setCurrentView('logbook'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'logbook'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <FileSpreadsheet className="w-5 h-5 shrink-0" />
              Sổ theo dõi trực tiếp
            </button>

            <p className="text-[11px] font-bold text-blue-200/60 dark:text-slate-500 uppercase px-4 pt-4 pb-1 tracking-wider whitespace-nowrap text-left">Cấu hình hệ thống</p>

            <button
              onClick={() => { setCurrentView('import'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'import'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <Upload className="w-5 h-5 shrink-0" />
              Import dữ liệu Excel
            </button>

            <button
              onClick={() => { setCurrentView('templates'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'templates'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <FileCode className="w-5 h-5 shrink-0" />
              Quản lý Template Word
            </button>

            <button
              onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'admin'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <Users className="w-5 h-5 shrink-0" />
              Quản trị Danh mục
            </button>

            <button
              onClick={() => { setCurrentView('audits'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'audits'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <ShieldCheck className="w-5 h-5 shrink-0" />
              Nhật ký Audit Log
            </button>

            <button
              onClick={() => { setCurrentView('backup_mgmt'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-[15px] font-bold transition-all cursor-pointer whitespace-nowrap justify-start text-left ${
                currentView === 'backup_mgmt'
                  ? 'bg-[#004a9e] text-white shadow-md border-l-4 border-amber-400'
                  : 'text-blue-100/90 hover:text-white hover:bg-[#004a9e]/40'
              }`}
            >
              <Database className="w-5 h-5 shrink-0 text-amber-400" />
              Bảo tồn & Sao lưu Dữ liệu
            </button>
          </nav>
        </div>

        {/* Action Logout button */}
        <div className="px-4 py-3 border-t border-[#004a9e]/40 dark:border-slate-800/80">
          <button
            onClick={handleLogout}
            className="flex items-center justify-center gap-2 w-full px-4 py-3 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-sm whitespace-nowrap"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            Đăng xuất hệ thống
          </button>
        </div>

        {/* Footer Dark mode controls */}
        <div className="p-4 border-t border-[#004a9e] dark:border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-blue-200/60 dark:text-slate-400 font-bold uppercase tracking-wider whitespace-nowrap">Giao diện</span>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-1.5 rounded-lg bg-[#004a9e]/40 dark:bg-slate-800 text-blue-100 dark:text-slate-300 hover:bg-[#004a9e]/80 dark:hover:bg-slate-750 transition-colors cursor-pointer"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-300" />}
          </button>
        </div>
      </aside>

      {/* 2. MAIN WORKSPACE CONTENT */}
      <div className="flex-1 flex flex-col md:pl-80 min-w-0">
        
        {/* Top Header Bar for mobile toggles and actions */}
        <header className="no-print bg-white dark:bg-slate-850 h-16 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 dark:text-slate-350 rounded-lg bg-slate-50 dark:bg-slate-800 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h2 className="font-extrabold text-[#00387B] dark:text-blue-400 uppercase text-xs md:text-sm tracking-wider">
              Ứng dụng quản lý dùng chung - Trung tâm Phục vụ hành chính công Phường Cầu Kiệu - TP.Hồ Chí Minh
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold bg-blue-50/50 dark:bg-blue-950/20 text-[#00387B] dark:text-blue-300 px-3 py-1 rounded-full border border-blue-100 dark:border-blue-900/40">
              Phường Cầu Kiệu
            </span>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-950/60 rounded-lg border border-red-100 dark:border-red-900/40 transition-colors cursor-pointer"
              title="Đăng xuất khỏi hệ thống"
            >
              <LogOut className="w-3.5 h-3.5" />
              Đăng xuất
            </button>
          </div>
        </header>

        {/* Workspace body panels */}
        <main className="flex-1 p-4 md:p-6 overflow-y-auto">
          
          {/* --- VIEW 1: DASHBOARD (BẢNG ĐIỀU KHIỂN) --- */}
          {currentView === 'dashboard' && (
            <div className="space-y-6">
              
              {/* Dashboard Statistics Filter Header */}
              <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                      <SlidersHorizontal className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      Bộ lọc thời gian thống kê
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">Chọn khoảng thời gian để xem thống kê tổng hợp và chi tiết từng loại phiếu</p>
                  </div>

                  {/* Filter tabs */}
                  <div className="flex flex-wrap items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                    <button
                      onClick={() => setDashboardFilterType('all')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                        dashboardFilterType === 'all'
                          ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-bold'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      Tất cả
                    </button>
                    <button
                      onClick={() => setDashboardFilterType('day')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                        dashboardFilterType === 'day'
                          ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-bold'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      Ngày
                    </button>
                    <button
                      onClick={() => setDashboardFilterType('month')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                        dashboardFilterType === 'month'
                          ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-bold'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      Tháng
                    </button>
                    <button
                      onClick={() => setDashboardFilterType('quarter')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                        dashboardFilterType === 'quarter'
                          ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-bold'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      Quý
                    </button>
                    <button
                      onClick={() => setDashboardFilterType('year')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                        dashboardFilterType === 'year'
                          ? 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-sm font-bold'
                          : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                      }`}
                    >
                      Năm
                    </button>
                  </div>
                </div>

                {/* Sub-selectors for custom periods */}
                {dashboardFilterType !== 'all' && (
                  <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 dark:border-slate-800 transition-all duration-200">
                    {dashboardFilterType === 'day' && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-500">Chọn Ngày:</span>
                        <input
                          type="date"
                          value={dashboardFilterDay}
                          onChange={(e) => setDashboardFilterDay(e.target.value)}
                          className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                        />
                      </div>
                    )}

                    {dashboardFilterType === 'month' && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-500">Chọn Tháng:</span>
                        <input
                          type="month"
                          value={dashboardFilterMonth}
                          onChange={(e) => setDashboardFilterMonth(e.target.value)}
                          className="px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                        />
                      </div>
                    )}

                    {dashboardFilterType === 'quarter' && (
                      <div className="flex flex-wrap items-center gap-3">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-500">Chọn Quý:</span>
                          <select
                            value={dashboardFilterQuarter}
                            onChange={(e) => setDashboardFilterQuarter(e.target.value)}
                            className="px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                          >
                            <option value="1">Quý I (Tháng 1-3)</option>
                            <option value="2">Quý II (Tháng 4-6)</option>
                            <option value="3">Quý III (Tháng 7-9)</option>
                            <option value="4">Quý IV (Tháng 10-12)</option>
                          </select>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-500">Năm:</span>
                          <input
                            type="number"
                            min="1990"
                            max="2050"
                            value={dashboardFilterYear}
                            onChange={(e) => setDashboardFilterYear(e.target.value)}
                            className="w-20 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono text-center"
                          />
                        </div>
                      </div>
                    )}

                    {dashboardFilterType === 'year' && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-500">Chọn Năm:</span>
                        <input
                          type="number"
                          min="1990"
                          max="2050"
                          value={dashboardFilterYear}
                          onChange={(e) => setDashboardFilterYear(e.target.value)}
                          className="w-24 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono text-center"
                        />
                      </div>
                    )}
                  </div>
                )}
                
                {/* Active time banner label */}
                <div className="text-[11px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20 px-3 py-1.5 rounded-lg border border-blue-100/30 dark:border-blue-900/30 inline-block">
                  Đang xem thống kê: {
                    dashboardFilterType === 'all' ? 'Tất cả thời gian' :
                    dashboardFilterType === 'day' ? `Ngày ${formatDateVN(dashboardFilterDay)}` :
                    dashboardFilterType === 'month' ? `Tháng ${dashboardFilterMonth.split('-')[1]}/${dashboardFilterMonth.split('-')[0]}` :
                    dashboardFilterType === 'quarter' ? `Quý ${dashboardFilterQuarter} - Năm ${dashboardFilterYear}` :
                    `Năm ${dashboardFilterYear}`
                  }
                </div>
              </div>

              {/* Quick Summary KPI Cards */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Tổng hồ sơ</span>
                  <p className="text-2xl font-black text-slate-850 dark:text-slate-100 mt-2">{stats.total}</p>
                </div>
                <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Chờ xử lý</span>
                  <p className="text-2xl font-black text-blue-600 mt-2">{stats.pending}</p>
                </div>
                <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Bổ sung (Mẫu 02)</span>
                  <p className="text-2xl font-black text-amber-500 mt-2">{stats.boSung}</p>
                </div>
                <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Từ chối (Mẫu 03)</span>
                  <p className="text-2xl font-black text-red-500 mt-2">{stats.refused}</p>
                </div>
                <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Dừng (Mẫu 05)</span>
                  <p className="text-2xl font-black text-slate-600 mt-2">{stats.stopped}</p>
                </div>
              </div>

              {/* Graphical Layout Panel */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* SVG Status Column Bar Chart Visualizer */}
                <div className="lg:col-span-2 bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                    <div>
                      <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 mb-0.5 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400"></span>
                        Cơ cấu Trạng thái Xử lý hồ sơ
                      </h3>
                      <p className="text-xs text-slate-400">Biểu đồ hình cột thể hiện cơ cấu và số lượng hồ sơ hành chính</p>
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300 shrink-0">
                      <span>Tổng số:</span>
                      <span className="font-bold font-mono text-blue-600 dark:text-blue-400">{stats.total}</span>
                      <span>hồ sơ</span>
                    </div>
                  </div>
                  
                  {(() => {
                    const statusItems = [
                      { label: 'Chờ duyệt', count: stats.pending, colorClass: 'bg-blue-500 hover:bg-blue-600', textClass: 'text-blue-600 dark:text-blue-400', borderClass: 'border-blue-500', hex: '#3b82f6' },
                      { label: 'Yêu cầu bổ sung', count: stats.boSung, colorClass: 'bg-amber-500 hover:bg-amber-600', textClass: 'text-amber-600 dark:text-amber-400', borderClass: 'border-amber-500', hex: '#f59e0b' },
                      { label: 'Từ chối tiếp nhận', count: stats.refused, colorClass: 'bg-red-500 hover:bg-red-600', textClass: 'text-red-600 dark:text-red-400', borderClass: 'border-red-500', hex: '#ef4444' },
                      { label: 'Hoàn thành', count: stats.supplemented, colorClass: 'bg-emerald-500 hover:bg-emerald-600', textClass: 'text-emerald-600 dark:text-emerald-400', borderClass: 'border-emerald-500', hex: '#10b981' },
                      { label: 'Đã dừng giải quyết', count: stats.stopped, colorClass: 'bg-slate-500 hover:bg-slate-600', textClass: 'text-slate-600 dark:text-slate-400', borderClass: 'border-slate-500', hex: '#64748b' },
                    ];
                    
                    const maxCount = Math.max(...statusItems.map(s => s.count), 1);

                    return (
                      <div className="flex-1 flex flex-col justify-center my-2 space-y-4">
                        {/* Graphical Column Bars Container */}
                        <div className="relative pt-5 pb-3 px-3 bg-slate-50/70 dark:bg-slate-900/40 rounded-xl border border-slate-200/60 dark:border-slate-800 w-full flex flex-col justify-center items-center">
                          {/* Y-axis gridlines */}
                          <div className="absolute inset-x-3 top-4 bottom-12 flex flex-col justify-between pointer-events-none opacity-25">
                            <div className="border-b border-dashed border-slate-400 dark:border-slate-600 w-full" />
                            <div className="border-b border-dashed border-slate-400 dark:border-slate-600 w-full" />
                            <div className="border-b border-dashed border-slate-400 dark:border-slate-600 w-full" />
                          </div>

                          <div className="h-44 flex items-end justify-around relative z-10 w-full gap-2 px-1">
                            {statusItems.map((item, idx) => {
                              const pct = stats.total > 0 ? Math.round((item.count / stats.total) * 100) : 0;
                              // Minimum visual height of 10px so empty bars remain visible
                              const heightPx = Math.max(10, Math.round((item.count / maxCount) * 120));

                              return (
                                <div key={idx} className="flex flex-col items-center flex-1 max-w-[90px] group cursor-pointer">
                                  {/* Value tooltip above column */}
                                  <div className="mb-1.5 text-center transition-transform group-hover:-translate-y-0.5">
                                    <span className="text-xs font-black text-slate-800 dark:text-slate-100 block font-mono">
                                      {item.count}
                                    </span>
                                    <span className="text-[10px] font-semibold text-slate-400 block font-mono">
                                      {pct}%
                                    </span>
                                  </div>

                                  {/* Column Bar Container */}
                                  <div className="w-full h-32 flex items-end justify-center bg-slate-200/50 dark:bg-slate-800/60 rounded-t-lg p-1">
                                    <div
                                      className={`w-full max-w-[38px] ${item.colorClass} rounded-t-md transition-all duration-500 shadow-xs relative overflow-hidden`}
                                      style={{ height: `${heightPx}px` }}
                                    >
                                      {/* Glass highlight effect */}
                                      <div className="absolute top-0 left-0 right-0 h-1/3 bg-white/20 rounded-t-md pointer-events-none" />
                                    </div>
                                  </div>

                                  {/* Column Label */}
                                  <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 text-center leading-tight mt-2 truncate w-full px-0.5" title={item.label}>
                                    {item.label}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Chart Legend / Ghi chú chi tiết */}
                        <div className="w-full">
                          <h4 className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                            <span>Ghi chú & Tỷ lệ chi tiết</span>
                          </h4>
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 w-full">
                            {statusItems.map((item, idx) => {
                              const pct = stats.total > 0 ? Math.round((item.count / stats.total) * 100) : 0;
                              return (
                                <div key={idx} className="bg-slate-50 dark:bg-slate-800/60 p-2 rounded-lg border border-slate-100 dark:border-slate-800 flex flex-col justify-between">
                                  <div className="flex items-center gap-1.5 mb-1">
                                    <span className={`w-2.5 h-2.5 rounded-sm ${item.colorClass} shrink-0`} />
                                    <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 truncate" title={item.label}>
                                      {item.label}
                                    </span>
                                  </div>
                                  <div className="flex items-baseline justify-between font-mono mt-0.5">
                                    <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                                      {item.count}
                                    </span>
                                    <span className="text-[10px] font-semibold text-slate-400">
                                      {pct}%
                                    </span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Right Column Stack: Form Type Statistics & Quick Actions */}
                <div className="lg:col-span-1 space-y-6 flex flex-col justify-between">
                  {/* Detailed Statistics by Form Type */}
                  <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                    <div>
                      <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 mb-1">Thống kê theo từng loại phiếu</h3>
                      <p className="text-xs text-slate-400">Phân phối số lượng phiếu biểu mẫu được cấp phát</p>
                    </div>
                    
                    <div className="space-y-3.5 pt-1">
                      {/* Mẫu 02 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block" />
                            Yêu cầu bổ sung (Mẫu 02)
                          </span>
                          <span className="text-slate-800 dark:text-slate-100 font-mono text-xs">{stats.countMau02} phiếu</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div 
                            className="bg-amber-500 h-full rounded-full transition-all duration-500" 
                            style={{ width: `${stats.total > 0 ? (stats.countMau02 / stats.total) * 100 : 0}%` }}
                          />
                        </div>
                      </div>

                      {/* Mẫu 03 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-red-500 block" />
                            Từ chối tiếp nhận (Mẫu 03)
                          </span>
                          <span className="text-slate-800 dark:text-slate-100 font-mono text-xs">{stats.countMau03} phiếu</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div 
                            className="bg-red-500 h-full rounded-full transition-all duration-500" 
                            style={{ width: `${stats.total > 0 ? (stats.countMau03 / stats.total) * 100 : 0}%` }}
                          />
                        </div>
                      </div>

                      {/* Mẫu 05 */}
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-slate-500 block" />
                            Dừng giải quyết (Mẫu 05)
                          </span>
                          <span className="text-slate-800 dark:text-slate-100 font-mono text-xs">{stats.countMau05} phiếu</span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div 
                            className="bg-slate-500 h-full rounded-full transition-all duration-500" 
                            style={{ width: `${stats.total > 0 ? (stats.countMau05 / stats.total) * 100 : 0}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-2 rounded-lg border border-slate-100 dark:border-slate-800 font-medium">
                      Tỷ số % biểu mẫu trên tổng <span className="font-bold">{stats.total} hồ sơ</span>.
                    </div>
                  </div>

                  {/* Detailed Statistics by Field/Lĩnh vực */}
                  <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                    <div>
                      <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 mb-1">Thống kê theo từng lĩnh vực</h3>
                      <p className="text-xs text-slate-400">Phân phối số lượng phiếu biểu mẫu theo lĩnh vực chuyên môn</p>
                    </div>
                    
                    <div className="space-y-3.5 pt-1 max-h-[220px] overflow-y-auto pr-1">
                      {Object.entries(stats.statsByField || {}).map(([field, fieldStat], index) => {
                        const colors = ['bg-blue-500', 'bg-teal-500', 'bg-violet-500', 'bg-amber-500', 'bg-rose-500', 'bg-emerald-500', 'bg-pink-500'];
                        const colorClass = colors[index % colors.length];
                        const totalInField = fieldStat.total;
                        return (
                          <div key={field} className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-1.5">
                            <div className="flex items-center justify-between text-xs font-bold">
                              <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1.5 truncate max-w-[190px]" title={field}>
                                <span className={`w-2 h-2 rounded-full ${colorClass} block shrink-0`} />
                                {field}
                              </span>
                              <span className="text-slate-900 dark:text-slate-100 font-mono text-xs">{totalInField} phiếu</span>
                            </div>
                            <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                              <div 
                                className={`${colorClass} h-full rounded-full transition-all duration-500`} 
                                style={{ width: `${stats.total > 0 ? (totalInField / stats.total) * 100 : 0}%` }}
                              />
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium pt-0.5">
                              <span>Mẫu 02: {fieldStat.mau02} | Mẫu 03: {fieldStat.mau03} | Mẫu 05: {fieldStat.mau05}</span>
                              <span className="font-semibold text-slate-500">STT cao nhất: #{fieldStat.maxTicket || 0}</span>
                            </div>
                          </div>
                        );
                      })}
                      {Object.keys(stats.statsByField || {}).length === 0 && (
                        <p className="text-xs text-slate-400 italic text-center py-2">Chưa có hồ sơ phân loại lĩnh vực.</p>
                      )}
                    </div>

                    <div className="text-[10px] text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-2 rounded-lg border border-slate-100 dark:border-slate-800 font-medium flex items-center justify-between">
                      <span>Tổng hồ sơ để theo dõi:</span>
                      <span className="font-bold text-slate-800 dark:text-slate-100 font-mono text-xs">{stats.total} hồ sơ</span>
                    </div>
                  </div>

                  {/* Quick actions panel */}
                  <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 mb-4">Lối tắt tác vụ nhanh</h3>
                      <div className="space-y-2.5">
                        <button 
                          onClick={() => startNewDocument('mau02')}
                          className="flex items-center justify-between w-full p-3 bg-blue-50/50 hover:bg-blue-50 text-blue-700 dark:bg-blue-950/20 dark:text-blue-300 dark:hover:bg-blue-950/40 rounded-xl transition-all font-semibold text-xs border border-blue-100/50 dark:border-blue-900/40 cursor-pointer"
                        >
                          <span className="flex items-center gap-2">
                            <Plus className="w-4 h-4 text-blue-600" />
                            Soạn phiếu bổ sung (Mẫu 02)
                          </span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => startNewDocument('mau03')}
                          className="flex items-center justify-between w-full p-3 bg-red-50/50 hover:bg-red-50 text-red-700 dark:bg-red-950/20 dark:text-red-300 dark:hover:bg-red-950/40 rounded-xl transition-all font-semibold text-xs border border-red-100/50 dark:border-red-900/40 cursor-pointer"
                        >
                          <span className="flex items-center gap-2">
                            <Plus className="w-4 h-4 text-red-600" />
                            Soạn phiếu từ chối (Mẫu 03)
                          </span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => { setCurrentView('logbook'); }}
                          className="flex items-center justify-between w-full p-3 bg-slate-50 hover:bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-750 rounded-xl transition-all font-semibold text-xs border border-slate-200/50 dark:border-slate-700/50 cursor-pointer"
                        >
                          <span className="flex items-center gap-2">
                            <FileSpreadsheet className="w-4 h-4 text-slate-500" />
                            Sổ theo dõi hồ sơ của Phường
                          </span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 dark:border-slate-800 pt-4 mt-4 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Nhập từ tệp</span>
                      <button 
                        onClick={() => setCurrentView('import')}
                        className="text-xs text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <FileUp className="w-3.5 h-3.5" /> Nhập Excel
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Latest Audits List on Dashboard */}
              <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200">Hoạt động xử lý vừa qua</h3>
                  <button 
                    onClick={() => setCurrentView('audits')}
                    className="text-xs text-blue-600 hover:text-blue-700 font-bold cursor-pointer"
                  >
                    Xem tất cả nhật ký
                  </button>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {auditLogs.slice(0, 4).map((log, index) => (
                    <div key={index} className="p-4 flex items-center justify-between text-xs hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                      <div className="flex items-center gap-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'Thêm' || log.action === 'Sửa' ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/20 dark:text-blue-300' :
                          log.action === 'Xóa' ? 'bg-red-50 text-red-700 dark:bg-red-950/20' : 'bg-slate-100 text-slate-650'
                        }`}>
                          {log.action}
                        </span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200 max-w-md truncate">{log.details}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">{new Date(log.timestamp).toLocaleTimeString('vi-VN')}</span>
                    </div>
                  ))}
                  {auditLogs.length === 0 && (
                    <div className="p-6 text-center text-slate-400 italic">Chưa có hoạt động hệ thống nào diễn ra.</div>
                  )}
                </div>
              </div>
            </div>
          )}


          {/* --- VIEW 2: DOCUMENT EDITOR (SOẠN PHIẾU CHUYÊN SÂU) --- */}
          {currentView === 'editor' && (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
              
              {/* Form Input Control Pane */}
              <div className="bg-white dark:bg-slate-850 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200">
                      {editingRecordId ? 'Chỉnh sửa tài liệu' : 'Soạn phiếu giải quyết mới'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      Biên dịch sang biểu mẫu {activeFormType === 'mau02' ? 'Mẫu 02 (Bổ sung)' : activeFormType === 'mau03' ? 'Mẫu 03 (Từ chối)' : 'Mẫu 05 (Dừng)'}
                    </p>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => startNewDocument(activeFormType)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-50 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg cursor-pointer"
                    >
                      Làm trống
                    </button>
                  </div>
                </div>

                <form onSubmit={handleSaveRecord} className="space-y-4 text-sm">
                  {/* Administrative Record Field & Procedure (First Position) */}
                  <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/40 rounded-xl space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-1">
                        <label className="block text-xs font-bold text-blue-700 dark:text-blue-400 uppercase mb-1">Lĩnh vực thủ tục <span className="text-red-500">*</span></label>
                        <select
                          required
                          value={formLinhVuc}
                          onChange={(e) => {
                            const val = e.target.value;
                            setFormLinhVuc(val);
                            setFormTicketNo(generateTicketNoForLinhVuc(activeFormType, val));
                          }}
                          className="w-full px-3 py-2 border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                        >
                          <option value="">-- Chọn lĩnh vực --</option>
                          {Array.from(new Set([
                            ...PROCEDURE_FIELDS,
                            ...procedures.map(p => p.field).filter(Boolean)
                          ])).map(f => (
                            <option key={f} value={f}>{f}</option>
                          ))}
                        </select>
                      </div>

                      <div className="md:col-span-2 space-y-2">
                        <div>
                          <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Thủ tục Hành chính yêu cầu (Chọn từ danh mục)</label>
                          <select
                            value={formProcedureContent}
                            onChange={(e) => {
                              const val = e.target.value;
                              setFormProcedureContent(val);
                              const proc = procedures.find(p => p.name === val);
                              if (proc && proc.field) {
                                setFormLinhVuc(proc.field);
                                setFormTicketNo(generateTicketNoForLinhVuc(activeFormType, proc.field));
                              }
                            }}
                            className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                          >
                            <option value="">-- Chọn thủ tục từ danh mục --</option>
                            {procedures.map(p => (
                              <option key={p.id} value={p.name}>{p.name} ({p.code})</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-blue-700 dark:text-blue-400 uppercase mb-1">
                            Nội dung yêu cầu giải quyết
                          </label>
                          <input
                            type="text"
                            placeholder="Nhập trực tiếp hoặc tùy chỉnh nội dung yêu cầu giải quyết..."
                            value={formProcedureContent}
                            onChange={(e) => setFormProcedureContent(e.target.value)}
                            className="w-full px-3 py-2 border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                          />
                        </div>
                      </div>
                    </div>

                    {/* If Lĩnh vực khác is chosen, show manual input */}
                    {formLinhVuc === 'Khác' && (
                      <div className="pt-2 border-t border-blue-100 dark:border-blue-900/30">
                        <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Nhập Lĩnh vực mới</label>
                        <input
                          type="text"
                          placeholder="Nhập tên lĩnh vực"
                          onChange={(e) => {
                            const val = e.target.value;
                            setFormLinhVuc(val);
                            setFormTicketNo(generateTicketNoForLinhVuc(activeFormType, val));
                          }}
                          className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    )}
                  </div>

                  {/* Basic ticket fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Số phiếu thụ lý <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="Chỉ nhập số"
                        value={formTicketNo}
                        onChange={(e) => setFormTicketNo(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Ngày lập văn bản</label>
                      <input
                        type="date"
                        required
                        value={formCreatedDate}
                        onChange={(e) => setFormCreatedDate(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Citizen Credentials fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Tên công dân, tổ chức <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="Nguyễn Văn A hoặc Công ty TNHH ABC"
                        value={formCitizenName}
                        onChange={(e) => setFormCitizenName(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Số định danh cá nhân / CCCD / MST</label>
                      <input
                        type="text"
                        placeholder="CCCD hoặc Mã số thuế (Không bắt buộc)"
                        value={formCitizenId}
                        onChange={(e) => setFormCitizenId(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Địa chỉ thường trú/trụ sở</label>
                    <input
                      type="text"
                      placeholder="Số nhà, đường, phường, quận..."
                      value={formAddress}
                      onChange={(e) => setFormAddress(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Số điện thoại</label>
                      <input
                        type="text"
                        value={formPhone}
                        onChange={(e) => setFormPhone(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Email liên lạc</label>
                      <input
                        type="email"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-1">
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Mã hồ sơ (Nếu có)</label>
                      <input
                        type="text"
                        placeholder="E.g., HS-2026-004122"
                        value={formRecordId}
                        onChange={(e) => setFormRecordId(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* FORM TYPE 02: SUPPLMENT PAPERS LIST BUILDER */}
                  {activeFormType === 'mau02' && (
                    <div className="p-4 bg-blue-50/20 border border-blue-500/20 rounded-xl space-y-4">
                      <h4 className="text-xs font-bold text-blue-900 dark:text-blue-400 uppercase tracking-wide">
                        Danh sách hồ sơ giấy tờ cần bổ sung, hoàn thiện
                      </h4>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="E.g., Bản sao CCCD công chứng"
                          value={newPaperInput}
                          onChange={(e) => setNewPaperInput(e.target.value)}
                          className="flex-1 text-xs px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleAddPaper}
                          className="px-3 py-2 bg-blue-600 text-white font-bold rounded-lg text-xs hover:bg-blue-700 cursor-pointer"
                        >
                          Thêm giấy tờ
                        </button>
                      </div>

                      <div className="space-y-1.5 max-h-[150px] overflow-y-auto">
                        {formPapersList.map((paper, idx) => (
                          <div key={idx} className="flex items-center justify-between bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-100 dark:border-slate-700 text-xs">
                            <span className="font-medium">{idx + 1}. {paper}</span>
                            <button
                              type="button"
                              onClick={() => handleRemovePaper(idx)}
                              className="text-red-500 hover:text-red-600 cursor-pointer"
                            >
                              Xóa
                            </button>
                          </div>
                        ))}
                        {formPapersList.length === 0 && (
                          <p className="text-xs text-slate-400 italic text-center py-2">Danh sách trống. Vui lòng nộp danh sách bổ sung.</p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Refusal / Addition Reasons & Predefined Reasons integration */}
                  {(activeFormType === 'mau03' || activeFormType === 'mau02') && (
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <label className="block text-xs font-bold text-slate-400 uppercase">
                            {activeFormType === 'mau02' ? 'Chi tiết yêu cầu / Lý do' : 'Lý do từ chối cụ thể'}
                          </label>
                          <select
                            onChange={(e) => handleSelectPredefinedReason(e.target.value)}
                            className="text-xs font-bold text-blue-600 bg-blue-50/50 dark:bg-blue-950/20 dark:text-blue-300 border-none focus:outline-none py-1 px-2 rounded max-w-[200px]"
                          >
                            <option value="">-- Áp lý do soạn sẵn --</option>
                            {reasons.filter(r => r.formType === activeFormType).map(r => (
                              <option key={r.id} value={r.content}>{r.title}</option>
                            ))}
                          </select>
                        </div>
                        <textarea
                          rows={3}
                          value={formRejectionReason}
                          onChange={(e) => setFormRejectionReason(e.target.value)}
                          placeholder={activeFormType === 'mau02' ? "Cung cấp chi tiết các vướng mắc hồ sơ..." : "Hồ sơ không thuộc thẩm quyền giải quyết..."}
                          className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 resize-none text-justify"
                        />
                      </div>
                    </div>
                  )}

                  {/* FORM TYPE 05 SPECIFIC: LEADER & REQUEST DATA */}
                  {activeFormType === 'mau05' && (
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-4 border border-slate-100 dark:border-slate-700">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Ngày công dân gửi đơn dừng</label>
                          <input
                            type="date"
                            value={formStopDateRequest}
                            onChange={(e) => setFormStopDateRequest(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Thủ trưởng ký duyệt <span className="text-slate-400 font-normal lowercase">(để trống để tự điền/ký)</span></label>
                          <input
                            type="text"
                            value={formLeaderName}
                            onChange={(e) => setFormLeaderName(e.target.value)}
                            placeholder="Để trống để công chức tự điền tay/đóng dấu"
                            className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none"
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <label className="block text-xs font-bold text-slate-400 uppercase">Lý do dừng hồ sơ hành chính</label>
                          <select
                            onChange={(e) => handleSelectPredefinedReason(e.target.value)}
                            className="text-xs font-bold text-blue-600 bg-blue-50/50 dark:bg-blue-950/20 dark:text-blue-300 border-none focus:outline-none py-1 px-2 rounded"
                          >
                            <option value="">-- Áp lý do soạn sẵn --</option>
                            {reasons.filter(r => r.formType === 'mau05').map(r => (
                              <option key={r.id} value={r.content}>{r.title}</option>
                            ))}
                          </select>
                        </div>
                        <textarea
                          rows={2}
                          value={formStopReason}
                          onChange={(e) => setFormStopReason(e.target.value)}
                          placeholder="Công dân gửi đơn xin rút do thay đổi nhu cầu xây dựng..."
                          className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none resize-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Processing officer configuration */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Cán bộ thụ lý hồ sơ</label>
                      <select
                        value={formOfficerName}
                        onChange={(e) => {
                          const off = officers.find(o => o.name === e.target.value);
                          setFormOfficerName(e.target.value);
                          if (off) setFormOfficerPhone(off.phone);
                        }}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      >
                        {officers.map(o => (
                          <option key={o.id} value={o.name}>{o.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Điện thoại hướng dẫn</label>
                      <input
                        type="text"
                        value={formOfficerPhone}
                        onChange={(e) => setFormOfficerPhone(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Trạng thái hồ sơ</label>
                      <select
                        value={formStatus}
                        onChange={(e) => setFormStatus(e.target.value as Record['status'])}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-semibold"
                      >
                        <option value="cho_xu_ly">Chờ xử lý (Mới nhận)</option>
                        <option value="bo_sung">Đã gửi yêu cầu bổ sung</option>
                        <option value="tu_choi">Đã gửi phiếu từ chối</option>
                        <option value="da_dung">Đã dừng giải quyết thủ tục</option>
                        <option value="da_hoan_thien">Đã giải quyết hoàn thành</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Ghi chú cán bộ</label>
                      <input
                        type="text"
                        placeholder="Ghi chú nhanh..."
                        value={formNotes}
                        onChange={(e) => setFormNotes(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-sm transition-colors cursor-pointer text-center"
                      id="btn-save-record"
                    >
                      {editingRecordId ? 'Lưu cập nhật hồ sơ' : 'Khởi tạo & Lưu hồ sơ'}
                    </button>
                    {editingRecordId && (
                      <button
                        type="button"
                        onClick={() => startNewDocument(activeFormType)}
                        className="px-4 py-2.5 bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:text-slate-350 dark:border-slate-700 rounded-lg font-semibold text-sm cursor-pointer"
                      >
                        Hủy Sửa
                      </button>
                    )}
                  </div>
                </form>

                {/* Local record revision logs if editing */}
                {editingRecordId && records.find(r => r.id === editingRecordId) && (
                  <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-150 dark:border-slate-700 rounded-xl space-y-3">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                      <History className="w-4 h-4 text-blue-600" />
                      Lịch sử chỉnh sửa hồ sơ
                    </h4>
                    <div className="space-y-2 max-h-[120px] overflow-y-auto">
                      {records.find(r => r.id === editingRecordId)?.history.map((h, i) => (
                        <div key={i} className="text-xs border-b border-dashed border-slate-100 dark:border-slate-700 pb-2 flex justify-between gap-4">
                          <div>
                            <p className="font-semibold text-slate-700 dark:text-slate-300">{h.action} bởi {h.user}</p>
                            <p className="text-slate-400 mt-0.5 text-[10px]">{h.details}</p>
                          </div>
                          <span className="text-[10px] text-slate-400 shrink-0 font-mono">{new Date(h.timestamp).toLocaleTimeString('vi-VN')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Document Paper Previewer Pane */}
              <div className="h-full">
                <DocumentPreview 
                  record={dummyActiveRecord}
                  onPrint={() => handlePrintRecord(dummyActiveRecord)}
                  onExportWord={() => handleExportWordRecord(dummyActiveRecord)}
                  autoPrint={autoPrintActive}
                />
              </div>
            </div>
          )}


          {/* --- VIEW 3: RECORDS REGISTRY (SỔ QUẢN LÝ HỒ SƠ) --- */}
          {currentView === 'records' && (
            <div className="space-y-6">
              {/* Header Filters block */}
              <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 gap-4">
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200">Kho lưu trữ Hồ sơ Hành chính</h3>
                    <p className="text-xs text-slate-400">Xem, chỉnh sửa, truy cứu lịch sử và xuất tài liệu hành chính</p>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => startNewDocument('mau02')}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Tạo hồ sơ mới
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                  {/* Search input */}
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
                    <Search className="w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      placeholder="Tìm theo Tên, CCCD, Số phiếu..."
                      value={recordsSearch}
                      onChange={(e) => { setRecordsSearch(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
                    />
                  </div>

                  {/* Field filter */}
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
                    <Filter className="w-4 h-4 text-slate-400 shrink-0" />
                    <select
                      id="records-field-filter-select"
                      value={recordsFieldFilter}
                      onChange={(e) => { setRecordsFieldFilter(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      <option value="">Tất cả Lĩnh vực</option>
                      <option value="Hộ tịch">Hộ tịch</option>
                      <option value="Kinh tế">Kinh tế</option>
                      <option value="Đất đai - Tài nguyên Môi trường">Đất đai - Môi trường</option>
                      <option value="Tư pháp - Chứng thực">Chứng thực / Tư pháp</option>
                      <option value="Văn hóa - Xã hội">Văn hóa - Xã hội</option>
                      <option value="Đô thị - Xây dựng">Đô thị - Xây dựng</option>
                    </select>
                  </div>

                  {/* Status filter */}
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
                    <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0" />
                    <select
                      value={recordsStatusFilter}
                      onChange={(e) => { setRecordsStatusFilter(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
                    >
                      <option value="">Tất cả Trạng thái</option>
                      <option value="cho_xu_ly">Chờ xử lý</option>
                      <option value="bo_sung">Yêu cầu bổ sung</option>
                      <option value="tu_choi">Từ chối</option>
                      <option value="da_dung">Đã dừng</option>
                      <option value="da_hoan_thien">Đã hoàn thành</option>
                    </select>
                  </div>

                  {/* Form type filter */}
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm">
                    <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                    <select
                      value={recordsTypeFilter}
                      onChange={(e) => { setRecordsTypeFilter(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 dark:text-slate-200"
                    >
                      <option value="">Tất cả Biểu mẫu</option>
                      <option value="mau02">Bổ sung (Mẫu 02)</option>
                      <option value="mau03">Từ chối (Mẫu 03)</option>
                      <option value="mau05">Dừng giải quyết (Mẫu 05)</option>
                    </select>
                  </div>

                  {/* Sổ theo dõi Excel download triggers */}
                  <button
                    onClick={() => exportLogbookToExcel(filteredRecords)}
                    className="flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900 rounded-lg py-2 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4" /> Xuất Excel ({filteredRecords.length})
                  </button>
                </div>
              </div>

              {/* Records Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedRecords.map((r) => (
                  <div 
                    key={r.id} 
                    className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 hover:shadow-md transition-all flex flex-col justify-between space-y-4 relative group overflow-hidden"
                  >
                    {/* Badge type label absolute */}
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        r.formType === 'mau02' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300' :
                        r.formType === 'mau03' ? 'bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-300' :
                        'bg-blue-100 text-blue-800 dark:bg-blue-950/30 dark:text-blue-300'
                      }`}>
                        {getFormTypeLabel(r.formType).split(' (')[0]}
                      </span>
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md ${
                        r.status === 'cho_xu_ly' ? 'bg-blue-50 text-blue-600' :
                        r.status === 'da_hoan_thien' ? 'bg-emerald-50 text-emerald-600' :
                        r.status === 'tu_choi' ? 'bg-red-50 text-red-600' :
                        r.status === 'bo_sung' ? 'bg-amber-50 text-amber-600' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {getStatusLabel(r.status)}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm whitespace-normal break-words">{r.citizenName}</h4>
                      <p className="text-[11px] text-slate-400 font-mono mt-0.5">Số phiếu: {r.ticketNo}</p>
                      
                      <div className="space-y-1.5 my-3 text-xs text-slate-600 dark:text-slate-350">
                        <p className="whitespace-normal break-words flex items-start gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                          <span><span className="font-semibold text-slate-400">Đ/c:</span> {r.address || 'N/A'}</span>
                        </p>
                        <p className="truncate flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          {r.phone || 'N/A'}
                        </p>
                        <p className="truncate flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          Ngày lập: {formatDateVN(r.createdDate)}
                        </p>
                        <p className="truncate flex items-center gap-1.5">
                          <ListChecks className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          Mã hồ sơ: {r.recordId || 'Chưa đăng ký'}
                        </p>
                      </div>

                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 text-justify bg-slate-50 dark:bg-slate-800 p-2 rounded-lg italic">
                        "{r.procedureContent}"
                      </p>
                    </div>

                    {/* Operational action footer bar */}
                    <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3 text-xs font-semibold gap-1.5">
                      <button
                        onClick={() => loadRecordForEditing(r)}
                        className="flex items-center gap-1 py-1.5 px-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer flex-1 justify-center"
                      >
                        <Edit className="w-3.5 h-3.5" /> Biên tập
                      </button>
                      <button
                        onClick={() => loadRecordForEditing(r, true)}
                        className="flex items-center gap-1 py-1.5 px-2.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-150 dark:bg-red-950/20 dark:text-red-300 dark:border-red-900 rounded-lg cursor-pointer"
                        title="Xuất file PDF"
                      >
                        <FileText className="w-3.5 h-3.5" /> Xuất PDF
                      </button>
                      <button
                        onClick={() => handleExportWordRecord(r)}
                        className="flex items-center gap-1 py-1.5 px-2.5 bg-blue-50 hover:bg-blue-100 text-[#00387B] border border-blue-150 dark:bg-blue-950/20 dark:text-blue-300 dark:border-blue-900 rounded-lg cursor-pointer"
                        title="Xuất Word tệp mẫu Chuẩn"
                      >
                        <Download className="w-3.5 h-3.5" /> Xuất Word
                      </button>
                      <button
                        onClick={() => handleDeleteRecord(r.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg cursor-pointer"
                        title="Xóa hồ sơ"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
                {filteredRecords.length === 0 && (
                  <div className="col-span-full py-12 text-center text-slate-400 italic">Không tìm thấy hồ sơ nào phù hợp.</div>
                )}
              </div>

              {/* Pagination controls footer */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center gap-2 pt-4">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(currentPage - 1)}
                    className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-bold text-slate-500">Trang {currentPage} / {totalPages}</span>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(currentPage + 1)}
                    className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}


          {/* --- VIEW 4: AUTOMATED SỔ THEO DÕI (REGISTRY LOGBOOK) --- */}
          {currentView === 'logbook' && (
            <div className="space-y-6">
              <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 gap-4">
                  <div>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200">Sổ theo dõi hồ sơ Thống nhất</h3>
                    <p className="text-xs text-slate-400">Biểu mẫu tổng hợp tự động các phiếu và tình trạng xử lý của UBND Phường</p>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => exportLogbookToExcel(filteredLogbookRecords, getLogbookReportFilename())}
                      className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer transition-colors"
                      id="btn-export-logbook"
                    >
                      <FileSpreadsheet className="w-4 h-4" /> Xuất Excel ({filteredLogbookRecords.length} dòng)
                    </button>
                  </div>
                </div>

                {/* LOGBOOK REPORT FILTER CONTROLS */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 rounded-xl bg-slate-50/50 dark:bg-slate-800/20 border border-slate-150 dark:border-slate-800" id="logbook-reporting-filters">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Lĩnh vực thủ tục</label>
                    <select
                      id="logbook-field-filter-select"
                      value={logbookFieldFilter}
                      onChange={(e) => { setLogbookFieldFilter(e.target.value); setLogbookCurrentPage(1); }}
                      className="w-full text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer font-semibold"
                    >
                      <option value="">📂 Tất cả Lĩnh vực</option>
                      <option value="Hộ tịch">Hộ tịch</option>
                      <option value="Kinh tế">Kinh tế</option>
                      <option value="Đất đai - Tài nguyên Môi trường">Đất đai - Môi trường</option>
                      <option value="Tư pháp - Chứng thực">Chứng thực / Tư pháp</option>
                      <option value="Văn hóa - Xã hội">Văn hóa - Xã hội</option>
                      <option value="Đô thị - Xây dựng">Đô thị - Xây dựng</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chế độ lọc báo cáo</label>
                    <select
                      id="logbook-filter-type-select"
                      value={logbookFilterType}
                      onChange={(e) => { setLogbookFilterType(e.target.value as any); setLogbookCurrentPage(1); }}
                      className="w-full text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer font-semibold"
                    >
                      <option value="all">📂 Tất cả sổ theo dõi</option>
                      <option value="day">📅 Lọc theo Ngày</option>
                      <option value="month">📆 Lọc theo Tháng</option>
                      <option value="quarter">📊 Lọc theo Quý</option>
                      <option value="year">📅 Lọc theo Năm</option>
                    </select>
                  </div>

                  {logbookFilterType === 'day' && (
                    <div className="space-y-1.5 md:col-span-3">
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chọn Ngày báo cáo</label>
                      <div className="flex flex-wrap items-center gap-3">
                        <input
                          id="logbook-filter-day-input"
                          type="date"
                          value={logbookFilterDay}
                          onChange={(e) => { setLogbookFilterDay(e.target.value); setLogbookCurrentPage(1); }}
                          className="text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                        />
                        <span className="text-xs font-medium text-slate-400 italic">
                          (Đang hiển thị các hồ sơ phát sinh vào ngày {formatDateVN(logbookFilterDay)})
                        </span>
                      </div>
                    </div>
                  )}

                  {logbookFilterType === 'month' && (
                    <div className="space-y-1.5 md:col-span-3">
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chọn Tháng báo cáo</label>
                      <div className="flex flex-wrap items-center gap-3">
                        <input
                          id="logbook-filter-month-input"
                          type="month"
                          value={logbookFilterMonth}
                          onChange={(e) => { setLogbookFilterMonth(e.target.value); setLogbookCurrentPage(1); }}
                          className="text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 font-mono"
                        />
                        <span className="text-xs font-medium text-slate-400 italic">
                          (Đang hiển thị các hồ sơ phát sinh vào tháng {logbookFilterMonth.split('-')[1]}/{logbookFilterMonth.split('-')[0]})
                        </span>
                      </div>
                    </div>
                  )}

                  {logbookFilterType === 'quarter' && (
                    <div className="space-y-1.5 md:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chọn Quý</label>
                        <select
                          id="logbook-filter-quarter-select"
                          value={logbookFilterQuarter}
                          onChange={(e) => { setLogbookFilterQuarter(e.target.value); setLogbookCurrentPage(1); }}
                          className="w-full text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer font-semibold"
                        >
                          <option value="1">Quý I (Tháng 1, 2, 3)</option>
                          <option value="2">Quý II (Tháng 4, 5, 6)</option>
                          <option value="3">Quý III (Tháng 7, 8, 9)</option>
                          <option value="4">Quý IV (Tháng 10, 11, 12)</option>
                        </select>
                      </div>
                      <div className="space-y-1.5">
                        <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chọn Năm</label>
                        <select
                          id="logbook-filter-quarter-year-select"
                          value={logbookFilterYear}
                          onChange={(e) => { setLogbookFilterYear(e.target.value); setLogbookCurrentPage(1); }}
                          className="w-full text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer font-semibold"
                        >
                          {Array.from({ length: 5 }, (_, i) => {
                            const y = (new Date().getFullYear() - 2 + i).toString();
                            return <option key={y} value={y}>Năm {y}</option>;
                          })}
                        </select>
                      </div>
                    </div>
                  )}

                  {logbookFilterType === 'year' && (
                    <div className="space-y-1.5 md:col-span-3">
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Chọn Năm báo cáo</label>
                      <div className="flex flex-wrap items-center gap-3">
                        <select
                          id="logbook-filter-year-select"
                          value={logbookFilterYear}
                          onChange={(e) => { setLogbookFilterYear(e.target.value); setLogbookCurrentPage(1); }}
                          className="text-sm px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-850 dark:text-slate-200 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer font-semibold"
                        >
                          {Array.from({ length: 5 }, (_, i) => {
                            const y = (new Date().getFullYear() - 2 + i).toString();
                            return <option key={y} value={y}>Năm {y}</option>;
                          })}
                        </select>
                        <span className="text-xs font-medium text-slate-400 italic">
                          (Đang hiển thị toàn bộ hồ sơ trong năm {logbookFilterYear})
                        </span>
                      </div>
                    </div>
                  )}

                  {logbookFilterType === 'all' && (
                    <div className="space-y-1.5 md:col-span-3 flex items-end pb-1">
                      <span className="text-xs font-medium text-slate-400 italic">
                        (Đang hiển thị toàn bộ dữ liệu lịch sử không giới hạn mốc thời gian)
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Desktop Sổ Theo Dõi administrative table scroll */}
              <div className="bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs text-nowrap">
                    <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                      <tr>
                        <th className="py-3 px-4 w-12 text-center">STT</th>
                        <th className="py-3 px-4">Ngày lập</th>
                        <th className="py-3 px-4">Loại phiếu</th>
                        <th className="py-3 px-4">Số hiệu phiếu</th>
                        <th className="py-3 px-4">Tên công dân, tổ chức</th>
                        <th className="py-3 px-4">Số định danh / CCCD</th>
                        <th className="py-3 px-4">Địa chỉ thường trú/trụ sở</th>
                        <th className="py-3 px-4">Mã số hồ sơ</th>
                        <th className="py-3 px-4">Nội dung thủ tục giải quyết</th>
                        <th className="py-3 px-4">Lý do xử lý</th>
                        <th className="py-3 px-4">Cán bộ hướng dẫn</th>
                        <th className="py-3 px-4 text-center">Trạng thái</th>
                        <th className="py-3 px-4">Ghi chú</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-normal">
                      {paginatedLogbookRecords.map((r, index) => {
                        const globalIndex = (validLogbookPage - 1) * logbookItemsPerPage + index + 1;
                        return (
                          <tr key={r.id || index} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                            <td className="py-3 px-4 text-center font-mono text-slate-400">{globalIndex}</td>
                            <td className="py-3 px-4 font-mono">{formatDateVN(r.createdDate)}</td>
                            <td className="py-3 px-4 font-semibold text-blue-600 dark:text-blue-400">
                              {r.formType === 'mau02' ? 'Bổ sung (Mẫu 02)' : r.formType === 'mau03' ? 'Từ chối (Mẫu 03)' : 'Dừng (Mẫu 05)'}
                            </td>
                            <td className="py-3 px-4 font-mono font-bold text-slate-700 dark:text-slate-350">{r.ticketNo}</td>
                            <td className="py-3 px-4 font-bold text-slate-800 dark:text-slate-200 whitespace-normal break-words max-w-[220px]">{r.citizenName}</td>
                            <td className="py-3 px-4 font-mono text-slate-500">{r.citizenId}</td>
                            <td className="py-3 px-4 text-slate-700 dark:text-slate-300 font-medium whitespace-normal break-words max-w-[280px]">{r.address || '-'}</td>
                            <td className="py-3 px-4 font-mono">
                              <button
                                onClick={() => setSelectedRecordForDetail(r)}
                                className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-bold hover:underline focus:outline-none cursor-pointer text-left"
                                title="Nhấp để xem thông tin chi tiết của từng loại phiếu"
                              >
                                {r.recordId || '(Xem chi tiết)'}
                              </button>
                            </td>
                            <td className="py-3 px-4 max-w-[220px] truncate text-justify" title={r.procedureContent}>
                              {r.procedureContent}
                            </td>
                            <td className="py-3 px-4 max-w-[220px] truncate text-justify" title={r.rejectionReason || r.stopReason}>
                              {r.formType === 'mau02' ? 'Yêu cầu hoàn thiện hồ sơ' : r.rejectionReason || r.stopReason || '-'}
                            </td>
                            <td className="py-3 px-4 font-semibold text-emerald-700 dark:text-emerald-400">
                              {r.officerName} {r.officerPhone ? `(${r.officerPhone})` : ''}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold ${
                                r.status === 'cho_xu_ly' ? 'bg-blue-50 text-blue-700' :
                                r.status === 'da_hoan_thien' ? 'bg-emerald-50 text-emerald-700' :
                                r.status === 'tu_choi' ? 'bg-red-50 text-red-700' :
                                r.status === 'bo_sung' ? 'bg-amber-50 text-amber-700' :
                                'bg-slate-100 text-slate-700'
                              }`}>
                                {getStatusLabel(r.status)}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-400 truncate max-w-[120px]">{r.notes || '-'}</td>
                          </tr>
                        );
                      })}
                      {filteredLogbookRecords.length === 0 && (
                        <tr>
                          <td colSpan={13} className="py-12 text-center text-slate-400 italic">
                            {records.length === 0 
                              ? "Sổ theo dõi hiện chưa ghi nhận hồ sơ nào." 
                              : "Không tìm thấy hồ sơ nào phù hợp với bộ lọc báo cáo đã chọn."}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Logbook Pagination Bar */}
                <div className="p-4 bg-slate-50/80 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div className="text-slate-500 dark:text-slate-400 font-medium">
                    Hiển thị <span className="font-bold text-slate-700 dark:text-slate-200">{filteredLogbookRecords.length === 0 ? 0 : (validLogbookPage - 1) * logbookItemsPerPage + 1}</span> - <span className="font-bold text-slate-700 dark:text-slate-200">{Math.min(validLogbookPage * logbookItemsPerPage, filteredLogbookRecords.length)}</span> trên tổng số <span className="font-bold text-blue-600 dark:text-blue-400">{filteredLogbookRecords.length}</span> hồ sơ (20 hồ sơ/trang)
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      disabled={validLogbookPage <= 1}
                      onClick={() => setLogbookCurrentPage(prev => Math.max(1, prev - 1))}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer shadow-2xs"
                      title="Chuyển về trang trước"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Trang trước</span>
                    </button>

                    <div className="px-3 py-1.5 font-bold font-mono text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-2xs">
                      Trang {validLogbookPage} / {logbookTotalPages}
                    </div>

                    <button
                      disabled={validLogbookPage >= logbookTotalPages}
                      onClick={() => setLogbookCurrentPage(prev => Math.min(logbookTotalPages, prev + 1))}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer shadow-2xs"
                      title="Chuyển sang trang sau"
                    >
                      <span>Trang sau</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}


          {/* --- VIEW 5: EXCEL/CSV IMPORT GATEWAY --- */}
          {currentView === 'import' && (
            <div className="space-y-6">
              <div className="bg-white dark:bg-slate-850 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 className="font-bold text-slate-800 dark:text-slate-200">Nhập khẩu & Đồng bộ tệp Dữ liệu</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Cập nhật hàng loạt danh sách, tự động ghi đè lịch sử đồng bộ nếu trùng khớp số hiệu dockets mà không tạo hồ sơ ảo trùng lặp.
                </p>
              </div>

              <ExcelImport 
                existingRecords={records} 
                currentUser={currentUser.username}
                onImportComplete={(imports, syncs) => {
                  alert(`Nhập khẩu thành công ${imports} hồ sơ mới và đồng bộ thành công ${syncs} hồ sơ cũ!`);
                  fetchData();
                  setCurrentView('records');
                }}
              />
            </div>
          )}


          {/* --- VIEW 6: TEMPLATES CONFIGURE MANAGER --- */}
          {currentView === 'templates' && (
            <TemplateManager 
              templates={templates}
              onUploadTemplate={handleUploadTemplate}
              onDeleteTemplate={handleDeleteTemplate}
            />
          )}


          {/* --- VIEW 7: ADMIN METADATA MANAGER --- */}
          {currentView === 'admin' && (
            <AdminPanel 
              users={users}
              procedures={procedures}
              officers={officers}
              reasons={reasons}
              onAddUser={handleAddUser}
              onDeleteUser={handleDeleteUser}
              onUpdateUser={handleUpdateUser}
              onAddProcedure={handleAddProcedure}
              onDeleteProcedure={handleDeleteProcedure}
              onUpdateProcedure={handleUpdateProcedure}
              onAddOfficer={handleAddOfficer}
              onDeleteOfficer={handleDeleteOfficer}
              onUpdateOfficer={handleUpdateOfficer}
              onAddReason={handleAddReason}
              onDeleteReason={handleDeleteReason}
              onUpdateReason={handleUpdateReason}
              currentUser={currentUser}
            />
          )}


          {/* --- VIEW 8: AUDIT TRAIL LOGS PANEL --- */}
          {currentView === 'audits' && (
            <AuditLogs 
              logs={auditLogs} 
              currentUserRole={currentUser.role}
              onClearLogs={async () => {
                // Set to default blank log list in server
                await fetch('/api/audit-logs/log-action', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ username: currentUser.username, action: 'Xóa', details: 'Làm trống toàn bộ hệ thống Audit Log' })
                });
                fetchData();
              }}
            />
          )}

          {/* --- VIEW 9: DAILY REPORT VIEW --- */}
          {currentView === 'daily_report' && (
            <DailyReportView
              officers={officers}
              currentUser={currentUser as any}
              dailyReports={dailyReports}
              records={records}
              reportConfig={reportConfig}
              onSaveReport={handleSaveDailyReport}
              onSaveConfig={handleSaveReportConfig}
              onDeleteReport={handleDeleteDailyReport}
            />
          )}

          {/* --- VIEW 10: OFFICERS MANAGEMENT VIEW --- */}
          {currentView === 'officers_mgmt' && (
            <OfficerManagementView
              officers={officers}
              onAddOfficer={handleAddOfficer}
              onDeleteOfficer={handleDeleteOfficer}
              onUpdateOfficer={handleUpdateOfficer}
              currentUser={currentUser}
            />
          )}

          {/* --- VIEW 11: DATA PERSISTENCE & BACKUP VIEW --- */}
          {currentView === 'backup_mgmt' && (
            <DataBackupView
              currentUser={currentUser}
              onRefreshAllData={fetchData}
            />
          )}

          {/* Record Details Modal */}
          {selectedRecordForDetail && (
            <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-xs p-4 overflow-y-auto">
              <div className="bg-white dark:bg-slate-850 rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-8">
                {/* Header */}
                <div className="px-6 py-4 bg-[#00387B] text-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-200" />
                    <div>
                      <h3 className="font-bold text-sm">Chi tiết biểu mẫu: {selectedRecordForDetail.ticketNo}</h3>
                      <p className="text-[10px] text-blue-200 uppercase tracking-wider font-semibold">
                        {getFormTypeLabel(selectedRecordForDetail.formType)}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedRecordForDetail(null)}
                    className="p-1 text-blue-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-xs md:text-sm">
                  {/* Status & Date bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Trạng thái:</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        selectedRecordForDetail.status === 'cho_xu_ly' ? 'bg-blue-50 text-blue-600' :
                        selectedRecordForDetail.status === 'da_hoan_thien' ? 'bg-emerald-50 text-emerald-600' :
                        selectedRecordForDetail.status === 'tu_choi' ? 'bg-red-50 text-red-600' :
                        selectedRecordForDetail.status === 'bo_sung' ? 'bg-amber-50 text-amber-600' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {getStatusLabel(selectedRecordForDetail.status)}
                      </span>
                    </div>
                    <div className="text-slate-400 text-xs font-bold">
                      Ngày lập: <span className="text-slate-750 dark:text-slate-300 font-semibold">{formatDateVN(selectedRecordForDetail.createdDate)}</span>
                    </div>
                  </div>

                  {/* Citizen & Record Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-bold text-[#00387B] dark:text-blue-400 uppercase tracking-wide text-[11px] mb-2">Thông tin công dân / Tổ chức</h4>
                      <div className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-150 dark:border-slate-800 text-xs">
                        <p className="whitespace-normal break-words"><span className="text-slate-400 font-semibold">Tên công dân, tổ chức:</span> <strong className="text-slate-850 dark:text-slate-100">{selectedRecordForDetail.citizenName}</strong></p>
                        <p><span className="text-slate-400 font-semibold">Số CCCD / Định danh:</span> <strong className="font-mono text-slate-800 dark:text-slate-200">{selectedRecordForDetail.citizenId}</strong></p>
                        <p className="whitespace-normal break-words" title={selectedRecordForDetail.address}><span className="text-slate-400 font-semibold">Địa chỉ thường trú/trụ sở:</span> <span className="text-slate-750 dark:text-slate-300">{selectedRecordForDetail.address || 'N/A'}</span></p>
                        <p><span className="text-slate-400 font-semibold">Điện thoại:</span> <span className="font-semibold text-slate-750 dark:text-slate-300">{selectedRecordForDetail.phone || 'N/A'}</span></p>
                        <p><span className="text-slate-400 font-semibold">Email:</span> <span className="text-slate-750 dark:text-slate-300">{selectedRecordForDetail.email || 'N/A'}</span></p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-[#00387B] dark:text-blue-400 uppercase tracking-wide text-[11px] mb-2">Thông tin hồ sơ hành chính</h4>
                      <div className="space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-150 dark:border-slate-800 text-xs">
                        <p><span className="text-slate-400 font-semibold">Mã số hồ sơ:</span> <strong className="font-mono text-blue-600 dark:text-blue-400">{selectedRecordForDetail.recordId || 'Chưa đăng ký'}</strong></p>
                        <p><span className="text-slate-400 font-semibold">Cán bộ thụ lý:</span> <span className="font-semibold text-slate-750 dark:text-slate-300">{selectedRecordForDetail.officerName}</span></p>
                        <p><span className="text-slate-400 font-semibold">SĐT hướng dẫn:</span> <span className="font-semibold text-slate-750 dark:text-slate-300">{selectedRecordForDetail.officerPhone || 'N/A'}</span></p>
                        <p className="line-clamp-2" title={selectedRecordForDetail.procedureContent}><span className="text-slate-400 font-semibold">Thủ tục yêu cầu:</span> <span className="italic text-slate-750 dark:text-slate-300">"{selectedRecordForDetail.procedureContent}"</span></p>
                        <p className="truncate" title={selectedRecordForDetail.notes}><span className="text-slate-400 font-semibold">Ghi chú cán bộ:</span> <span className="text-slate-500 italic">{selectedRecordForDetail.notes || '-'}</span></p>
                      </div>
                    </div>
                  </div>

                  {/* Form specific reasons & paper lists */}
                  {selectedRecordForDetail.formType === 'mau02' && (
                    <div className="space-y-3">
                      <h4 className="font-bold text-amber-600 uppercase tracking-wide text-[11px]">Danh sách giấy tờ cần bổ sung, hoàn thiện</h4>
                      <div className="bg-amber-50/20 dark:bg-amber-950/10 border border-amber-500/20 p-4 rounded-xl space-y-2">
                        {selectedRecordForDetail.papersList && selectedRecordForDetail.papersList.length > 0 ? (
                          selectedRecordForDetail.papersList.map((paper, idx) => (
                            <div key={idx} className="flex items-start gap-2 text-xs">
                              <span className="flex items-center justify-center w-5 h-5 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 text-[10px] font-bold shrink-0 mt-0.5">{idx + 1}</span>
                              <span className="font-semibold text-slate-800 dark:text-slate-200">{paper}</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-slate-400 italic">Không yêu cầu danh mục giấy tờ cụ thể.</p>
                        )}
                      </div>
                    </div>
                  )}

                  {(selectedRecordForDetail.formType === 'mau02' || selectedRecordForDetail.formType === 'mau03') && selectedRecordForDetail.rejectionReason && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-red-600 dark:text-red-400 uppercase tracking-wide text-[11px]">
                        {selectedRecordForDetail.formType === 'mau02' ? 'Chi tiết yêu cầu / Lý do' : 'Lý do từ chối cụ thể'}
                      </h4>
                      <div className="bg-red-50/20 dark:bg-red-950/10 border-l-4 border-red-500 p-4 rounded-r-xl text-justify text-slate-700 dark:text-slate-300 font-medium italic text-xs">
                        "{selectedRecordForDetail.rejectionReason}"
                      </div>
                    </div>
                  )}

                  {selectedRecordForDetail.formType === 'mau05' && (
                    <div className="space-y-3">
                      <h4 className="font-bold text-slate-600 dark:text-slate-350 uppercase tracking-wide text-[11px]">Chi tiết dừng hồ sơ</h4>
                      <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl space-y-2 border border-slate-150 dark:border-slate-700 text-xs">
                        <p><span className="text-slate-400 font-semibold">Lãnh đạo ký duyệt:</span> <strong className="text-slate-850 dark:text-slate-150">{selectedRecordForDetail.leaderName || 'N/A'}</strong></p>
                        <p><span className="text-slate-400 font-semibold">Ngày công dân gửi đơn đề nghị:</span> <strong className="text-slate-800 dark:text-slate-200">{selectedRecordForDetail.stopDateRequest ? formatDateVN(selectedRecordForDetail.stopDateRequest) : 'N/A'}</strong></p>
                        <p className="text-justify font-medium italic text-slate-700 dark:text-slate-300"><span className="text-slate-400 font-semibold not-italic">Lý do dừng giải quyết:</span> "{selectedRecordForDetail.stopReason || 'Chưa rõ lý do'}"</p>
                      </div>
                    </div>
                  )}

                  {/* History Logs */}
                  {selectedRecordForDetail.history && selectedRecordForDetail.history.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-slate-400 uppercase tracking-wide text-[11px] flex items-center gap-1.5">
                        <History className="w-4 h-4 text-blue-500" />
                        Lịch sử cập nhật của phiếu
                      </h4>
                      <div className="space-y-2 bg-slate-50 dark:bg-slate-800/30 p-3 rounded-xl border border-slate-150 dark:border-slate-800 max-h-[100px] overflow-y-auto">
                        {selectedRecordForDetail.history.map((h, i) => (
                          <div key={i} className="text-[11px] border-b border-dashed border-slate-100 dark:border-slate-700 pb-1.5 flex justify-between gap-4">
                            <div>
                              <p className="font-bold text-slate-700 dark:text-slate-300">{h.action} bởi {h.user}</p>
                              <p className="text-slate-400 mt-0.5">{h.details}</p>
                            </div>
                            <span className="text-[10px] text-slate-400 shrink-0 font-mono">{new Date(h.timestamp).toLocaleString('vi-VN')}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Buttons */}
                <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-100 dark:border-slate-700 flex flex-wrap justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      loadRecordForEditing(selectedRecordForDetail, true);
                      setSelectedRecordForDetail(null);
                    }}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    In / Xuất PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleExportWordRecord(selectedRecordForDetail);
                    }}
                    className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-[#00387B] dark:bg-blue-950/20 dark:text-blue-300 dark:hover:bg-blue-950/40 border border-blue-100 dark:border-blue-900 rounded-lg font-semibold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Xuất tệp Word
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      loadRecordForEditing(selectedRecordForDetail, false);
                      setSelectedRecordForDetail(null);
                    }}
                    className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 font-semibold rounded-lg text-xs hover:bg-slate-50 dark:hover:bg-slate-650 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    Biên tập
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedRecordForDetail(null)}
                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-slate-200 font-bold rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
