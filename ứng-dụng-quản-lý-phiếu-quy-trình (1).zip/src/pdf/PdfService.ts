export { PdfService, prefetchFonts } from '../services/PdfService';
