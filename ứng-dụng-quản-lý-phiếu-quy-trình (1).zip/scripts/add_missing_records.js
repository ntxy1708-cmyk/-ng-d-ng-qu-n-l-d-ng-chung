import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'assets', 'db.json');
const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

// Check if 110 already exists
const has110 = db.records.some(r => r.field === 'Hộ tịch' && parseInt(r.ticketNo) === 110);
const has179 = db.records.some(r => r.field === 'Hộ tịch' && parseInt(r.ticketNo) === 179);

if (!has110) {
  const rec110 = {
    id: 'rec_110',
    formType: 'mau03',
    ticketNo: '110',
    createdDate: '2026-04-10',
    citizenName: 'NGUYỄN VĂN THANH',
    citizenId: '',
    address: '15/28 Phùng Văn Cung, Phường Cầu Kiệu',
    phone: '',
    email: '',
    recordId: 'H29.211-260410-150005',
    procedureContent: 'Giải quyết hồ sơ Hộ tịch',
    rejectionReason: 'Trùng hồ sơ; bổ sung giấy tờ xác nhận tình trạng hôn nhân',
    officerName: 'Lâm Thị Hồng Tuyến',
    status: 'tu_choi',
    notes: 'Dữ liệu từ danh sách sổ quản lý hồ sơ Trung tâm Phục vụ hành chính công Phường Cầu Kiệu',
    history: [
      {
        timestamp: '2026-04-10T08:00:00Z',
        action: 'Khởi tạo',
        user: 'admin@caukieu',
        details: 'Lập phiếu từ chối giải quyết hồ sơ số 110'
      }
    ],
    field: 'Hộ tịch'
  };
  db.records.push(rec110);
}

if (!has179) {
  const rec179 = {
    id: 'rec_179',
    formType: 'mau03',
    ticketNo: '179',
    createdDate: '2026-05-02',
    citizenName: 'TRẦN VĂN NAM',
    citizenId: '',
    address: '88/12 Nguyễn Công Hoan, Phường Cầu Kiệu',
    phone: '',
    email: '',
    recordId: 'H29.211-260502-150012',
    procedureContent: 'Giải quyết hồ sơ Hộ tịch',
    rejectionReason: 'Bổ sung giấy tờ có giá trị chứng minh thông tin cư trú theo quy định',
    officerName: 'Lâm Thị Hồng Tuyến',
    status: 'tu_choi',
    notes: 'Dữ liệu từ danh sách sổ quản lý hồ sơ Trung tâm Phục vụ hành chính công Phường Cầu Kiệu',
    history: [
      {
        timestamp: '2026-05-02T08:00:00Z',
        action: 'Khởi tạo',
        user: 'admin@caukieu',
        details: 'Lập phiếu từ chối giải quyết hồ sơ số 179'
      }
    ],
    field: 'Hộ tịch'
  };
  db.records.push(rec179);
}

// Re-sort records by field then ticketNo
db.records.sort((a, b) => {
  if (a.field !== b.field) {
    if (a.field === 'Hộ tịch') return -1;
    return 1;
  }
  return parseInt(a.ticketNo) - parseInt(b.ticketNo);
});

// Re-index IDs rec_1, rec_2, ...
db.records = db.records.map((r, idx) => ({
  ...r,
  id: `rec_${idx + 1}`
}));

fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');

console.log(`Total records now: ${db.records.length}`);
