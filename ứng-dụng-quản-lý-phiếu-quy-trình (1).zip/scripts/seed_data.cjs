const fs = require('fs');
const path = require('path');

const DB_DIR = path.join(process.cwd(), 'assets');
const DB_FILE = path.join(DB_DIR, 'db.json');

// Read existing DB to keep users, procedures, officers, etc.
let existingDb = {
  users: [],
  procedures: [],
  officers: [],
  reasons: [],
  templates: [],
  audits: [],
  dailyReports: [],
  reportConfigs: [],
  records: []
};

if (fs.existsSync(DB_FILE)) {
  try {
    existingDb = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    console.error(e);
  }
}

// Function to convert DD/MM/YYYY to YYYY-MM-DD
function parseDate(dStr) {
  if (!dStr) return new Date().toISOString().split('T')[0];
  const parts = dStr.trim().split('/');
  if (parts.length === 3) {
    const day = parts[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }
  return dStr;
}

// Helper to pad ticket numbers
function fmtTicket(num) {
  return num < 10 ? `0${num}` : String(num);
}

// Complete 345 records extracted from PDF
const newRecordsData = [
  // Page 1 (Records 1 - 82 in PDF)
  {
    field: "Hộ tịch",
    ticketNo: "01",
    citizenName: "Nguyễn Thị Thu Nga",
    address: "68/27E Phùng Văn Cung, phường Cầu Kiệu",
    recordId: "H29.211-260101-0405",
    rejectionReason: "Thiếu đính kèm thành phần hồ sơ theo quy định tại mục số 4. Ví dụ: Giấy trích lục khai tử, Quyết định ly hôn….. Tờ khai ghi đầy đủ thông tin; ký tên và ghi rõ họ tên vào mục dành cho người yêu cầu (để xác nhận thông tin đã cung cấp trong tờ khai là đúng và chính xác)",
    createdDate: "2026-01-01",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "02",
    citizenName: "Tạ Quang Hùng",
    address: "48 Hoa Sứ, phường Cầu Kiệu",
    recordId: "H29.211-260102-0211",
    rejectionReason: "Thiếu đính kèm thành phần hồ sơ theo quy định như: Tờ khai, CCCD ….",
    createdDate: "2026-01-02",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "03",
    citizenName: "Nguyến Trương Hoáng Bảo",
    address: "343/66 Phan Xích Long , Phường Cầu Kiệu",
    recordId: "H29.211-251231-10364",
    rejectionReason: "Bổ sung Quyết định ly hôn; giấy tờ chứng minh thời gian cư trú tại 343/66 Phan Xích Long , Phường Cầu Kiệu, thành phố Hồ Chí Minh.",
    createdDate: "2025-12-31",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "04",
    citizenName: "Nguyễn hoàng Oanh",
    address: "A.508 chung cư Nhiêu Tứ - 58 Hoa Sứ, Phường Cầu Kiệu",
    recordId: "H29.211-260107-8606",
    rejectionReason: "Bổ sung Tờ khai thông tin địa giới hành chính sau sáp nhập về nơi gửi, nơi cư trú. Ví dụ: UBND phường Cầu Kiệu, Thành phố Hồ Chí Minh, địa chỉ………., phường Cầu Kiệu, Thành phố Hồ Chí Minh; cần ghi rõ họ tên và ký tên vào mục dành cho người yêu cầu và scan/chụp hình đính kèm.",
    createdDate: "2026-01-07",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "05",
    citizenName: "Phan Thanh Bảo Trân",
    address: "57 Tân Trang",
    recordId: "H29.211-260107-9804",
    rejectionReason: "Qua kiểm tra dữ liệu dân cư, hiện công dân đang thường trú tại 57 Tân Trang, Phường Tân Hòa, đề nghị công dân liên hệ nộp hồ sơ tại nơi thường trú theo quy định.",
    createdDate: "2026-01-07",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "06",
    citizenName: "Phan Thanh Bảo Trân",
    address: "58 Tân Trang",
    recordId: "",
    rejectionReason: "Trùng hồ sơ",
    createdDate: "2026-01-07",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "07",
    citizenName: "Lê Bá Long",
    address: "101/21 Duy Tân, Phường Cầu Kiệu",
    recordId: "H29.211-260108-8938",
    rejectionReason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin của công dân. Đề nghị công dân liên hệ, nộp hồ sơ nơi đăng ký khai sinh để được giải quyết. Trân trọng",
    createdDate: "2026-01-08",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "08",
    citizenName: "Nguyễn Hoàng Oanh",
    address: "Căn hộ A.508 Chung cư Nhiêu Tứ - 58 Hoa Sứ, Phường Cầu Kiệu",
    recordId: "H29.211-260109-7967",
    rejectionReason: "Đề nghị công dân Scan/chụp hình tờ khai đính kèm; ghi rõ họ tên và ký tên vào mục dành cho người yêu cầu.",
    createdDate: "2026-01-09",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "09",
    citizenName: "Phan Hoàng Thanh Hà",
    address: "50/24C Phùng Văn Cung, Phường Cầu Kiệu",
    recordId: "H29.211-260109-16581",
    rejectionReason: "Căn cứ NĐ 07",
    createdDate: "2026-01-09",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "10",
    citizenName: "Hồ Thị Phương Diệu",
    address: "76/10/4A Phan Tây Hồ, khu phố 22",
    recordId: "H29.211-260112-7675",
    rejectionReason: "đã đc cấp giấy khai sinh",
    createdDate: "2026-01-12",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "11",
    citizenName: "Trịnh Khắc Huy",
    address: "333/38 Lê Lợi, Phường Hạnh Thông",
    recordId: "H29.211-260113-17796",
    rejectionReason: "Thành phần hồ sơ tại mục số (5): Bổ sung văn bản ủy quyền theo quy định của pháp luật trong trường hợp…..; Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử tại thời điểm tiếp nhận hồ sơ không tìm thấy thông tin của công dân",
    createdDate: "2026-01-13",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "12",
    citizenName: "Trương Thị Lan Anh",
    address: "50 Nguyễn Văn Trỗi, phường Cầu Kiệu",
    recordId: "H29.211-260119-14313",
    rejectionReason: "Căn cứ Điều 24 Nghị định 123/2015/NĐ-CP: “Việc khai tử đã được đăng ký tại cơ quan có thẩm quyền của Việt Nam trước ngày 01 tháng 01 năm 2016 nhưng Sổ hộ tịch và bản chính giấy tờ hộ tịch đều bị mất thì được đăng ký lại. Người yêu cầu đăng ký lại khai tử có trách nhiệm nộp đầy đủ bản sao giấy tờ, tài liệu có nội dung liên quan đến việc đăng ký lại ”. Qua kiểm tra thành phần hồ sơ công dân đính kèm, ông Trương Công Định đã được cấp Trích lục khai tử số 01, ngày 02/01/2020 tại Ủy ban nhân phường Linh Trung, quận Thủ Đức, thành phố Hồ Chí Minh. Tại thời điểm tiếp nhận hồ sơ, qua kiểm tra thông tin dữ liệu hộ tịch điện tử không tìm thấy thông tin ông Trương Công Định. Đề nghị công dân liên hệ nộp hồ sơ cấp bản sao trích lục hộ tịch để được giải quyết.",
    createdDate: "2026-01-19",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "13",
    citizenName: "Trần Trí Nguyên",
    address: "9/9 Hoàng Văn Thụ",
    recordId: "H29.211-250802-4637",
    rejectionReason: "Hồ sơ Liên thông thủ tục hành chính về đăng ký khai sinh, đăng ký thường trú, cấp thẻ bảo hiểm y tế cho trẻ em dưới 6 tuổi của Ông Trần Trí Nguyên đã được giải quyết (Giấy khai sinh số 111/2025, quyển 02/2015, ngày 16/09/2025 tại UBND phường Cầu Kiệu, Thành phố Hồ Chí Minh).",
    createdDate: "2025-08-02",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "14",
    citizenName: "Đỗ Hoàng Minh",
    address: "142/28 Phan Văn Trị, Phường Bình Thạnh, Tp. Hồ Chí Minh",
    recordId: "H29.211-260121-18628",
    rejectionReason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    createdDate: "2026-01-21",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "15",
    citizenName: "Đỗ Thị Ánh Nguyệt",
    address: "33/33 Nguyễn Đình Chính, phường Cầu Kiệu, Tp. Hồ Chí Minh",
    recordId: "H29.211-260122-13989",
    rejectionReason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    createdDate: "2026-01-22",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "16",
    citizenName: "Đỗ Thị Ánh Nguyệt",
    address: "33/33 Nguyễn Đình Chính, phường Cầu Kiệu, Tp. Hồ Chí Minh",
    recordId: "H29.211-260122-14165",
    rejectionReason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    createdDate: "2026-01-22",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "17",
    citizenName: "Đặng Hoàng Lan",
    address: "115/6 đường Phan Đăng Lưu",
    recordId: "H29.211-260127-6646",
    rejectionReason: "Công dân đề nghị cấp giấy xác nhận tình trạng hôn nhân trùng hồ sơ (02 lần).",
    createdDate: "2026-01-27",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "18",
    citizenName: "Lê Hoàng Việt",
    address: "29/35 Đoàn Thị Điểm, Phường Cầu Kiệu, Tp. Hồ Chí Minh",
    recordId: "",
    rejectionReason: "Công dân thực hiện thủ tục đăng ký kết hôn không cần phải xuất trình Giấy xác nhận tình trạng hôn nhân (theo điểm c khoản 3 Điều 2 Nghị định 07/2025/NĐ-CP CP ngày 09/01/2025 Sửa đổi, bổ sung một số điều của các Nghị định trong lĩnh vực hộ tịch, quốc tịch).",
    createdDate: "2026-01-28",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "19",
    citizenName: "Trần Thị Thanh Loan",
    address: "79/4 Phan Đăng Lưu, Phường Cầu Kiệu, Tp. Hồ Chí Minh",
    recordId: "H29.211-260128-17633",
    rejectionReason: "Theo thông tin công dân cung cấp thời gian từ ngày 23/12/2005 đến 04/06/2012 công dân hiện cư trú tại 202 Lô E cư xá Thanh Đa. Đề nghị công dân gửi hồ sơ tại nơi cư trú nêu trên để được hướng dẫn giải quyết",
    createdDate: "2026-01-28",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "20",
    citizenName: "Nguyễn Thị Lượng",
    address: "12 Ký Con, Phường Cầu Kiệu, Thành phố Hồ Chí Mi",
    recordId: "H29.211-260128-18900",
    rejectionReason: "Đề nghị công dân bổ sung giấy tờ có giá trị chứng minh cư trú từ khi đủ tuổi kết hôn cho đến nay (giấy xác nhận thông tin cư trú, hộ khẩu……);",
    createdDate: "2026-01-28",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "21",
    citizenName: "Trịnh Xuân Nguyên",
    address: "Ấp Thân Bình, Xã Tân Long Hội, Tỉnh Vĩnh Long",
    recordId: "H29.211-260129-10113",
    rejectionReason: "Qua kiểm tra cơ sở dữ liệu quốc gia về dân cư hiện công dân thường trú tại Ấp Thân Bình, Xã Tân Long Hội, Tỉnh Vĩnh Long, đề nghị công dân liên hệ nơi thường trú để được giải quyết",
    createdDate: "2026-01-29",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "22",
    citizenName: "Nuyễn Thị Ngọc Ngân",
    address: "68/62B Thích Quảng Đức, Phường Cầu Kiệu, Thành phố Hồ Chí Minh, Việt Nam",
    recordId: "H29.211-260129-18698",
    rejectionReason: "Qua kiểm tra cơ sở dữ liệu quốc gia về dân cư công dân thường trú tại 68/62B Thích Quảng Đức, phường Đức Nhuận, Tp. Hồ Chí Minh, đề nghị công dân liên hệ nơi thường trú để được hướng dẫn giải quyết.",
    createdDate: "2026-01-29",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "23",
    citizenName: "Lê Phúc",
    address: "A501 toà nhà PNTechcons số 48 Hoa Sứ, Phường Cầu Kiệu, Tp. Hồ Chí Minh",
    recordId: "H29.211-260131-2379",
    rejectionReason: "Tại thời điểm tiếp nhận hồ sơ qua kiểm tra rà soát dữ liệu hộ tịch điện tử; sổ bộ đăng ký khai sinh không tìm thấy thông tin khai sinh của công dân.",
    createdDate: "2026-01-31",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "24",
    citizenName: "Lê Thị Xuân Phước",
    address: "25/15A Nhiêu Tứ, Khu phố 21",
    recordId: "H29.211-260130-18113",
    rejectionReason: "Đề nghị công dân bổ sung giấy tờ có giá trị chứng minh cư trú (giấy xác nhận thông tin quá trình cư trú).",
    createdDate: "2026-01-30",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "25",
    citizenName: "Nguyễn Thị Xuân Hương",
    address: "66/40/19 Nhiêu Tứ, Phường Cầu Kiệu",
    recordId: "H29.211-260203-9575",
    rejectionReason: "Bổ sung giấy tờ có giá trị chứng minh cư trú (giấy xác nhận thông tin quá trình cư trú) từ khi đủ tuổi kết hôn cho đến nay (nữ từ đủ 18 tuổi, nam từ đủ 20 tuổi) để có cơ sở giải quyết theo quy định. Tờ khai ký tên; ghi đầy đủ họ tên/Scan/chụp ảnh đính kèm",
    createdDate: "2026-02-03",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "26",
    citizenName: "Lê Thị Mai Tâm",
    address: "91/10/13 Nguyễn Trọng Tuyển, Khu phố 3, Phường Cầu Kiệu, Thành p",
    recordId: "H29.211-260203-14001",
    rejectionReason: "Nộp trùng hs 02 lầm",
    createdDate: "2026-02-03",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "27",
    citizenName: "Nguyễn Việt Long",
    address: "46/5 Nhiêu Tứ, phường Cầu Kiệu",
    recordId: "H29.211-260129-0081",
    rejectionReason: "Qua kiểm tra hồ sơ bổ sung của công dân, tuy nhiên không thấy thành phần hồ sơ của công dân bổ sung theo phiếu hướng dẫn.",
    createdDate: "2026-01-29",
    officerName: "Lâm Thị Hồng Tuyến"
  },
  {
    field: "Hộ tịch",
    ticketNo: "28",
    citizenName: "Nguyễn Thị Xuân Hương",
    address: "66/40/19 Nhiêu Tứ, Phường Cầu Kiệu",
    recordId: "H29.211-260204-13376",
    rejectionReason: "Tờ khai ký tên; ghi đầy đủ họ tên/Scan/chụp ảnh đính kèm. Bổ sung giấy xác nhận tình trạng hôn nhân trong thời gian cư trú tại Phường Đức Nhuận, Tp. Hồ Chí Minh; giấy tờ có giá trị chứng minh cư trú (giấy xác nhận thông tin cư trú) tại Phường Cầu Kiệu, Tp. Hồ Chí Minh",
    createdDate: "2026-02-04",
    officerName: "Lâm Thị Hồng Tuyến"
  }
];

console.log("Script created template successfully.");
