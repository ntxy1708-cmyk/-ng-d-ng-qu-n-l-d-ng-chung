const fs = require('fs');
const path = require('path');

const fileContent = fs.readFileSync(path.join(__dirname, 'raw_ocr_pages.txt'), 'utf8');

const lines = fileContent.split(/\r?\n/);
const rawBlocks = [];
let currentBlock = null;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const match = line.match(/^(\d+)\s+(\d+)\s+(Hộ tịch|Tư pháp|Đất đai\s*-\s*Tài nguyên Môi trường)\s+(.*)$/);
  if (match) {
    if (currentBlock) {
      rawBlocks.push(currentBlock);
    }
    currentBlock = {
      index: parseInt(match[1]),
      subIndex: parseInt(match[2]),
      field: match[3].trim(),
      firstLineRest: match[4].trim(),
      lines: []
    };
  } else if (currentBlock) {
    if (line.trim().length > 0) {
      currentBlock.lines.push(line.trim());
    }
  }
}
if (currentBlock) {
  rawBlocks.push(currentBlock);
}

const knownOfficers = [
  'Lâm Thị Hồng Tuyến',
  'Nguyễn Tiến Đạt',
  'Dương Thị Hồng Ngọc',
  'Nguyễn Thị Xuân Ý',
  'Nguyễn Thanh Tùng',
  'Nguyễn Văn Hữu',
  'Đoàn Ngọc Diễm',
  'Nguyễn Thị Ngọc Hiếu'
];

function formatDateISO(dateStr) {
  if (!dateStr) return '2026-01-01';
  const parts = dateStr.split('/');
  if (parts.length === 3) {
    const day = parts[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }
  return '2026-01-01';
}

function parseBlock(block) {
  let allLines = [block.firstLineRest, ...block.lines];

  let fullText = allLines.join('\n');
  fullText = fullText.replace(/(H29\.211-[\d\-]*)\n([\d\-]+)/g, '$1$2');
  fullText = fullText.replace(/(H29\.211-)\n([\d\-]+)/g, '$1$2');
  fullText = fullText.replace(/(G22\.99\.08-[\d\-]*)\n([\d\-]+)/g, '$1$2');

  let recordId = '';
  const recIdMatch = fullText.match(/(H29\.211-[\d\-]+(?:\s*\([^\)]+\))?)/);
  if (recIdMatch) {
    recordId = recIdMatch[1].trim();
  }

  let officerName = 'Lâm Thị Hồng Tuyến';
  for (const off of knownOfficers) {
    if (fullText.includes(off)) {
      officerName = off;
      break;
    }
  }

  let formTypeStr = 'Phiếu từ chối';
  if (fullText.includes('Phiếu bổ sung')) {
    formTypeStr = 'Phiếu bổ sung';
  }

  let createdDateStr = '';
  const dates = [...fullText.matchAll(/(\d{2}\/\d{2}\/\d{4})/g)];
  if (dates.length > 0) {
    createdDateStr = dates[dates.length - 1][1];
  }

  let headerText = '';
  let reasonLines = [];

  // Check where recordId appears in block.firstLineRest or block.lines
  if (recordId && block.firstLineRest.includes(recordId)) {
    const pos = block.firstLineRest.indexOf(recordId);
    headerText = block.firstLineRest.substring(0, pos).trim();
    const rest = block.firstLineRest.substring(pos + recordId.length).trim();
    if (rest) reasonLines.push(rest);
    reasonLines.push(...block.lines);
  } else {
    headerText = block.firstLineRest;
    let lineIdx = 0;
    while (lineIdx < block.lines.length) {
      const nextLine = block.lines[lineIdx];
      const isReasonStart = nextLine.match(/^(Qua|Căn cứ|Theo|Đề nghị|Trường hợp|Thiếu|Thực hiện|Nộp|Hồ sơ|Không|Tài khoản|Bổ sung|Làm lại|Cải chính|Công dân|Ông|Bà|Sổ|Việc|Cơ quan|Hồ sơ mã|Tờ khai)/i);
      const hasAddressPatterns = nextLine.match(/(?:\d+|Ấp|ẤP|Thôn|THÔN|Khóm|KP|Khu|SỐ|Số|Căn|Phòng|CC|c\/c|OG|CH|TDP|NKS|P\d+|A\d+|B\d+|C\d+|D\d+|TB1-)/i);

      if (!isReasonStart && hasAddressPatterns && !headerText.match(/\d{2,}/)) {
        headerText += ' ' + nextLine;
        lineIdx++;
      } else {
        break;
      }
    }
    reasonLines.push(...block.lines.slice(lineIdx));
  }

  if (recordId) {
    headerText = headerText.replace(recordId, '').trim();
    headerText = headerText.replace(/H29\.211-[\d\-]*/g, '').trim();
  }

  const addrRegex = /(?:^|\s+)(?:\d+[\d\/\-A-Za-z\.]*|A\.\d+|A\d+|B\d+|C\d+|D\d+|F\d+|P\d+|OG|TDP|K204|601|Căn\s+hộ|Số\s+nhà|Số|SỐ|Thôn|THÔN|Ấp|ẤP|NKS|CH|c\/c|TB1[^\s]*|G002|CH\s+F[^\s]*)(?=\s+|[,\/\.\-]|$)/i;

  let citizenName = headerText;
  let address = '';

  const matchAddr = headerText.match(addrRegex);

  if (matchAddr) {
    const idx = headerText.indexOf(matchAddr[0]);
    if (idx > 0) {
      citizenName = headerText.substring(0, idx).trim();
      address = headerText.substring(idx).trim();
    } else if (idx === 0) {
      citizenName = 'Công dân';
      address = headerText;
    }
  }

  if (!address && citizenName) {
    const numMatch = citizenName.match(/\s+(\d+[\d\/\-A-Za-z\.]*|\d+\,.*)$/);
    if (numMatch) {
      const idx = citizenName.indexOf(numMatch[0]);
      address = citizenName.substring(idx).trim();
      citizenName = citizenName.substring(0, idx).trim();
    }
  }

  citizenName = citizenName.replace(/[\d\.\,\-]+$/, '').trim();

  let reasonText = reasonLines.join(' ').replace(/\s+/g, ' ').trim();

  if (recordId) {
    reasonText = reasonText.replace(recordId, '').trim();
  }
  reasonText = reasonText.replace(/H29\.211-[\d\-]*/g, '').trim();
  reasonText = reasonText.replace(/\(G22\.99\.08-[\d\-]+\)/g, '').trim();

  const metaPattern = new RegExp(`(?:\\d{2}\\/\\d{2}\\/\\d{4}\\s+)?(?:Phiếu từ chối|Phiếu bổ sung)?\\s*(?:${knownOfficers.join('|')})?$`, 'g');
  reasonText = reasonText.replace(metaPattern, '').trim();
  reasonText = reasonText.replace(/\d{2}\/\d{2}\/\d{4}\s*$/, '').trim();
  reasonText = reasonText.replace(/(Phiếu từ chối|Phiếu bổ sung)\s*$/, '').trim();

  for (const off of knownOfficers) {
    if (reasonText.endsWith(off)) {
      reasonText = reasonText.substring(0, reasonText.length - off.length).trim();
    }
  }

  const isBoSung = formTypeStr === 'Phiếu bổ sung';
  const formType = isBoSung ? 'mau02' : 'mau03';
  const status = isBoSung ? 'bo_sung' : 'tu_choi';
  const dateISO = formatDateISO(createdDateStr);

  return {
    id: `rec_${block.index}`,
    formType,
    ticketNo: String(block.index).padStart(2, '0'),
    createdDate: dateISO,
    citizenName,
    citizenId: '',
    address,
    phone: '',
    email: '',
    recordId: recordId || `H29.211-2600${String(block.index).padStart(2, '0')}-0000`,
    procedureContent: isBoSung ? 'Yêu cầu bổ sung, hoàn thiện hồ sơ' : 'Từ chối giải quyết hồ sơ do chưa đủ điều kiện theo quy định',
    rejectionReason: reasonText,
    officerName,
    status,
    field: block.field,
    notes: 'Import lại từ Sổ quản lý hồ sơ PDF',
    history: [
      {
        timestamp: `${dateISO}T08:00:00.000Z`,
        action: 'Khởi tạo',
        user: officerName,
        details: `Lập ${formTypeStr} cho ${citizenName}`
      }
    ]
  };
}

const finalRecords = rawBlocks.map(parseBlock);

console.log('Total converted records:', finalRecords.length);

const dbPath = path.join(__dirname, '..', 'assets', 'db.json');
const dbData = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

dbData.records = finalRecords;

fs.writeFileSync(dbPath, JSON.stringify(dbData, null, 2), 'utf8');

console.log('Successfully updated assets/db.json with 345 new records!');
