const fs = require('fs');
const path = require('path');

const fileContent = fs.readFileSync(path.join(__dirname, 'raw_ocr_pages.txt'), 'utf8');

// We split by lines that start with index number e.g. "1 1 Hộ tịch...", "345 1 Đất đai..."
// Notice regex for item start: /^\d+\s+\d+\s+(Hộ tịch|Đất đai\s*-\s*Tài nguyên Môi trường)/m

const rawBlocks = [];
const lines = fileContent.split(/\r?\n/);

let currentBlock = null;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const match = line.match(/^(\d+)\s+(\d+)\s+(Hộ tịch|Đất đai\s*-\s*Tài nguyên Môi trường)\s+(.*)$/);
  if (match) {
    if (currentBlock) {
      rawBlocks.push(currentBlock);
    }
    currentBlock = {
      index: parseInt(match[1]),
      subIndex: parseInt(match[2]),
      field: match[3].trim(),
      firstLineRest: match[4].trim(),
      lines: []
    };
  } else if (currentBlock) {
    currentBlock.lines.push(line);
  }
}
if (currentBlock) {
  rawBlocks.push(currentBlock);
}

console.log('Total blocks found:', rawBlocks.length);

if (rawBlocks.length > 0) {
  console.log('First block:', rawBlocks[0]);
  console.log('Last block:', rawBlocks[rawBlocks.length - 1]);
}
