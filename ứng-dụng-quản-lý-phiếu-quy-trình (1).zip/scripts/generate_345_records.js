const fs = require('fs');
const path = require('path');

const page1To5Data = [
  // 1
  {
    stt: 1, field: "Hộ tịch", name: "Nguyễn Thị Thu Nga", address: "68/27E Phùng Văn Cung, phường Cầu Kiệu", recordId: "H29.211-260101-0405",
    reason: "Thiếu đính kèm thành phần hồ sơ theo quy định tại mục số 4. Ví dụ: Giấy trích lục khai tử, Quyết định ly hôn….. Tờ khai ghi đầy đủ thông tin; ký tên và ghi rõ họ tên vào mục dành cho người yêu cầu (để xác nhận thông tin đã cung cấp trong tờ khai là đúng và chính xác)",
    date: "2026-01-01", officer: "Lâm Thị Hồng Tuyến"
  },
  // 2
  {
    stt: 2, field: "Hộ tịch", name: "Tạ Quang Hùng", address: "48 Hoa Sứ, phường Cầu Kiệu", recordId: "H29.211-260102-0211",
    reason: "Thiếu đính kèm thành phần hồ sơ theo quy định như: Tờ khai, CCCD ….",
    date: "2026-01-02", officer: "Lâm Thị Hồng Tuyến"
  },
  // 3
  {
    stt: 3, field: "Hộ tịch", name: "Nguyến Trương Hoáng Bảo", address: "343/66 Phan Xích Long , Phường Cầu Kiệu", recordId: "H29.211-251231-10364",
    reason: "Bổ sung Quyết định ly hôn; giấy tờ chứng minh thời gian cư trú tại 343/66 Phan Xích Long , Phường Cầu Kiệu, thành phố Hồ Chí Minh.",
    date: "2025-12-31", officer: "Lâm Thị Hồng Tuyến"
  },
  // 4
  {
    stt: 4, field: "Hộ tịch", name: "Nguyễn hoàng Oanh", address: "A.508 chung cư Nhiêu Tứ - 58 Hoa Sứ, Phường Cầu Kiệu", recordId: "H29.211-260107-8606",
    reason: "Bổ sung Tờ khai thông tin địa giới hành chính sau sáp nhập về nơi gửi, nơi cư trú. Ví dụ: UBND phường Cầu Kiệu, Thành phố Hồ Chí Minh, địa chỉ………., phường Cầu Kiệu, Thành phố Hồ Chí Minh; cần ghi rõ họ tên và ký tên vào mục dành cho người yêu cầu và scan/chụp hình đính kèm.",
    date: "2026-01-07", officer: "Lâm Thị Hồng Tuyến"
  },
  // 5
  {
    stt: 5, field: "Hộ tịch", name: "Phan Thanh Bảo Trân", address: "57 Tân Trang", recordId: "H29.211-260107-9804",
    reason: "Qua kiểm tra dữ liệu dân cư, hiện công dân đang thường trú tại 57 Tân Trang, Phường Tân Hòa, đề nghị công dân liên hệ nộp hồ sơ tại nơi thường trú theo quy định.",
    date: "2026-01-07", officer: "Lâm Thị Hồng Tuyến"
  },
  // 6
  {
    stt: 6, field: "Hộ tịch", name: "Phan Thanh Bảo Trân", address: "58 Tân Trang", recordId: "",
    reason: "Trùng hồ sơ",
    date: "2026-01-07", officer: "Lâm Thị Hồng Tuyến"
  },
  // 7
  {
    stt: 7, field: "Hộ tịch", name: "Lê Bá Long", address: "101/21 Duy Tân, Phường Cầu Kiệu", recordId: "H29.211-260108-8938",
    reason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin của công dân. Đề nghị công dân liên hệ, nộp hồ sơ nơi đăng ký khai sinh để được giải quyết. Trân trọng",
    date: "2026-01-08", officer: "Lâm Thị Hồng Tuyến"
  },
  // 8
  {
    stt: 8, field: "Hộ tịch", name: "Nguyễn Hoàng Oanh", address: "Căn hộ A.508 Chung cư Nhiêu Tứ - 58 Hoa Sứ, Phường Cầu Kiệu", recordId: "H29.211-260109-7967",
    reason: "Đề nghị công dân Scan/chụp hình tờ khai đính kèm; ghi rõ họ tên và ký tên vào mục dành cho người yêu cầu.",
    date: "2026-01-09", officer: "Lâm Thị Hồng Tuyến"
  },
  // 9
  {
    stt: 9, field: "Hộ tịch", name: "Phan Hoàng Thanh Hà", address: "50/24C Phùng Văn Cung, Phường Cầu Kiệu", recordId: "H29.211-260109-16581",
    reason: "Căn cứ NĐ 07",
    date: "2026-01-09", officer: "Lâm Thị Hồng Tuyến"
  },
  // 10
  {
    stt: 10, field: "Hộ tịch", name: "Hồ Thị Phương Diệu", address: "76/10/4A Phan Tây Hồ, khu phố 22", recordId: "H29.211-260112-7675",
    reason: "đã đc cấp giấy khai sinh",
    date: "2026-01-12", officer: "Lâm Thị Hồng Tuyến"
  },
  // 11
  {
    stt: 11, field: "Hộ tịch", name: "Trịnh Khắc Huy", address: "333/38 Lê Lợi, Phường Hạnh Thông", recordId: "H29.211-260113-17796",
    reason: "Thành phần hồ sơ tại mục số (5): Bổ sung văn bản ủy quyền theo quy định của pháp luật trong trường hợp…..; Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử tại thời điểm tiếp nhận hồ sơ không tìm thấy thông tin của công dân",
    date: "2026-01-13", officer: "Lâm Thị Hồng Tuyến"
  },
  // 12
  {
    stt: 12, field: "Hộ tịch", name: "Trương Thị Lan Anh", address: "50 Nguyễn Văn Trỗi, phường Cầu Kiệu", recordId: "H29.211-260119-14313",
    reason: "Căn cứ Điều 24 Nghị định 123/2015/NĐ-CP... Đề nghị công dân liên hệ nộp hồ sơ cấp bản sao trích lục hộ tịch để được giải quyết.",
    date: "2026-01-19", officer: "Lâm Thị Hồng Tuyến"
  },
  // 13
  {
    stt: 13, field: "Hộ tịch", name: "Trần Trí Nguyên", address: "9/9 Hoàng Văn Thụ", recordId: "H29.211-250802-4637",
    reason: "Hồ sơ Liên thông thủ tục hành chính về đăng ký khai sinh... của Ông Trần Trí Nguyên đã được giải quyết",
    date: "2025-08-02", officer: "Lâm Thị Hồng Tuyến"
  },
  // 14
  {
    stt: 14, field: "Hộ tịch", name: "Đỗ Hoàng Minh", address: "142/28 Phan Văn Trị, Phường Bình Thạnh, Tp. Hồ Chí Minh", recordId: "H29.211-260121-18628",
    reason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    date: "2026-01-21", officer: "Lâm Thị Hồng Tuyến"
  },
  // 15
  {
    stt: 15, field: "Hộ tịch", name: "Đỗ Thị Ánh Nguyệt", address: "33/33 Nguyễn Đình Chính, phường Cầu Kiệu, Tp. Hồ Chí Minh", recordId: "H29.211-260122-13989",
    reason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    date: "2026-01-22", officer: "Lâm Thị Hồng Tuyến"
  },
  // 16
  {
    stt: 16, field: "Hộ tịch", name: "Đỗ Thị Ánh Nguyệt", address: "33/33 Nguyễn Đình Chính, phường Cầu Kiệu, Tp. Hồ Chí Minh", recordId: "H29.211-260122-14165",
    reason: "Qua kiểm tra, rà soát dữ liệu thông tin hộ tịch điện tử không tìm thấy thông tin khai sinh của công dân theo yêu cầu",
    date: "2026-01-22", officer: "Lâm Thị Hồng Tuyến"
  },
  // 17
  {
    stt: 17, field: "Hộ tịch", name: "Đặng Hoàng Lan", address: "115/6 đường Phan Đăng Lưu", recordId: "H29.211-260127-6646",
    reason: "Công dân đề nghị cấp giấy xác nhận tình trạng hôn nhân trùng hồ sơ (02 lần).",
    date: "2026-01-27", officer: "Lâm Thị Hồng Tuyến"
  },
  // 18
  {
    stt: 18, field: "Hộ tịch", name: "Lê Hoàng Việt", address: "29/35 Đoàn Thị Điểm, Phường Cầu Kiệu, Tp. Hồ Chí Minh", recordId: "",
    reason: "Công dân thực hiện thủ tục đăng ký kết hôn không cần phải xuất trình Giấy xác nhận tình trạng hôn nhân",
    date: "2026-01-28", officer: "Lâm Thị Hồng Tuyến"
  },
  // 19
  {
    stt: 19, field: "Hộ tịch", name: "Trần Thị Thanh Loan", address: "79/4 Phan Đăng Lưu, Phường Cầu Kiệu, Tp. Hồ Chí Minh", recordId: "H29.211-260128-17633",
    reason: "Theo thông tin công dân cung cấp thời gian từ ngày 23/12/2005 đến 04/06/2012 công dân hiện cư trú tại 202 Lô E cư xá Thanh Đa.",
    date: "2026-01-28", officer: "Lâm Thị Hồng Tuyến"
  },
  // 20
  {
    stt: 20, field: "Hộ tịch", name: "Nguyễn Thị Lượng", address: "12 Ký Con, Phường Cầu Kiệu, Thành phố Hồ Chí Mi", recordId: "H29.211-260128-18900",
    reason: "Đề nghị công dân bổ sung giấy tờ có giá trị chứng minh cư trú từ khi đủ tuổi kết hôn cho đến nay",
    date: "2026-01-28", officer: "Lâm Thị Hồng Tuyến"
  }
];

console.log("Data template ready");
