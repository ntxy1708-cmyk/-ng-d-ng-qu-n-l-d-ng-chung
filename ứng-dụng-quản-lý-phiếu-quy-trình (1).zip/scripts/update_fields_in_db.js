import fs from 'fs';
import path from 'path';

const DB_FILE = path.join(process.cwd(), 'assets', 'db.json');

if (!fs.existsSync(DB_FILE)) {
  console.error("db.json not found");
  process.exit(1);
}

const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

console.log(`Processing ${db.records.length} records...`);

db.records = db.records.map((rec, idx) => {
  // Determine field
  let field = "Hộ tịch";
  
  // Is this the Đất đai record?
  if (rec.citizenName === 'Trần Kim Danh' || rec.recordId === 'H29.211-260624-150001' || idx === db.records.length - 1) {
    field = "Đất đai - Tài nguyên Môi trường";
  }

  // Format ticketNo cleanly as string
  let ticketNo = rec.ticketNo || String(idx + 1);
  if (!isNaN(parseInt(ticketNo))) {
    const num = parseInt(ticketNo);
    ticketNo = num < 10 ? `0${num}` : String(num);
  }

  return {
    ...rec,
    field,
    ticketNo,
    formType: rec.formType || 'mau03',
    status: rec.status || 'tu_choi',
    procedureContent: rec.procedureContent || `Giải quyết hồ sơ ${field}`,
    notes: rec.notes || 'Dữ liệu từ danh sách sổ quản lý hồ sơ Trung tâm Phục vụ hành chính công Phường Cầu Kiệu'
  };
});

fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');

console.log("Updated db.json successfully!");

// Verification
const fieldCounts = db.records.reduce((acc, r) => {
  acc[r.field] = (acc[r.field] || 0) + 1;
  return acc;
}, {});

console.log("Fields distribution:", fieldCounts);
