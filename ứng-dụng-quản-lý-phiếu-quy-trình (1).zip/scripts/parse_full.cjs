const fs = require('fs');
const path = require('path');

const fileContent = fs.readFileSync(path.join(__dirname, 'raw_ocr_pages.txt'), 'utf8');

const lines = fileContent.split(/\r?\n/);
const rawBlocks = [];
let currentBlock = null;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const match = line.match(/^(\d+)\s+(\d+)\s+(Hộ tịch|Tư pháp|Đất đai\s*-\s*Tài nguyên Môi trường)\s+(.*)$/);
  if (match) {
    if (currentBlock) {
      rawBlocks.push(currentBlock);
    }
    currentBlock = {
      index: parseInt(match[1]),
      subIndex: parseInt(match[2]),
      field: match[3].trim(),
      firstLineRest: match[4].trim(),
      lines: []
    };
  } else if (currentBlock) {
    if (line.trim().length > 0) {
      currentBlock.lines.push(line.trim());
    }
  }
}
if (currentBlock) {
  rawBlocks.push(currentBlock);
}

function parseBlock(block) {
  let allLines = [block.firstLineRest, ...block.lines];

  // Join lines that split H29.211- or G22.
  let fullText = allLines.join('\n');
  fullText = fullText.replace(/(H29\.211-[\d\-]*)\n([\d\-]+)/g, '$1$2');
  fullText = fullText.replace(/(H29\.211-)\n([\d\-]+)/g, '$1$2');
  fullText = fullText.replace(/(G22\.99\.08-[\d\-]*)\n([\d\-]+)/g, '$1$2');

  // Extract recordId anywhere in fullText
  let recordId = '';
  const recIdMatch = fullText.match(/(H29\.211-[\d\-]+(?:\s*\([^\)]+\))?)/);
  if (recIdMatch) {
    recordId = recIdMatch[1].trim();
  }

  // Extract Officer Name
  const knownOfficers = [
    'Lâm Thị Hồng Tuyến',
    'Nguyễn Tiến Đạt',
    'Dương Thị Hồng Ngọc',
    'Nguyễn Thị Xuân Ý',
    'Nguyễn Thanh Tùng',
    'Nguyễn Văn Hữu',
    'Đoàn Ngọc Diễm',
    'Nguyễn Thị Ngọc Hiếu'
  ];
  let officerName = 'Lâm Thị Hồng Tuyến';
  for (const off of knownOfficers) {
    if (fullText.includes(off)) {
      officerName = off;
      break;
    }
  }

  // Extract Form Type
  let formType = 'Phiếu từ chối';
  if (fullText.includes('Phiếu bổ sung')) {
    formType = 'Phiếu bổ sung';
  }

  // Extract Date
  let createdDate = '';
  const dates = [...fullText.matchAll(/(\d{2}\/\d{2}\/\d{4})/g)];
  if (dates.length > 0) {
    createdDate = dates[dates.length - 1][1];
  }

  // Build header string for Citizen Name & Address
  let headerText = block.firstLineRest;
  
  if (recordId) {
    headerText = headerText.replace(recordId, '').trim();
    headerText = headerText.replace(/H29\.211-[\d\-]*/g, '').trim();
  }

  // Check if headerText overflows to block.lines[0]
  let lineIdx = 0;
  while (lineIdx < block.lines.length) {
    const nextLine = block.lines[lineIdx];
    const isReasonStart = nextLine.match(/^(Qua|Căn cứ|Theo|Đề nghị|Trường hợp|Thiếu|Thực hiện|Nộp|Hồ sơ|Không|Tài khoản|Bổ sung|Làm lại|Cải chính|Công dân|Ông|Bà|Sổ|Việc|Cơ quan|Hồ sơ mã|Tài khoản|Nộp|Tờ khai)/i);
    const hasAddressPatterns = nextLine.match(/(?:\d+|Ấp|ẤP|Thôn|THÔN|Khóm|KP|Khu|SỐ|Số|Căn|Phòng|CC|c\/c|OG|CH|TDP|NKS|P\d+|A\d+|B\d+|C\d+|D\d+|TB1-)/i);

    if (!isReasonStart && hasAddressPatterns && !headerText.match(/\d{2,}/)) {
      headerText += ' ' + nextLine;
      lineIdx++;
    } else {
      break;
    }
  }

  if (recordId) {
    headerText = headerText.replace(recordId, '').trim();
    headerText = headerText.replace(/H29\.211-[\d\-]*/g, '').trim();
  }

  // Address pattern trigger without using \b before accented characters:
  // Regex matches start of address:
  // Either a number like 68/27E or 48 or 14 or 137 or 56
  // Or location tokens: Ấp, ẤP, Thôn, THÔN, Khóm, TDP, NKS, OG, P505, A501, Căn, CH, Số, SỐ, TB1-, G002, A007, Căn hộ, CH F05.04, etc.
  const addrRegex = /(?:^|\s+)(?:\d+[\d\/\-A-Za-z\.]*|A\.\d+|A\d+|B\d+|C\d+|D\d+|F\d+|P\d+|OG|TDP|K204|601|Căn\s+hộ|Số\s+nhà|Số|SỐ|Thôn|THÔN|Ấp|ẤP|NKS|CH|c\/c|TB1[^\s]*|G002|CH\s+F[^\s]*)(?=\s+|[,\/\.\-]|$)/i;

  let citizenName = headerText;
  let address = '';

  const matchAddr = headerText.match(addrRegex);

  if (matchAddr) {
    const idx = headerText.indexOf(matchAddr[0]);
    if (idx > 0) {
      citizenName = headerText.substring(0, idx).trim();
      address = headerText.substring(idx).trim();
    } else if (idx === 0) {
      citizenName = 'Công dân';
      address = headerText;
    }
  }

  // Special fixes for items where address has no standard prefix or name is clear
  // If citizenName still contains address-like words, or address is empty:
  // e.g. "Nguyễn Thị Loan 50/7, Duy Tân..."
  if (!address && citizenName) {
    // Try matching any digit sequence in citizenName
    const numMatch = citizenName.match(/\s+(\d+[\d\/\-A-Za-z\.]*|\d+\,.*)$/);
    if (numMatch) {
      const idx = citizenName.indexOf(numMatch[0]);
      address = citizenName.substring(idx).trim();
      citizenName = citizenName.substring(0, idx).trim();
    }
  }

  // Clean trailing punctuation from citizenName
  citizenName = citizenName.replace(/[\d\.\,\-]+$/, '').trim();

  // Reconstruct rejectionReason
  let reasonLines = block.lines.slice(lineIdx);
  let reasonText = reasonLines.join('\n').trim();

  if (recordId) {
    reasonText = reasonText.replace(recordId, '').trim();
  }
  reasonText = reasonText.replace(/H29\.211-[\d\-]*/g, '').trim();
  reasonText = reasonText.replace(/\(G22\.99\.08-[\d\-]+\)/g, '').trim();

  // Strip trailing metadata
  const metaPattern = new RegExp(`(?:\\d{2}\\/\\d{2}\\/\\d{4}\\s+)?(?:Phiếu từ chối|Phiếu bổ sung)?\\s*(?:${knownOfficers.join('|')})?$`, 'g');
  reasonText = reasonText.replace(metaPattern, '').trim();
  reasonText = reasonText.replace(/\d{2}\/\d{2}\/\d{4}\s*$/, '').trim();
  reasonText = reasonText.replace(/(Phiếu từ chối|Phiếu bổ sung)\s*$/, '').trim();

  return {
    index: block.index,
    field: block.field,
    citizenName,
    address,
    recordId,
    rejectionReason: reasonText,
    createdDate,
    formType,
    officerName
  };
}

const results = rawBlocks.map(parseBlock);

console.log('Processed:', results.length);
console.log('Empty address count:', results.filter(r => !r.address).length);
console.log('Empty address list:', results.filter(r => !r.address).map(r => ({ idx: r.index, name: r.citizenName })));
