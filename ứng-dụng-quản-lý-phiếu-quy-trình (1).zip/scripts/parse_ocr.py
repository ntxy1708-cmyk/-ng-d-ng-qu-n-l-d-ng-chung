import json
import re

# Read current db.json structure for users, procedures, officers, reasons
with open('assets/db.json', 'r', encoding='utf-8') as f:
    current_db = json.load(f)

print("Current keys in db:", list(current_db.keys()))
