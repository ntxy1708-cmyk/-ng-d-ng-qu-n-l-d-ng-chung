const fs = require('fs');
const path = require('path');

const fileContent = fs.readFileSync(path.join(__dirname, 'raw_ocr_pages.txt'), 'utf8');

const targetIndices = [58, 70, 93, 96, 113, 118, 119, 211, 244, 266, 269, 319, 330];

for (const idx of targetIndices) {
  const regex = new RegExp(`^${idx}\\s+${idx}\\s+.*?(?=\\n\\d+\\s+\\d+\\s+|$)`, 'ms');
  const match = fileContent.match(regex);
  if (match) {
    console.log(`=== BLOCK ${idx} ===`);
    console.log(match[0]);
  }
}
