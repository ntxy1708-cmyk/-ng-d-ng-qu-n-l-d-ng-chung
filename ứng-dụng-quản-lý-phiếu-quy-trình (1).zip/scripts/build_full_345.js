const fs = require('fs');
const path = require('path');

const DB_DIR = path.join(process.cwd(), 'assets');
const DB_FILE = path.join(DB_DIR, 'db.json');

// Read existing DB to keep users, procedures, officers, etc.
let existingDb = {
  users: [],
  procedures: [],
  officers: [],
  reasons: [],
  templates: [],
  audits: [],
  dailyReports: [],
  reportConfigs: [],
  records: []
};

if (fs.existsSync(DB_FILE)) {
  try {
    existingDb = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (e) {
    console.error(e);
  }
}

// Function to convert DD/MM/YYYY to YYYY-MM-DD
function parseDate(dStr) {
  if (!dStr) return "2026-06-24";
  const parts = dStr.trim().split('/');
  if (parts.length === 3) {
    const day = parts[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }
  return dStr;
}

function fmtTicket(num) {
  return num < 10 ? `0${num}` : String(num);
}

// Read raw text of all pages from OCR if we can store raw items or build full array
const rawRecords = [
  // Item 1 to 344 are "Hộ tịch", Item 345 is "Đất đai - Tài nguyên Môi trường"
];

