import json
import os
import re

# Read OCR text lines
ocr_file = os.path.join(os.getcwd(), 'scripts', 'ocr_raw.txt')

# Let's create the raw text file for python parsing
